import { useMemo, useState, type ReactNode } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { FileUp, Play, Upload } from "lucide-react";
import { toast } from "sonner";
import { AppShell, PageHeader } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input, Textarea } from "@/components/ui/input";
import { Badge, Label, Progress } from "@/components/ui/misc";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { generateQuizFn } from "@/lib/ai";
import { SAMPLE_DOCUMENTS } from "@/lib/data";
import { useAppStore } from "@/lib/store";
import type { GeneratedQuiz } from "@/lib/types";

export const Route = createFileRoute("/quiz/")({ component: QuizStudio });

const STEPS = ["Upload", "Extract concepts", "Draft MCQs", "Tag difficulty"];

function QuizStudio() {
  const addQuiz = useAppStore((s) => s.addQuiz);
  const quizzes = useAppStore((s) => s.quizzes);
  const startQuiz = useAppStore((s) => s.startQuiz);
  const navigate = useNavigate();
  const [sourceName, setSourceName] = useState("Untitled source");
  const [content, setContent] = useState("");
  const [count, setCount] = useState("6");
  const [difficulty, setDifficulty] = useState<"easy" | "medium" | "hard" | "mixed">("mixed");
  const [language, setLanguage] = useState<"English" | "Hindi" | "Bilingual">("English");
  const [durationMin, setDurationMin] = useState("15");
  const [busy, setBusy] = useState(false);
  const [step, setStep] = useState(0);
  const [fileError, setFileError] = useState("");

  const canGenerate = content.trim().length >= 40;

  async function onFile(file: File) {
    setFileError("");
    setSourceName(file.name);
    const textLike =
      file.type.startsWith("text/") ||
      /\.(md|txt|csv|json)$/i.test(file.name);
    if (textLike) {
      const text = await file.text();
      setContent(text.slice(0, 9000));
      toast.success(`Loaded ${file.name}`);
      return;
    }
    setContent(
      (prev) =>
        prev ||
        `Document: ${file.name} (${Math.round(file.size / 1024)} KB, ${file.type || "binary"}).\n\n` +
          "Extracted text is unavailable in the browser for this format. Paste an excerpt or load a sample PLFS / NAD note, then generate.",
    );
    toast.message("Binary formats need an excerpt. Paste key pages or use a sample document.");
  }

  async function generate() {
    if (!canGenerate) {
      setFileError("Add at least 40 characters of source material.");
      return;
    }
    setBusy(true);
    setStep(1);
    const timers = [
      window.setTimeout(() => setStep(2), 600),
      window.setTimeout(() => setStep(3), 1400),
    ];
    try {
      const res = await generateQuizFn({
        data: {
          content: content.slice(0, 8500),
          sourceName,
          count: Number(count),
          difficulty,
          language,
          durationMin: Number(durationMin),
        },
      });
      if (!res.ok) {
        toast.error(res.error);
        return;
      }
      const quiz: GeneratedQuiz = {
        id: crypto.randomUUID(),
        title: res.quiz.title,
        sourceName,
        language,
        durationMin: Number(durationMin),
        difficulty,
        questions: res.quiz.questions,
        createdAt: new Date().toISOString(),
        published: false,
        status: "draft",
      };
      addQuiz(quiz);
      setStep(4);
      toast.success(`Drafted ${quiz.questions.length} questions. Open Trainer Desk to approve.`);
    } catch {
      toast.error("Generation failed.");
    } finally {
      timers.forEach(clearTimeout);
      setBusy(false);
    }
  }

  const progress = useMemo(() => (busy ? Math.min(90, 20 + step * 22) : step >= 4 ? 100 : 0), [busy, step]);

  return (
    <AppShell>
      <PageHeader
        eyebrow="Assessment studio"
        title="Quiz and MCQ generator"
        description="Upload a note, deck excerpt or video transcript. StatSkill drafts tagged questions with explanations for NSSTA and iGOT programmes."
      />

      <div className="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
        <Card>
          <CardHeader>
            <CardTitle>Source material</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <label className="flex cursor-pointer flex-col items-center justify-center rounded-2xl border border-dashed border-border bg-muted/40 px-4 py-8 text-center">
              <Upload className="size-6 text-indigo" />
              <p className="mt-2 text-sm font-medium">Drop PDF, PPT, video notes or text</p>
              <p className="text-xs text-muted-foreground">Text files load directly. For PDF/PPT, paste an excerpt.</p>
              <input
                type="file"
                className="sr-only"
                accept=".pdf,.ppt,.pptx,.md,.txt,.csv,.json,video/*,application/pdf"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) void onFile(file);
                }}
              />
            </label>
            <div className="flex flex-wrap gap-2">
              {SAMPLE_DOCUMENTS.map((doc) => (
                <Button
                  key={doc.id}
                  type="button"
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    setSourceName(doc.name);
                    setContent(doc.content);
                    toast.success(`Loaded ${doc.title}`);
                  }}
                >
                  <FileUp className="size-3.5" />
                  {doc.title}
                </Button>
              ))}
            </div>
            <div className="space-y-1.5">
              <Label>Source name</Label>
              <Input value={sourceName} onChange={(e) => setSourceName(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>Content</Label>
              <Textarea
                className="min-h-40"
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Paste lecture notes, a chapter, or a methodology excerpt…"
              />
              {fileError && <p className="text-xs text-destructive">{fileError}</p>}
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Questions">
                <Select value={count} onValueChange={setCount}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {["4", "6", "8", "10", "12"].map((n) => (
                      <SelectItem key={n} value={n}>{n}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>
              <Field label="Difficulty">
                <Select value={difficulty} onValueChange={(v) => setDifficulty(v as typeof difficulty)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="easy">Easy</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="hard">Hard</SelectItem>
                    <SelectItem value="mixed">Mixed</SelectItem>
                  </SelectContent>
                </Select>
              </Field>
              <Field label="Language">
                <Select value={language} onValueChange={(v) => setLanguage(v as typeof language)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="English">English</SelectItem>
                    <SelectItem value="Hindi">Hindi</SelectItem>
                    <SelectItem value="Bilingual">Bilingual</SelectItem>
                  </SelectContent>
                </Select>
              </Field>
              <Field label="Duration (minutes)">
                <Select value={durationMin} onValueChange={setDurationMin}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {["10", "15", "20", "30", "45"].map((n) => (
                      <SelectItem key={n} value={n}>{n}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>
            </div>
            <Button variant="accent" disabled={busy} onClick={() => void generate()} className="w-full sm:w-auto">
              {busy ? "Generating…" : "Generate MCQs"}
            </Button>
            {(busy || step >= 4) && (
              <div>
                <Progress value={progress} />
                <div className="mt-2 flex flex-wrap gap-2 text-[11px] text-muted-foreground">
                  {STEPS.map((s, i) => (
                    <span key={s} className={i < step ? "text-accent" : ""}>
                      {s}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Drafts in this session</CardTitle>
          </CardHeader>
          <CardContent>
            {quizzes.length === 0 ? (
              <div className="rounded-2xl bg-muted/50 px-4 py-10 text-center">
                <p className="font-medium">No quizzes yet</p>
                <p className="mt-1 text-sm text-muted-foreground">
                  Load the PLFS sampling note and generate a six-question paper to see the trainer flow.
                </p>
              </div>
            ) : (
              <ul className="space-y-3">
                {quizzes.map((q) => (
                  <li key={q.id} className="rounded-xl border border-border p-4">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <p className="font-medium">{q.title}</p>
                        <p className="text-xs text-muted-foreground">
                          {q.questions.length} questions · {q.durationMin} min · {q.difficulty}
                        </p>
                      </div>
                      <Badge variant={q.status === "published" ? "success" : "muted"}>{q.status}</Badge>
                    </div>
                    <Button
                      size="sm"
                      className="mt-3"
                      onClick={() => {
                        startQuiz(q.id);
                        navigate({ to: "/quiz/take" });
                      }}
                    >
                      <Play className="size-3.5" />
                      Sit paper
                    </Button>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>
    </AppShell>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      {children}
    </div>
  );
}
