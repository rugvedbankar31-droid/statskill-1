import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Search } from "lucide-react";
import { toast } from "sonner";
import { AppShell, PageHeader } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge, Progress } from "@/components/ui/misc";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { COURSES, recommendCourses } from "@/lib/data";
import { COMPETENCIES } from "@/lib/data";
import { useAppStore } from "@/lib/store";
import { t } from "@/lib/i18n";

export const Route = createFileRoute("/courses")({ component: CoursesPage });

function CoursesPage() {
  const lang = useAppStore((s) => s.lang);
  const enrolments = useAppStore((s) => s.enrolments);
  const enrol = useAppStore((s) => s.enrol);
  const result = useAppStore((s) => s.assessmentResult);
  const [q, setQ] = useState("");
  const [provider, setProvider] = useState("all");
  const [level, setLevel] = useState("all");

  const recIds = new Set(
    recommendCourses(result?.competencies ?? COMPETENCIES, 5).map((c) => c.id),
  );

  const list = useMemo(() => {
    const query = q.trim().toLowerCase();
    return COURSES.filter((c) => {
      if (provider !== "all" && c.provider !== provider) return false;
      if (level !== "all" && c.level !== level) return false;
      if (!query) return true;
      const hay = `${c.title} ${c.skills.join(" ")} ${c.description} ${c.provider}`.toLowerCase();
      return hay.includes(query) || c.skills.some((s) => s.toLowerCase().startsWith(query));
    });
  }, [q, provider, level]);

  return (
    <AppShell>
      <PageHeader
        eyebrow="iGOT Karmayogi + NSSTA TPAC"
        title="Course catalogue"
        description="Semantic search across Mission Karmayogi and NSSTA programmes. Recommendations stay linked to your competency gaps."
      />

      <div className="mb-5 grid gap-3 md:grid-cols-[1fr_12rem_12rem]">
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            className="pl-9"
            placeholder="Search skills, SNA, PLFS, Python…"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
        </div>
        <Select value={provider} onValueChange={setProvider}>
          <SelectTrigger><SelectValue placeholder="Provider" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All providers</SelectItem>
            <SelectItem value="iGOT Karmayogi">iGOT Karmayogi</SelectItem>
            <SelectItem value="NSSTA TPAC">NSSTA TPAC</SelectItem>
            <SelectItem value="StatSkill AI">StatSkill AI</SelectItem>
          </SelectContent>
        </Select>
        <Select value={level} onValueChange={setLevel}>
          <SelectTrigger><SelectValue placeholder="Level" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All levels</SelectItem>
            <SelectItem value="Foundation">Foundation</SelectItem>
            <SelectItem value="Intermediate">Intermediate</SelectItem>
            <SelectItem value="Advanced">Advanced</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {list.length === 0 ? (
        <Card className="px-6 py-16 text-center">
          <p className="font-semibold">No programmes match</p>
          <p className="mt-1 text-sm text-muted-foreground">Clear filters or try “sampling”, “Python”, or “DPDP”.</p>
          <Button className="mt-4" variant="outline" onClick={() => { setQ(""); setProvider("all"); setLevel("all"); }}>
            Reset filters
          </Button>
        </Card>
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          {list.map((c) => {
            const enr = enrolments.find((e) => e.courseId === c.id);
            return (
              <Card key={c.id} className="flex flex-col p-5">
                <div className="flex flex-wrap items-center gap-2">
                  <Badge variant="navy">{c.provider}</Badge>
                  <Badge variant="outline">{c.level}</Badge>
                  {recIds.has(c.id) && <Badge variant="accent">Gap-linked</Badge>}
                  {enr && (
                    <Badge variant={enr.status === "completed" ? "success" : "muted"}>
                      {enr.status.replace("_", " ")}
                    </Badge>
                  )}
                </div>
                <h3 className="mt-3 font-display text-lg font-semibold leading-snug">{c.title}</h3>
                <p className="mt-2 flex-1 text-sm text-muted-foreground">{c.description}</p>
                <p className="mt-3 text-xs text-muted-foreground">
                  {c.durationHours}h · {c.modules} modules · {c.language} · rating {c.rating}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">Skills: {c.skills.join(", ")}</p>
                {enr && (
                  <div className="mt-3">
                    <Progress value={enr.progress} />
                  </div>
                )}
                <Button
                  className="mt-4 w-fit"
                  variant={enr ? "outline" : "accent"}
                  onClick={() => {
                    enrol(c.id);
                    toast.success(enr ? "Enrolment updated." : `Enrolled in ${c.title}`);
                  }}
                >
                  {enr ? t(lang, "continue") : t(lang, "enrol")}
                </Button>
              </Card>
            );
          })}
        </div>
      )}
    </AppShell>
  );
}
