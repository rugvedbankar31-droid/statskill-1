import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Building2, Lock, ShieldCheck } from "lucide-react";
import { MarketingNav } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/misc";
import { DEMO_USERS } from "@/lib/data";
import { useAppStore } from "@/lib/store";
import { t } from "@/lib/i18n";
import type { Role } from "@/lib/types";
import { toast } from "sonner";

export const Route = createFileRoute("/login")({ component: LoginPage });

const ROLE_COPY: Record<Role, string> = {
  learner: "Competency file, learning path, quizzes",
  trainer: "Question bank, approve & publish, NSSTA desk",
  admin: "Workforce analytics, catalogues, reports",
  superadmin: "Frameworks, tenants, security controls",
};

function LoginPage() {
  const lang = useAppStore((s) => s.lang);
  const signIn = useAppStore((s) => s.signIn);
  const navigate = useNavigate();

  function enter(role: Role) {
    signIn(role);
    toast.success("Signed in with iGOT SSO (demo directory).");
    if (role === "admin" || role === "superadmin") navigate({ to: "/admin" });
    else if (role === "trainer") navigate({ to: "/quiz/trainer" });
    else navigate({ to: "/dashboard" });
  }

  return (
    <div className="min-h-screen bg-background">
      <MarketingNav />
      <div className="mx-auto grid max-w-6xl gap-10 px-4 py-12 sm:px-6 lg:grid-cols-[0.9fr_1.1fr]">
        <div>
          <Badge variant="navy">Secure access</Badge>
          <h1 className="mt-4 font-display text-4xl font-semibold">{t(lang, "ssoTitle")}</h1>
          <p className="mt-3 text-muted-foreground">{t(lang, "ssoBody")}</p>
          <ul className="mt-8 space-y-3 text-sm">
            {[
              { icon: ShieldCheck, text: "SAML / OIDC with NIC identity and iGOT Karmayogi" },
              { icon: Lock, text: "Role tokens: Learner, Trainer, Administrator, Super Admin" },
              { icon: Building2, text: "MoSPI directory + State DES federation (demo personas below)" },
            ].map((row) => (
              <li key={row.text} className="flex gap-3 rounded-xl bg-card p-3 shadow-card">
                <row.icon className="mt-0.5 size-4 text-accent" />
                {row.text}
              </li>
            ))}
          </ul>
          <p className="mt-6 text-xs text-muted-foreground">
            Production SSO is directory-backed. This preview uses named officers so you can tour each role without a government IdP.
          </p>
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          {DEMO_USERS.map((u) => (
            <Card key={u.id} className="flex flex-col p-5">
              <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-accent">{u.role}</p>
              <h2 className="mt-2 font-display text-xl font-semibold">{u.name}</h2>
              <p className="text-sm text-muted-foreground">{u.designation}</p>
              <p className="mt-1 text-xs text-muted-foreground">
                {u.department}
                <br />
                {u.cadre} · {u.region}
              </p>
              <p className="mt-3 flex-1 text-xs text-muted-foreground">{ROLE_COPY[u.role]}</p>
              <Button className="mt-4 w-full" variant={u.role === "learner" ? "accent" : "default"} onClick={() => enter(u.role)}>
                Continue as {u.name.split(" ")[0]}
              </Button>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
