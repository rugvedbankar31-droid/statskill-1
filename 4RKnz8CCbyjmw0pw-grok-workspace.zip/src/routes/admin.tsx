import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { AppShell, PageHeader } from "@/components/layout";
import { SkillDistribution, WorkforceBars } from "@/components/charts";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/misc";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  COURSES,
  DEPARTMENTS,
  DESIGNATIONS,
  INSIGHTS,
  REGIONS,
  WORKFORCE,
} from "@/lib/data";
import { downloadText } from "@/lib/utils";
import { DEMO_USERS } from "@/lib/data";

export const Route = createFileRoute("/admin")({ component: AdminPage });

function AdminPage() {
  const [department, setDepartment] = useState("all");
  const [designation, setDesignation] = useState("all");
  const [region, setRegion] = useState("all");
  const [domain, setDomain] = useState("all");

  const rows = useMemo(() => {
    return WORKFORCE.filter((w) => {
      if (department !== "all" && w.department !== department) return false;
      if (designation !== "all" && w.designation !== designation) return false;
      if (region !== "all" && w.region !== region) return false;
      if (domain !== "all") {
        const score = w.domainScores[domain as keyof typeof w.domainScores];
        if (score >= 70) return false;
      }
      return true;
    });
  }, [department, designation, region, domain]);

  const mean = rows.length
    ? Math.round(rows.reduce((s, r) => s + r.score, 0) / rows.length)
    : 0;
  const completion = rows.length
    ? Math.round(rows.reduce((s, r) => s + r.completionRate, 0) / rows.length)
    : 0;

  return (
    <AppShell>
      <PageHeader
        eyebrow="Capacity building division"
        title="Administrator dashboard"
        description="Organisation-wide competency analytics for MoSPI, NSO and participating State DES units."
        actions={
          <Button
            variant="outline"
            onClick={() => {
              downloadText("statskill-workforce.json", JSON.stringify(rows, null, 2), "application/json");
              toast.success("Workforce extract downloaded.");
            }}
          >
            Export report
          </Button>
        }
      />

      <div className="mb-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        <Filter label="Department" value={department} onChange={setDepartment} options={DEPARTMENTS} />
        <Filter label="Designation" value={designation} onChange={setDesignation} options={DESIGNATIONS} />
        <Filter label="Region" value={region} onChange={setRegion} options={REGIONS} />
        <Filter
          label="Competency domain"
          value={domain}
          onChange={setDomain}
          options={[
            { value: "statistical", label: "Statistical" },
            { value: "technical", label: "Technical" },
            { value: "digital", label: "Digital Governance" },
            { value: "behavioural", label: "Behavioural" },
          ]}
        />
        <Filter
          label="Date range"
          value="fy"
          onChange={() => toast.message("FY 2026–27 is the active training year.")}
          options={[{ value: "fy", label: "FY 2026–27" }]}
          hideAll
        />
      </div>

      <div className="grid gap-3 sm:grid-cols-4">
        {[
          ["Officers in view", String(rows.length)],
          ["Mean competency", String(mean)],
          ["Learning completion", `${completion}%`],
          ["Hours logged", String(rows.reduce((s, r) => s + r.hours, 0))],
        ].map(([k, v]) => (
          <Card key={k} className="p-4">
            <p className="text-xs text-muted-foreground">{k}</p>
            <p className="mt-1 font-display text-2xl font-semibold tabular-nums">{v}</p>
          </Card>
        ))}
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        {INSIGHTS.map((ins) => (
          <Card key={ins.title} className="p-5">
            <Badge variant="accent">{ins.tag}</Badge>
            <h3 className="mt-3 font-display text-lg font-semibold">{ins.title}</h3>
            <p className="mt-2 text-sm text-muted-foreground">{ins.body}</p>
          </Card>
        ))}
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Department comparison</CardTitle>
          </CardHeader>
          <CardContent>
            {rows.length ? <WorkforceBars rows={rows} /> : <Empty />}
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Workforce skill distribution</CardTitle>
          </CardHeader>
          <CardContent>
            {rows.length ? <SkillDistribution rows={rows} /> : <Empty />}
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="people" className="mt-6">
        <TabsList>
          <TabsTrigger value="people">Users</TabsTrigger>
          <TabsTrigger value="framework">Frameworks</TabsTrigger>
          <TabsTrigger value="catalogue">Course catalogues</TabsTrigger>
          <TabsTrigger value="assess">Assessments</TabsTrigger>
        </TabsList>
        <TabsContent value="people">
          <Card className="overflow-x-auto p-0">
            <table className="w-full min-w-[640px] text-left text-sm">
              <thead className="border-b border-border text-xs uppercase tracking-wide text-muted-foreground">
                <tr>
                  <th className="px-4 py-3 font-medium">Officer</th>
                  <th className="px-4 py-3 font-medium">Designation</th>
                  <th className="px-4 py-3 font-medium">Department</th>
                  <th className="px-4 py-3 font-medium">Score</th>
                  <th className="px-4 py-3 font-medium">Completion</th>
                  <th className="px-4 py-3 font-medium">Top gap</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.id} className="border-b border-border last:border-0">
                    <td className="px-4 py-3">
                      <p className="font-medium">{r.name}</p>
                      <p className="text-xs text-muted-foreground">{r.cadre} · {r.region}</p>
                    </td>
                    <td className="px-4 py-3">{r.designation}</td>
                    <td className="px-4 py-3">{r.department}</td>
                    <td className="px-4 py-3 tabular-nums">{r.score}</td>
                    <td className="px-4 py-3 tabular-nums">{r.completionRate}%</td>
                    <td className="px-4 py-3">{r.topGap}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {rows.length === 0 && <Empty />}
          </Card>
        </TabsContent>
        <TabsContent value="framework">
          <Card className="p-5">
            <h3 className="font-semibold">NSSTA / FRAC competency framework</h3>
            <p className="mt-2 text-sm text-muted-foreground">
              Four domains, fourteen skills. Super Admins can version the framework at the start of each training year. Current version: FY 2026–27 v3.
            </p>
            <ul className="mt-4 grid gap-2 sm:grid-cols-2">
              {["Statistical", "Technical", "Digital Governance", "Behavioural"].map((d) => (
                <li key={d} className="rounded-xl bg-muted/60 px-3 py-2 text-sm">
                  {d} domain · active
                </li>
              ))}
            </ul>
          </Card>
        </TabsContent>
        <TabsContent value="catalogue">
          <div className="grid gap-3 md:grid-cols-2">
            {COURSES.map((c) => (
              <Card key={c.id} className="p-4">
                <Badge variant="navy">{c.provider}</Badge>
                <p className="mt-2 font-medium">{c.title}</p>
                <p className="text-xs text-muted-foreground">
                  {c.durationHours}h · {c.level} · rating {c.rating}
                </p>
              </Card>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="assess">
          <Card className="p-5">
            <p className="text-sm text-muted-foreground">
              Live papers sit in Trainer Desk. Directory identities in this preview:
            </p>
            <ul className="mt-3 space-y-2 text-sm">
              {DEMO_USERS.map((u) => (
                <li key={u.id}>
                  {u.name} · {u.role} · {u.email}
                </li>
              ))}
            </ul>
          </Card>
        </TabsContent>
      </Tabs>
    </AppShell>
  );
}

function Filter({
  label,
  value,
  onChange,
  options,
  hideAll,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: string[] | { value: string; label: string }[];
  hideAll?: boolean;
}) {
  const items = options.map((o) => (typeof o === "string" ? { value: o, label: o } : o));
  return (
    <label className="block text-xs font-medium text-muted-foreground">
      {label}
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger className="mt-1">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {!hideAll && <SelectItem value="all">All</SelectItem>}
          {items.map((o) => (
            <SelectItem key={o.value} value={o.value}>
              {o.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </label>
  );
}

function Empty() {
  return (
    <p className="px-4 py-10 text-center text-sm text-muted-foreground">
      No officers match these filters. Clear a dimension to widen the view.
    </p>
  );
}
