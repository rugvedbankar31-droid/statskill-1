import { createFileRoute } from "@tanstack/react-router";
import { Cloud, Globe, KeyRound, Lock, Server, ShieldCheck } from "lucide-react";
import { AppShell, PageHeader } from "@/components/layout";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/misc";

export const Route = createFileRoute("/security")({ component: SecurityPage });

const ROLES = [
  {
    role: "Learner",
    access: "Own competency file, catalogue, sit published papers, assistant",
  },
  {
    role: "Trainer",
    access: "Question bank edit/approve/publish, cohort results, NSSTA materials",
  },
  {
    role: "Administrator",
    access: "Workforce analytics, user directory, catalogues, reports",
  },
  {
    role: "Super Admin",
    access: "Framework versioning, tenant federation, SSO policy, audit export",
  },
];

function SecurityPage() {
  return (
    <AppShell>
      <PageHeader
        eyebrow="System design"
        title="Security and readiness"
        description="Role-based access, iGOT SSO, government-cloud hosting posture and a multilingual shell — designed for MoSPI deployment, not a public LMS."
      />

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="p-5">
          <KeyRound className="size-5 text-indigo" />
          <h2 className="mt-3 font-display text-xl font-semibold">SSO login experience</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            Officers authenticate through iGOT Karmayogi / NIC identity. Tokens carry cadre (ISS, SSS), posting and FRAC role. This preview uses named directory personas in place of a live IdP.
          </p>
          <div className="mt-4 flex flex-wrap gap-2">
            <Badge variant="navy">SAML 2.0</Badge>
            <Badge variant="navy">OIDC</Badge>
            <Badge variant="outline">NIC IdP</Badge>
          </div>
        </Card>
        <Card className="p-5">
          <Cloud className="size-5 text-indigo" />
          <h2 className="mt-3 font-display text-xl font-semibold">Government-cloud ready</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            Target hosting on NIC National Cloud / MeghRaj with no unit-level microdata at rest in the learning layer. Competency scores and enrolment metadata only.
          </p>
          <div className="mt-4 flex flex-wrap gap-2">
            <Badge variant="success">MeitY empanelled path</Badge>
            <Badge variant="outline">No survey microdata</Badge>
          </div>
        </Card>
      </div>

      <Card className="mt-4 overflow-x-auto p-0">
        <table className="w-full min-w-[520px] text-left text-sm">
          <thead className="border-b border-border text-xs uppercase tracking-wide text-muted-foreground">
            <tr>
              <th className="px-5 py-3 font-medium">Role</th>
              <th className="px-5 py-3 font-medium">Access</th>
            </tr>
          </thead>
          <tbody>
            {ROLES.map((r) => (
              <tr key={r.role} className="border-b border-border last:border-0">
                <td className="px-5 py-3 font-medium">{r.role}</td>
                <td className="px-5 py-3 text-muted-foreground">{r.access}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      <div className="mt-4 grid gap-4 sm:grid-cols-3">
        {[
          {
            icon: ShieldCheck,
            title: "Secure data sharing",
            body: "Division-to-academy sharing is tagged purpose-limited. Exports are officer-level aggregates, never unit-level survey files.",
          },
          {
            icon: Globe,
            title: "Multilingual",
            body: "English and Hindi ship in the shell. Regional language packs (Tamil, Bengali, Marathi) plug into the same key map.",
          },
          {
            icon: Server,
            title: "Audit posture",
            body: "Role changes, paper publish events and report downloads are first-class audit events for internal inspection.",
          },
        ].map((item) => (
          <Card key={item.title} className="p-5">
            <item.icon className="size-5 text-accent" />
            <h3 className="mt-3 font-semibold">{item.title}</h3>
            <p className="mt-2 text-sm text-muted-foreground">{item.body}</p>
          </Card>
        ))}
      </div>

      <Card className="mt-4 flex items-start gap-3 p-5">
        <Lock className="mt-0.5 size-4 text-indigo" />
        <p className="text-sm text-muted-foreground">
          Classification: Official (learning metadata). Do not upload identifiable respondent records from PLFS, HCES or ASI into Quiz Studio.
        </p>
      </Card>
    </AppShell>
  );
}
