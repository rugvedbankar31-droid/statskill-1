import { useEffect, useMemo, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { AppShell, PageHeader } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge, Progress } from "@/components/ui/misc";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/quiz/take")({ component: QuizTakePage });

function QuizTakePage() {
  const quizzes = useAppStore((s) => s.quizzes);
  const activeQuizId = useAppStore((s) => s.activeQuizId);
  const answers = useAppStore((s) => s.quizAnswers);
  const startedAt = useAppStore((s) => s.quizStartedAt);
  const answerQuestion = useAppStore((s) => s.answerQuestion);
  const reset = useAppStore((s) => s.resetQuizRun);
  const navigate = useNavigate();
  const quiz = quizzes.find((q) => q.id === activeQuizId) ?? quizzes[0];
  const [index, setIndex] = useState(0);
  const [submitted, setSubmitted] = useState(false);
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    if (!quiz) return;
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, [quiz]);

  const remaining = useMemo(() => {
    if (!quiz || !startedAt) return quiz ? quiz.durationMin * 60 : 0;
    const elapsed = Math.floor((now - startedAt) / 1000);
    return Math.max(0, quiz.durationMin * 60 - elapsed);
  }, [quiz, startedAt, now]);

  useEffect(() => {
    if (quiz && remaining === 0 && !submitted) setSubmitted(true);
  }, [remaining, submitted, quiz]);

  if (!quiz) {
    return (
      <AppShell>
        <PageHeader title="No paper in session" description="Generate a quiz first, then sit the paper." />
        <Button asChild>
          <Link to="/quiz">Open Quiz Studio</Link>
        </Button>
      </AppShell>
    );
  }

  const q = quiz.questions[index];
  const answered = Object.values(answers).filter((v) => v !== null && v !== undefined).length;
  const correct = quiz.questions.filter((item) => answers[item.id] === item.correctIndex).length;
  const pct = Math.round((answered / quiz.questions.length) * 100);
  const mm = String(Math.floor(remaining / 60)).padStart(2, "0");
  const ss = String(remaining % 60).padStart(2, "0");

  if (submitted) {
    const scorePct = Math.round((correct / quiz.questions.length) * 100);
    const weak = quiz.questions.filter((item) => answers[item.id] !== item.correctIndex);
    return (
      <AppShell>
        <PageHeader
          eyebrow="Instant evaluation"
          title={`Score ${scorePct}%`}
          description={`${correct} of ${quiz.questions.length} correct · ${quiz.title}`}
        />
        <Card className="mb-4 p-5">
          <p className="text-sm leading-relaxed text-muted-foreground">
            {scorePct >= 80
              ? "Strong command of this material. Consider writing a short teaching note for NSSTA peers on the items you missed."
              : scorePct >= 55
                ? "Solid core, with gaps on method detail. Revisit the source excerpt and retake after a focused hour."
                : "Treat this as a diagnostic. Enrol in the matching iGOT / NSSTA module and sit a shorter paper in a week."}
          </p>
        </Card>
        <div className="space-y-3">
          {quiz.questions.map((item, i) => {
            const picked = answers[item.id];
            const ok = picked === item.correctIndex;
            return (
              <Card key={item.id} className="p-4">
                <div className="flex items-center gap-2">
                  <Badge variant={ok ? "success" : "muted"}>{ok ? "Correct" : "Review"}</Badge>
                  <span className="text-xs text-muted-foreground">{item.topic} · {item.difficulty}</span>
                </div>
                <p className="mt-2 font-medium">
                  {i + 1}. {item.question}
                </p>
                <p className="mt-2 text-sm text-muted-foreground">{item.explanation}</p>
              </Card>
            );
          })}
        </div>
        {weak.length > 0 && (
          <p className="mt-4 text-sm text-muted-foreground">
            Focus next: {Array.from(new Set(weak.map((w) => w.topic))).join(", ")}.
          </p>
        )}
        <div className="mt-6 flex gap-2">
          <Button
            variant="outline"
            onClick={() => {
              reset();
              navigate({ to: "/quiz" });
            }}
          >
            Back to studio
          </Button>
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.14em] text-accent">{quiz.sourceName}</p>
          <h1 className="font-display text-2xl font-semibold">{quiz.title}</h1>
        </div>
        <div className="flex items-center gap-3 rounded-xl bg-card px-4 py-2 shadow-card">
          <span className="font-mono text-lg tabular-nums">
            {mm}:{ss}
          </span>
          <span className="text-xs text-muted-foreground">remaining</span>
        </div>
      </div>
      <Progress value={pct} className="mb-6" />
      <Card>
        <CardContent className="p-6">
          <p className="text-xs text-muted-foreground">
            Question {index + 1} of {quiz.questions.length} · {q.topic} · {q.difficulty}
          </p>
          <p className="mt-3 font-display text-xl font-semibold leading-snug">{q.question}</p>
          <div className="mt-5 grid gap-2">
            {q.options.map((opt, i) => {
              const selected = answers[q.id] === i;
              return (
                <button
                  key={opt}
                  type="button"
                  onClick={() => answerQuestion(q.id, i)}
                  className={cn(
                    "rounded-xl border px-4 py-3 text-left text-sm transition-colors",
                    selected
                      ? "border-accent bg-accent/10"
                      : "border-border bg-card hover:bg-muted/60",
                  )}
                >
                  <span className="mr-2 font-mono text-xs text-muted-foreground">
                    {String.fromCharCode(65 + i)}
                  </span>
                  {opt}
                </button>
              );
            })}
          </div>
          <div className="mt-6 flex justify-between">
            <Button variant="outline" disabled={index === 0} onClick={() => setIndex((i) => i - 1)}>
              Previous
            </Button>
            {index < quiz.questions.length - 1 ? (
              <Button onClick={() => setIndex((i) => i + 1)}>Next</Button>
            ) : (
              <Button variant="accent" onClick={() => setSubmitted(true)}>
                Submit paper
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </AppShell>
  );
}
