import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { AppShell, PageHeader } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input, Textarea } from "@/components/ui/input";
import { Badge, Label, Switch } from "@/components/ui/misc";
import { useAppStore } from "@/lib/store";
import { downloadText } from "@/lib/utils";
import type { QuizQuestion } from "@/lib/types";

export const Route = createFileRoute("/quiz/trainer")({ component: TrainerDesk });

function TrainerDesk() {
  const quizzes = useAppStore((s) => s.quizzes);
  const updateQuestion = useAppStore((s) => s.updateQuestion);
  const setQuizStatus = useAppStore((s) => s.setQuizStatus);
  const deleteQuiz = useAppStore((s) => s.deleteQuiz);
  const [activeId, setActiveId] = useState<string | null>(quizzes[0]?.id ?? null);
  const quiz = quizzes.find((q) => q.id === activeId) ?? quizzes[0];

  function exportQuiz() {
    if (!quiz) return;
    downloadText(
      `${quiz.title.replace(/\s+/g, "-").toLowerCase()}.json`,
      JSON.stringify(quiz, null, 2),
      "application/json",
    );
    toast.success("Question paper exported as JSON.");
  }

  return (
    <AppShell>
      <PageHeader
        eyebrow="NSSTA / iGOT faculty"
        title="Trainer desk"
        description="Edit, approve, publish and export generated questions before they reach a cohort."
        actions={
          quiz ? (
            <div className="flex flex-wrap gap-2">
              <Button variant="outline" onClick={exportQuiz}>
                Export JSON
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setQuizStatus(quiz.id, "approved");
                  toast.success("Paper approved.");
                }}
              >
                Approve
              </Button>
              <Button
                variant="accent"
                onClick={() => {
                  setQuizStatus(quiz.id, "published");
                  toast.success("Published to the learner catalogue.");
                }}
              >
                Publish
              </Button>
            </div>
          ) : undefined
        }
      />

      {quizzes.length === 0 || !quiz ? (
        <Card className="px-6 py-16 text-center">
          <p className="font-display text-xl font-semibold">Nothing to review</p>
          <p className="mt-2 text-sm text-muted-foreground">
            Generate a paper in Quiz Studio. Drafts appear here for faculty edit-and-approve.
          </p>
        </Card>
      ) : (
        <div className="grid gap-4 lg:grid-cols-[16rem_1fr]">
          <Card className="h-fit p-3">
            {quizzes.map((q) => (
              <button
                key={q.id}
                type="button"
                onClick={() => setActiveId(q.id)}
                className={`mb-1 w-full rounded-xl px-3 py-2 text-left text-sm ${
                  q.id === quiz.id ? "bg-muted font-medium" : "hover:bg-muted/60"
                }`}
              >
                <span className="block truncate">{q.title}</span>
                <span className="text-[11px] text-muted-foreground">{q.status}</span>
              </button>
            ))}
          </Card>
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-2">
              <Badge variant="navy">{quiz.questions.length} items</Badge>
              <Badge>{quiz.difficulty}</Badge>
              <Badge variant="accent">{quiz.status}</Badge>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => {
                  deleteQuiz(quiz.id);
                  setActiveId(null);
                }}
              >
                Delete draft
              </Button>
            </div>
            {quiz.questions.map((item, i) => (
              <QuestionEditor
                key={item.id}
                index={i}
                question={item}
                onChange={(next) => updateQuestion(quiz.id, next)}
              />
            ))}
          </div>
        </div>
      )}
    </AppShell>
  );
}

function QuestionEditor({
  question,
  index,
  onChange,
}: {
  question: QuizQuestion;
  index: number;
  onChange: (q: QuizQuestion) => void;
}) {
  return (
    <Card className="p-5">
      <div className="mb-3 flex items-center justify-between gap-3">
        <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
          Item {index + 1} · {question.topic} · {question.difficulty}
        </p>
        <label className="flex items-center gap-2 text-xs">
          Approved
          <Switch
            checked={Boolean(question.approved)}
            onCheckedChange={(v) => onChange({ ...question, approved: v })}
          />
        </label>
      </div>
      <Label>Stem</Label>
      <Textarea
        className="mt-1"
        value={question.question}
        onChange={(e) => onChange({ ...question, question: e.target.value })}
      />
      <div className="mt-3 grid gap-2">
        {question.options.map((opt, i) => (
          <div key={i} className="flex items-center gap-2">
            <input
              type="radio"
              name={`correct-${question.id}`}
              checked={question.correctIndex === i}
              onChange={() => onChange({ ...question, correctIndex: i })}
              className="size-4 accent-[var(--accent)]"
              aria-label={`Mark option ${i + 1} correct`}
            />
            <Input
              value={opt}
              onChange={(e) => {
                const options = [...question.options];
                options[i] = e.target.value;
                onChange({ ...question, options });
              }}
            />
          </div>
        ))}
      </div>
      <Label className="mt-3 block">Explanation</Label>
      <Textarea
        className="mt-1"
        value={question.explanation}
        onChange={(e) => onChange({ ...question, explanation: e.target.value })}
      />
    </Card>
  );
}
