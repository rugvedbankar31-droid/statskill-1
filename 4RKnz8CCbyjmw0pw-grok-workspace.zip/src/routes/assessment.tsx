import { useState, type ReactNode } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { AppShell, PageHeader } from "@/components/layout";
import { DomainRadar, GapBars, Heatmap, ScoreRing } from "@/components/charts";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input, Textarea } from "@/components/ui/input";
import { Label, Badge } from "@/components/ui/misc";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  CAREER_PATHS,
  DESIGNATIONS,
  JOB_ROLES,
  computeCompetencies,
  domainAverages,
  overallScore,
  recommendCourses,
} from "@/lib/data";
import { competencyNarrativeFn } from "@/lib/ai";
import { useAppStore } from "@/lib/store";
import type { AssessmentProfile } from "@/lib/types";

export const Route = createFileRoute("/assessment")({ component: AssessmentPage });

function AssessmentPage() {
  const profile = useAppStore((s) => s.profile);
  const setProfile = useAppStore((s) => s.setProfile);
  const saveAssessment = useAppStore((s) => s.saveAssessment);
  const result = useAppStore((s) => s.assessmentResult);
  const enrol = useAppStore((s) => s.enrol);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);

  const live = result?.competencies ?? computeCompetencies(profile);
  const domains = domainAverages(live);
  const score = overallScore(live);
  const recs = recommendCourses(live, 4);

  function update<K extends keyof AssessmentProfile>(key: K, value: AssessmentProfile[K]) {
    setProfile({ ...profile, [key]: value });
  }

  function validate() {
    const next: Record<string, string> = {};
    if (!profile.designation) next.designation = "Select a designation.";
    if (!profile.jobRole) next.jobRole = "Select a job role.";
    if (!profile.education.trim()) next.education = "Education is required.";
    if (!profile.currentAssignment.trim()) next.currentAssignment = "Describe the current assignment.";
    if (profile.experienceYears < 0 || profile.experienceYears > 40) next.experienceYears = "Enter 0–40 years.";
    setErrors(next);
    return Object.keys(next).length === 0;
  }

  async function run(withAi: boolean) {
    if (!validate()) {
      toast.error("Please complete the highlighted fields.");
      return;
    }
    saveAssessment();
    if (!withAi) {
      toast.success("Competency heatmap updated from role and career path.");
      return;
    }
    setBusy(true);
    try {
      const comps = computeCompetencies(profile);
      const gaps = [...comps]
        .sort((a, b) => b.target - b.score - (a.target - a.score))
        .slice(0, 5)
        .map((c) => `${c.name}: ${c.score}/${c.target}`)
        .join("; ");
      const res = await competencyNarrativeFn({
        data: {
          profileSummary: `${profile.designation}, ${profile.jobRole}, ${profile.department}. Education: ${profile.education}. Experience: ${profile.experienceYears} years. Trainings: ${profile.previousTrainings}. Assignment: ${profile.currentAssignment}. Career path: ${profile.careerPath}. Gaps: ${gaps}.`,
        },
      });
      if (!res.ok) {
        toast.error(res.error);
        saveAssessment();
      } else {
        saveAssessment(res.text);
        toast.success("AI briefing added to the competency file.");
      }
    } catch {
      toast.error("Could not generate the AI briefing.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <AppShell>
      <PageHeader
        eyebrow="Competency engine"
        title="AI competency assessment"
        description="Capture the officer file, then generate a heatmap, radar and skill-gap recommendations against the chosen career path."
      />

      <div className="grid gap-6 lg:grid-cols-[0.95fr_1.05fr]">
        <Card>
          <CardHeader>
            <CardTitle>Officer profile</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Field label="Designation" error={errors.designation}>
              <Select value={profile.designation} onValueChange={(v) => update("designation", v)}>
                <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                <SelectContent>
                  {DESIGNATIONS.map((d) => (
                    <SelectItem key={d} value={d}>{d}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Department">
              <Input value={profile.department} onChange={(e) => update("department", e.target.value)} />
            </Field>
            <Field label="Job role" error={errors.jobRole}>
              <Select value={profile.jobRole} onValueChange={(v) => update("jobRole", v)}>
                <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                <SelectContent>
                  {JOB_ROLES.map((d) => (
                    <SelectItem key={d} value={d}>{d}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Education" error={errors.education}>
              <Input value={profile.education} onChange={(e) => update("education", e.target.value)} />
            </Field>
            <Field label="Experience (years)" error={errors.experienceYears}>
              <Input
                type="number"
                min={0}
                max={40}
                value={profile.experienceYears}
                onChange={(e) => update("experienceYears", Number(e.target.value))}
              />
            </Field>
            <Field label="Previous trainings">
              <Textarea
                value={profile.previousTrainings}
                onChange={(e) => update("previousTrainings", e.target.value)}
              />
            </Field>
            <Field label="Current assignment" error={errors.currentAssignment}>
              <Textarea
                value={profile.currentAssignment}
                onChange={(e) => update("currentAssignment", e.target.value)}
              />
            </Field>
            <Field label="Future career path">
              <Select value={profile.careerPath} onValueChange={(v) => update("careerPath", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {CAREER_PATHS.map((d) => (
                    <SelectItem key={d} value={d}>{d}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <div className="flex flex-col gap-2 sm:flex-row">
              <Button onClick={() => void run(false)} variant="outline">
                Update heatmap
              </Button>
              <Button onClick={() => void run(true)} variant="accent" disabled={busy}>
                {busy ? "Writing briefing…" : "Generate AI briefing"}
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-4">
          <Card>
            <CardContent className="flex flex-col items-center gap-4 p-6 sm:flex-row">
              <ScoreRing value={score} />
              <div className="flex-1">
                <p className="text-xs font-semibold uppercase tracking-[0.14em] text-accent">Composite</p>
                <h2 className="font-display text-2xl font-semibold">Competency file</h2>
                <p className="mt-1 text-sm text-muted-foreground">
                  Targets rise when you pick a specialist career path. Saffron is current score; indigo is the role bar.
                </p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Domain radar</CardTitle>
            </CardHeader>
            <CardContent>
              <DomainRadar data={domains} />
            </CardContent>
          </Card>
        </div>
      </div>

      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Competency heatmap</CardTitle>
        </CardHeader>
        <CardContent>
          <Heatmap items={live} />
        </CardContent>
      </Card>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Priority gaps</CardTitle>
          </CardHeader>
          <CardContent>
            <GapBars items={live} />
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Linked programmes</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {recs.map((c) => (
              <div key={c.id} className="flex items-center justify-between gap-3 rounded-xl bg-muted/60 p-3">
                <div>
                  <p className="text-sm font-medium">{c.title}</p>
                  <p className="text-xs text-muted-foreground">
                    {c.provider} · {c.durationHours}h
                  </p>
                </div>
                <Button size="sm" variant="outline" onClick={() => { enrol(c.id); toast.success(`Enrolled in ${c.title}`); }}>
                  Enrol
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {result?.narrative && (
        <Card className="mt-6">
          <CardHeader className="flex-row items-center justify-between">
            <CardTitle>AI briefing</CardTitle>
            <Badge variant="accent">Generated</Badge>
          </CardHeader>
          <CardContent>
            <p className="whitespace-pre-wrap text-sm leading-relaxed text-muted-foreground">
              {result.narrative}
            </p>
          </CardContent>
        </Card>
      )}
    </AppShell>
  );
}

function Field({
  label,
  error,
  children,
}: {
  label: string;
  error?: string;
  children: ReactNode;
}) {
  return (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      {children}
      {error && <p className="text-xs text-destructive">{error}</p>}
    </div>
  );
}
