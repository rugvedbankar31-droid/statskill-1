import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Award, BookOpen, Clock3, GraduationCap } from "lucide-react";
import { AppShell, PageHeader } from "@/components/layout";
import { GapBars, ScoreRing } from "@/components/charts";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge, Progress } from "@/components/ui/misc";
import { COURSES, UPCOMING, domainAverages, recommendCourses } from "@/lib/data";
import { useAppStore } from "@/lib/store";
import { t } from "@/lib/i18n";
import { overallScore } from "@/lib/data";
import { COMPETENCIES } from "@/lib/data";

export const Route = createFileRoute("/dashboard")({ component: DashboardPage });

function DashboardPage() {
  const user = useAppStore((s) => s.user);
  const lang = useAppStore((s) => s.lang);
  const enrolments = useAppStore((s) => s.enrolments);
  const result = useAppStore((s) => s.assessmentResult);
  const enrol = useAppStore((s) => s.enrol);
  const advance = useAppStore((s) => s.advanceCourse);
  if (!user) return null;

  const competencies = result?.competencies ?? COMPETENCIES;
  const score = result ? overallScore(competencies) : user.competencyScore;
  const domains = domainAverages(competencies);
  const recommended = recommendCourses(competencies, 4);
  const roadmap = COURSES.filter((c) =>
    enrolments.some((e) => e.courseId === c.id) || recommended.some((r) => r.id === c.id),
  ).slice(0, 5);

  return (
    <AppShell>
      <PageHeader
        eyebrow={user.cadre}
        title={`${t(lang, "welcome")}, ${user.name.split(" ")[0]}`}
        description={`${user.designation} · ${user.department}`}
      />

      <div className="grid gap-4 lg:grid-cols-[1.2fr_0.8fr]">
        <Card className="overflow-hidden">
          <CardContent className="grid gap-6 p-6 sm:grid-cols-[auto_1fr] sm:items-center">
            <ScoreRing value={score} />
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.14em] text-accent">
                {t(lang, "competency")}
              </p>
              <h2 className="mt-1 font-display text-2xl font-semibold">Role-fit snapshot</h2>
              <p className="mt-2 text-sm text-muted-foreground">
                Profile {user.profileCompletion}% complete. {user.education}.
              </p>
              <div className="mt-4">
                <div className="mb-1 flex justify-between text-xs text-muted-foreground">
                  <span>Profile completion</span>
                  <span className="tabular-nums">{user.profileCompletion}%</span>
                </div>
                <Progress value={user.profileCompletion} />
              </div>
              <Button asChild variant="outline" size="sm" className="mt-4">
                <Link to="/assessment">Update assessment</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
        <div className="grid grid-cols-2 gap-3">
          {[
            { icon: Clock3, label: t(lang, "hours"), value: user.learningHours },
            { icon: Award, label: t(lang, "certs"), value: user.certificates },
            { icon: BookOpen, label: t(lang, "modules"), value: user.completedModules },
            { icon: GraduationCap, label: t(lang, "upcoming"), value: user.upcomingAssessments },
          ].map((s) => (
            <Card key={s.label} className="p-4">
              <s.icon className="size-4 text-indigo" />
              <p className="mt-3 font-display text-2xl font-semibold tabular-nums">{s.value}</p>
              <p className="text-xs text-muted-foreground">{s.label}</p>
            </Card>
          ))}
        </div>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Skill-gap insights</CardTitle>
            <p className="text-sm text-muted-foreground">
              Statistical, technical, digital governance and behavioural domains.
            </p>
          </CardHeader>
          <CardContent>
            <div className="mb-5 grid grid-cols-2 gap-2 sm:grid-cols-4">
              {domains.map((d) => (
                <div key={d.domain} className="rounded-xl bg-muted/70 p-3">
                  <p className="text-[11px] text-muted-foreground">{d.label}</p>
                  <p className="font-display text-xl tabular-nums">{d.score}</p>
                </div>
              ))}
            </div>
            <GapBars items={competencies} />
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Upcoming</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {UPCOMING.map((u) => (
              <div key={u.id} className="rounded-xl border border-border p-3">
                <p className="text-xs uppercase tracking-wide text-accent">{u.type}</p>
                <p className="mt-1 font-medium">{u.title}</p>
                <p className="text-xs text-muted-foreground">
                  {u.date} · {u.venue}
                </p>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <div className="mt-6">
        <div className="mb-3 flex items-end justify-between">
          <h2 className="font-display text-2xl font-semibold">{t(lang, "roadmap")}</h2>
          <Button asChild variant="link" size="sm">
            <Link to="/courses">Full catalogue</Link>
          </Button>
        </div>
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {roadmap.map((course) => {
            const enr = enrolments.find((e) => e.courseId === course.id);
            return (
              <Card key={course.id} className="flex flex-col p-5">
                <div className="flex items-center justify-between gap-2">
                  <Badge variant="navy">{course.provider}</Badge>
                  <span className="text-xs text-muted-foreground">{course.level}</span>
                </div>
                <h3 className="mt-3 font-semibold leading-snug">{course.title}</h3>
                <p className="mt-1 text-xs text-muted-foreground">
                  {course.durationHours}h · {course.modules} modules · {course.skills.join(" · ")}
                </p>
                {enr && (
                  <div className="mt-3">
                    <Progress value={enr.progress} />
                    <p className="mt-1 text-[11px] text-muted-foreground tabular-nums">{enr.progress}% · {enr.status.replace("_", " ")}</p>
                  </div>
                )}
                <div className="mt-4 flex gap-2">
                  {enr ? (
                    <Button size="sm" variant="accent" onClick={() => advance(course.id)}>
                      {enr.status === "completed" ? "Revise" : t(lang, "continue")}
                    </Button>
                  ) : (
                    <Button
                      size="sm"
                      variant="accent"
                      onClick={() => enrol(course.id)}
                    >
                      {t(lang, "start")}
                    </Button>
                  )}
                </div>
              </Card>
            );
          })}
        </div>
      </div>

      <Card className="mt-6">
        <CardHeader className="flex-row items-center justify-between">
          <CardTitle>{t(lang, "recommended")}</CardTitle>
          <Link to="/courses" className="text-sm text-indigo">
            iGOT Karmayogi
            <ArrowRight className="ml-1 inline size-3.5" />
          </Link>
        </CardHeader>
        <CardContent className="grid gap-3 sm:grid-cols-2">
          {recommended.map((c) => (
            <div key={c.id} className="flex items-start justify-between gap-3 rounded-xl bg-muted/60 p-4">
              <div>
                <p className="font-medium">{c.title}</p>
                <p className="text-xs text-muted-foreground">
                  {c.provider} · {c.durationHours}h · {c.level}
                </p>
              </div>
              <Button size="sm" variant="outline" onClick={() => enrol(c.id)}>
                {t(lang, "enrol")}
              </Button>
            </div>
          ))}
        </CardContent>
      </Card>
    </AppShell>
  );
}
