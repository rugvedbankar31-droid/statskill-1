import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowRight,
  BarChart3,
  BookOpen,
  Brain,
  CheckCircle2,
  Cloud,
  Gauge,
  Lock,
  Shield,
  TrendingUp,
} from "lucide-react";
import { MarketingNav } from "@/components/layout";
import { LogoMark } from "@/components/logo";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/misc";
import { useAppStore } from "@/lib/store";
import { t } from "@/lib/i18n";
import { useHydrated } from "@/lib/utils";

export const Route = createFileRoute("/")({ component: Home });

const FEATURES = [
  { key: "feat1" as const, body: "feat1b" as const, icon: Gauge },
  { key: "feat2" as const, body: "feat2b" as const, icon: BookOpen },
  { key: "feat3" as const, body: "feat3b" as const, icon: Brain },
  { key: "feat4" as const, body: "feat4b" as const, icon: BarChart3 },
];

const STEPS = [
  {
    n: "01",
    title: "Assess the officer, not a generic role",
    body: "Designation, assignment and career path drive a 14-competency heatmap across statistical, technical, digital and behavioural domains.",
  },
  {
    n: "02",
    title: "Open a personalised iGOT / NSSTA path",
    body: "Recommendations bind to live gaps — Python for NAD compilers, sampling for FOD, DPDP for divisions holding unit-level files.",
  },
  {
    n: "03",
    title: "Turn training material into quizzes",
    body: "Upload a PLFS note or SNA brief. StatSkill drafts tagged MCQs, trainers approve, learners sit a timed paper with explanations.",
  },
];

function Home() {
  const lang = useAppStore((s) => s.lang);
  const user = useAppStore((s) => s.user);
  const hydrated = useHydrated();
  const authed = hydrated && Boolean(user);

  return (
    <div className="min-h-screen bg-background">
      <MarketingNav />
      <section className="relative overflow-hidden bg-navy text-on-navy">
        <div className="hero-grid pointer-events-none absolute inset-0 opacity-70" />
        <div className="pointer-events-none absolute -right-24 -top-24 size-80 rounded-full bg-indigo/50 blur-3xl" />
        <div className="relative mx-auto grid max-w-6xl gap-12 px-4 py-16 sm:px-6 lg:grid-cols-[1.1fr_0.9fr] lg:py-24">
          <div className="stagger-in">
            <Badge variant="accent" className="border-0 bg-saffron/15 text-saffron">
              Mission Karmayogi · NSSTA TPAC · MoSPI
            </Badge>
            <h1 className="mt-5 font-display text-4xl font-semibold leading-[1.12] tracking-tight sm:text-5xl lg:text-[3.4rem]">
              {t(lang, "heroTitle")}
            </h1>
            <p className="mt-5 max-w-xl text-base leading-relaxed text-on-navy/75 sm:text-lg">
              {t(lang, "heroBody")}
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Button asChild variant="accent" size="lg" className="pr-3.5">
                <Link to={authed ? "/dashboard" : "/login"}>
                  {t(lang, "ctaPath")}
                  <ArrowRight className="size-4" />
                </Link>
              </Button>
              <Button
                asChild
                variant="outline"
                size="lg"
                className="border-on-navy/20 bg-transparent text-on-navy hover:bg-on-navy/10"
              >
                <Link to={authed && (user?.role === "admin" || user?.role === "superadmin") ? "/admin" : "/login"}>
                  {t(lang, "ctaAdmin")}
                </Link>
              </Button>
            </div>
            <dl className="mt-10 grid grid-cols-3 gap-4 border-t border-on-navy/10 pt-6 text-sm">
              <div>
                <dt className="text-on-navy/55">Competencies</dt>
                <dd className="mt-1 font-display text-2xl font-semibold tabular-nums">14</dd>
              </div>
              <div>
                <dt className="text-on-navy/55">Catalogue</dt>
                <dd className="mt-1 font-display text-2xl font-semibold tabular-nums">14</dd>
              </div>
              <div>
                <dt className="text-on-navy/55">Cadres</dt>
                <dd className="mt-1 font-display text-2xl font-semibold">ISS · SSS</dd>
              </div>
            </dl>
          </div>
          <HeroPreview />
        </div>
      </section>

      <section className="border-b border-border bg-card/60">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-4 px-4 py-4 text-xs font-medium uppercase tracking-[0.16em] text-muted-foreground sm:px-6">
          <span>MoSPI</span>
          <span>NSO</span>
          <span>NSSTA</span>
          <span>iGOT Karmayogi</span>
          <span>Mission Karmayogi</span>
          <span>NIC Cloud ready</span>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
        <p className="text-xs font-semibold uppercase tracking-[0.16em] text-accent">Platform</p>
        <h2 className="mt-2 font-display text-3xl font-semibold">{t(lang, "featuresTitle")}</h2>
        <div className="mt-8 grid gap-4 sm:grid-cols-2">
          {FEATURES.map((f) => {
            const Icon = f.icon;
            return (
              <Card key={f.key} className="glass-panel p-6 transition-shadow duration-200 hover:shadow-lift">
                <div className="flex size-10 items-center justify-center rounded-xl bg-indigo/10 text-indigo">
                  <Icon className="size-5" />
                </div>
                <h3 className="mt-4 font-display text-xl font-semibold">{t(lang, f.key)}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{t(lang, f.body)}</p>
              </Card>
            );
          })}
        </div>
      </section>

      <section className="bg-card/50 py-16">
        <div className="mx-auto grid max-w-6xl gap-10 px-4 sm:px-6 lg:grid-cols-[0.9fr_1.1fr]">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.16em] text-accent">How it works</p>
            <h2 className="mt-2 font-display text-3xl font-semibold">Three steps from role to ready</h2>
            <p className="mt-3 text-sm text-muted-foreground">
              Built as a learning product, not a circular. Officers keep a living competency file that follows them from NSSTA induction to DDG.
            </p>
          </div>
          <ol className="space-y-4">
            {STEPS.map((s) => (
              <li key={s.n} className="flex gap-4 rounded-2xl bg-card p-5 shadow-card">
                <span className="font-display text-2xl text-accent">{s.n}</span>
                <div>
                  <h3 className="font-semibold">{s.title}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{s.body}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
        <div className="grid gap-4 sm:grid-cols-3">
          {[
            { icon: Lock, title: "Role-based access", body: "Learner, Trainer, Administrator, Super Admin — FRAC-aligned views." },
            { icon: Cloud, title: "Government-cloud ready", body: "Designed for NIC / MeghRaj hosting with audit-friendly data sharing marks." },
            { icon: Shield, title: "SSO with iGOT identity", body: "Directory login experience mapped to MoSPI and State DES officers." },
          ].map((item) => (
            <Card key={item.title} className="p-5">
              <item.icon className="size-5 text-indigo" />
              <h3 className="mt-3 font-semibold">{item.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{item.body}</p>
            </Card>
          ))}
        </div>
      </section>

      <section className="px-4 pb-16 sm:px-6">
        <div className="mx-auto flex max-w-6xl flex-col items-start justify-between gap-6 rounded-3xl bg-navy px-8 py-10 text-on-navy sm:flex-row sm:items-center">
          <div>
            <h2 className="font-display text-3xl font-semibold">Ready for the next survey cycle?</h2>
            <p className="mt-2 max-w-lg text-sm text-on-navy/70">
              Sign in as a learner, trainer or administrator to tour competency analytics, the iGOT catalogue and quiz studio.
            </p>
          </div>
          <Button asChild variant="accent" size="lg">
            <Link to="/login">
              Enter the platform
              <ArrowRight className="size-4" />
            </Link>
          </Button>
        </div>
      </section>

      <footer className="border-t border-border px-4 py-8 text-sm text-muted-foreground sm:px-6">
        <div className="mx-auto flex max-w-6xl flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-2">
            <LogoMark className="size-7" />
            <span>StatSkill AI · Skill intelligence for official statistics</span>
          </div>
          <p>English · हिन्दी · regional-language ready</p>
        </div>
      </footer>
    </div>
  );
}

function HeroPreview() {
  return (
    <div className="relative hidden lg:block">
      <div className="rounded-3xl border border-on-navy/15 bg-indigo/35 p-4 backdrop-blur-md">
        <div className="flex items-center justify-between px-2 py-2">
          <div className="flex items-center gap-2">
            <LogoMark className="size-7" />
            <div>
              <p className="text-xs font-semibold text-on-navy">Priya Sharma</p>
              <p className="text-[10px] text-on-navy/60">Joint Director · NAD, NSO</p>
            </div>
          </div>
          <span className="rounded-full bg-saffron/20 px-2 py-0.5 text-[10px] font-medium text-saffron">
            Score 64
          </span>
        </div>
        <div className="mt-2 grid grid-cols-2 gap-2">
          {[
            ["Python", 48, 75],
            ["AI / ML", 32, 70],
            ["National Accounts", 86, 92],
            ["Data Privacy", 61, 82],
          ].map(([name, score, target]) => (
            <div key={String(name)} className="rounded-xl bg-on-navy/8 p-3">
              <p className="text-[11px] text-on-navy/70">{name}</p>
              <p className="mt-1 font-display text-xl text-on-navy">{score}</p>
              <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-on-navy/10">
                <div className="h-full rounded-full bg-saffron" style={{ width: `${score}%` }} />
              </div>
              <p className="mt-1 text-[10px] text-on-navy/50">target {target}</p>
            </div>
          ))}
        </div>
        <div className="mt-2 flex items-center gap-2 rounded-xl bg-on-navy/8 px-3 py-2 text-xs text-on-navy/80">
          <CheckCircle2 className="size-3.5 text-saffron" />
          Next: Python for Official Statistics · iGOT · 16h
        </div>
      </div>
      <div className="absolute -bottom-6 -left-6 hidden rounded-2xl bg-card p-3 text-foreground shadow-lift xl:block">
        <div className="flex items-center gap-2 text-xs">
          <TrendingUp className="size-3.5 text-accent" />
          High demand for Python and AI/ML
        </div>
      </div>
    </div>
  );
}
