import { cn } from "@/lib/utils";

export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={cn("size-8", className)} aria-hidden>
      <rect width="32" height="32" rx="8" className="fill-navy dark:fill-indigo" />
      <rect x="6" y="18" width="4.2" height="8" rx="1" className="fill-saffron" />
      <rect x="12.2" y="13" width="4.2" height="13" rx="1" className="fill-card" />
      <rect x="18.4" y="8" width="4.2" height="18" rx="1" className="fill-card" />
      <circle cx="25.2" cy="9.2" r="2.6" className="fill-saffron" />
    </svg>
  );
}

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <span className="flex items-center gap-2.5">
      <LogoMark />
      {!compact && (
        <span className="flex flex-col leading-none">
          <span className="text-[15px] font-semibold tracking-tight text-foreground">
            StatSkill AI
          </span>
          <span className="mt-0.5 text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
            Official Statistics
          </span>
        </span>
      )}
    </span>
  );
}
