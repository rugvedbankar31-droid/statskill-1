import type { ReactNode } from "react";
import { useHydrated } from "@/lib/utils";
import { Skeleton } from "@/components/ui/misc";
import type { Competency, CompetencyDomain, WorkforceMember } from "@/lib/types";
import { DOMAIN_LABEL } from "@/lib/data";
import {
  PolarAngleAxis,
  PolarGrid,
  PolarRadiusAxis,
  Radar,
  RadarChart,
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as RTooltip,
  Legend,
  Cell,
} from "recharts";

export function ClientOnly({
  children,
  fallback,
}: {
  children: ReactNode;
  fallback?: ReactNode;
}) {
  const hydrated = useHydrated();
  if (!hydrated) return fallback ?? <Skeleton className="h-56 w-full" />;
  return <>{children}</>;
}

export function ScoreRing({ value, size = 148 }: { value: number; size?: number }) {
  const r = 54;
  const c = 2 * Math.PI * r;
  const offset = c - (Math.min(100, Math.max(0, value)) / 100) * c;
  return (
    <svg width={size} height={size} viewBox="0 0 128 128" className="overflow-visible">
      <circle
        cx="64"
        cy="64"
        r={r}
        fill="none"
        className="stroke-muted"
        strokeWidth="10"
      />
      <circle
        cx="64"
        cy="64"
        r={r}
        fill="none"
        className="stroke-accent"
        strokeWidth="10"
        strokeLinecap="round"
        strokeDasharray={c}
        strokeDashoffset={offset}
        transform="rotate(-90 64 64)"
      />
      <text
        x="64"
        y="60"
        textAnchor="middle"
        className="fill-foreground font-sans"
        style={{ fontSize: 28, fontWeight: 600 }}
      >
        {value}
      </text>
      <text
        x="64"
        y="78"
        textAnchor="middle"
        className="fill-muted-foreground font-sans"
        style={{ fontSize: 11, fontWeight: 500 }}
      >
        / 100
      </text>
    </svg>
  );
}

const tooltipStyle = {
  background: "var(--card)",
  border: "1px solid var(--border)",
  borderRadius: 12,
  color: "var(--foreground)",
  fontSize: 12,
};

export function DomainRadar({ data }: { data: { label: string; score: number; target: number }[] }) {
  return (
    <ClientOnly>
      <div className="h-64 w-full">
        <ResponsiveContainer>
          <RadarChart data={data}>
            <PolarGrid stroke="var(--border)" />
            <PolarAngleAxis dataKey="label" tick={{ fill: "var(--muted-foreground)", fontSize: 11 }} />
            <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
            <Radar dataKey="target" stroke="var(--indigo)" fill="var(--indigo)" fillOpacity={0.08} />
            <Radar dataKey="score" stroke="var(--accent)" fill="var(--accent)" fillOpacity={0.28} />
            <Legend wrapperStyle={{ fontSize: 12 }} />
            <RTooltip contentStyle={tooltipStyle} />
          </RadarChart>
        </ResponsiveContainer>
      </div>
    </ClientOnly>
  );
}

export function Heatmap({ items }: { items: Competency[] }) {
  function tone(score: number) {
    if (score >= 80) return "bg-success/20 text-success";
    if (score >= 60) return "bg-indigo/15 text-indigo";
    if (score >= 45) return "bg-warning/18 text-warning";
    return "bg-destructive/12 text-destructive";
  }
  return (
    <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4">
      {items.map((c) => (
        <div
          key={c.id}
          className={`rounded-xl px-3 py-3 ${tone(c.score)}`}
        >
          <p className="text-[11px] font-medium uppercase tracking-wide opacity-80">
            {DOMAIN_LABEL[c.domain]}
          </p>
          <p className="mt-1 text-sm font-semibold leading-snug">{c.name}</p>
          <p className="mt-2 font-mono text-lg tabular-nums">{c.score}</p>
          <p className="text-[11px] opacity-80">target {c.target}</p>
        </div>
      ))}
    </div>
  );
}

export function GapBars({ items }: { items: Competency[] }) {
  const gaps = [...items].sort((a, b) => b.target - b.score - (a.target - a.score)).slice(0, 6);
  return (
    <div className="space-y-3">
      {gaps.map((c) => {
        const gap = Math.max(0, c.target - c.score);
        return (
          <div key={c.id}>
            <div className="mb-1 flex items-baseline justify-between text-sm">
              <span className="font-medium">{c.name}</span>
              <span className="tabular-nums text-muted-foreground">
                {c.score} · gap {gap}
              </span>
            </div>
            <div className="relative h-2 overflow-hidden rounded-full bg-muted">
              <div
                className="absolute inset-y-0 left-0 rounded-full bg-indigo/35"
                style={{ width: `${c.target}%` }}
              />
              <div
                className="absolute inset-y-0 left-0 rounded-full bg-accent"
                style={{ width: `${c.score}%` }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
}

export function WorkforceBars({ rows }: { rows: WorkforceMember[] }) {
  const byDept = new Map<string, { name: string; score: number; n: number; completion: number }>();
  for (const r of rows) {
    const cur = byDept.get(r.department) ?? { name: r.department, score: 0, n: 0, completion: 0 };
    cur.score += r.score;
    cur.completion += r.completionRate;
    cur.n += 1;
    byDept.set(r.department, cur);
  }
  const data = [...byDept.values()].map((d) => ({
    name: d.name.replace(" Division", "").replace(" & Research", "").replace(" & Innovation", ""),
    score: Math.round(d.score / d.n),
    completion: Math.round(d.completion / d.n),
  }));
  return (
    <ClientOnly>
      <div className="h-72 w-full">
        <ResponsiveContainer>
          <BarChart data={data} margin={{ left: 0, right: 8, top: 8, bottom: 24 }}>
            <CartesianGrid stroke="var(--border)" vertical={false} />
            <XAxis dataKey="name" tick={{ fill: "var(--muted-foreground)", fontSize: 10 }} interval={0} angle={-22} textAnchor="end" height={48} />
            <YAxis domain={[0, 100]} tick={{ fill: "var(--muted-foreground)", fontSize: 11 }} />
            <RTooltip contentStyle={tooltipStyle} />
            <Legend />
            <Bar dataKey="score" name="Competency" fill="var(--indigo)" radius={[6, 6, 0, 0]} />
            <Bar dataKey="completion" name="Completion %" fill="var(--accent)" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </ClientOnly>
  );
}

export function SkillDistribution({ rows }: { rows: WorkforceMember[] }) {
  const domains: CompetencyDomain[] = ["statistical", "technical", "digital", "behavioural"];
  const data = domains.map((d) => ({
    name: DOMAIN_LABEL[d],
    value: Math.round(rows.reduce((s, r) => s + r.domainScores[d], 0) / Math.max(1, rows.length)),
  }));
  const colors = ["var(--indigo)", "var(--accent)", "var(--success)", "var(--navy)"];
  return (
    <ClientOnly>
      <div className="h-64 w-full">
        <ResponsiveContainer>
          <BarChart data={data} layout="vertical" margin={{ left: 16, right: 16 }}>
            <CartesianGrid stroke="var(--border)" horizontal={false} />
            <XAxis type="number" domain={[0, 100]} tick={{ fill: "var(--muted-foreground)", fontSize: 11 }} />
            <YAxis type="category" dataKey="name" width={128} tick={{ fill: "var(--foreground)", fontSize: 12 }} />
            <RTooltip contentStyle={tooltipStyle} />
            <Bar dataKey="value" name="Mean score" radius={[0, 8, 8, 0]}>
              {data.map((_, i) => (
                <Cell key={data[i].name} fill={colors[i]} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </ClientOnly>
  );
}
