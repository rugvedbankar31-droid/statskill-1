import { useEffect, type ReactNode } from "react";
import { Toaster } from "sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAppStore } from "@/lib/store";

export function AppProviders({ children }: { children: ReactNode }) {
  const theme = useAppStore((s) => s.theme);
  const lang = useAppStore((s) => s.lang);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
    localStorage.setItem("statskill-theme", theme);
  }, [theme]);

  useEffect(() => {
    document.documentElement.lang = lang;
  }, [lang]);

  return (
    <TooltipProvider delayDuration={250}>
      {children}
      <Toaster
        position="top-center"
        richColors
        closeButton
        theme={theme}
        toastOptions={{
          className: "font-sans",
        }}
      />
    </TooltipProvider>
  );
}
