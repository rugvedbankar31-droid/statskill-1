import { useEffect, useState, type ReactNode } from "react";
import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import {
  BarChart3,
  BookOpen,
  Brain,
  ClipboardCheck,
  LayoutDashboard,
  ListChecks,
  LogOut,
  Menu,
  Moon,
  Shield,
  Sun,
  Languages,
} from "lucide-react";
import { Logo } from "@/components/logo";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent } from "@/components/ui/sheet";
import { Separator, Skeleton } from "@/components/ui/misc";
import { AssistantDock } from "@/components/chat";
import { useAppStore } from "@/lib/store";
import { t, type I18nKey } from "@/lib/i18n";
import type { Role } from "@/lib/types";
import { cn, useHydrated } from "@/lib/utils";

const NAV: {
  to: string;
  key: I18nKey;
  icon: typeof LayoutDashboard;
  roles: Role[] | "all";
}[] = [
  { to: "/dashboard", key: "navDashboard", icon: LayoutDashboard, roles: "all" },
  { to: "/assessment", key: "navAssessment", icon: Brain, roles: "all" },
  { to: "/quiz", key: "navQuiz", icon: ListChecks, roles: "all" },
  {
    to: "/quiz/trainer",
    key: "navTrainer",
    icon: ClipboardCheck,
    roles: ["trainer", "admin", "superadmin"],
  },
  { to: "/courses", key: "navCourses", icon: BookOpen, roles: "all" },
  { to: "/admin", key: "navAdmin", icon: BarChart3, roles: ["admin", "superadmin"] },
  { to: "/security", key: "navSecurity", icon: Shield, roles: ["admin", "superadmin"] },
];

function allowed(roles: Role[] | "all", role: Role) {
  return roles === "all" || roles.includes(role);
}

function NavLinks({
  onNavigate,
  collapsed,
}: {
  onNavigate?: () => void;
  collapsed?: boolean;
}) {
  const lang = useAppStore((s) => s.lang);
  const user = useAppStore((s) => s.user);
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  if (!user) return null;
  return (
    <nav className="flex flex-col gap-1">
      {NAV.filter((n) => allowed(n.roles, user.role)).map((item) => {
        const active =
          item.to === "/quiz"
            ? pathname === "/quiz"
            : pathname === item.to || pathname.startsWith(`${item.to}/`);
        const Icon = item.icon;
        return (
          <Link
            key={item.to}
            to={item.to}
            onClick={onNavigate}
            className={cn(
              "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors",
              active
                ? "bg-indigo/12 text-indigo dark:bg-accent/15 dark:text-accent"
                : "text-muted-foreground hover:bg-muted hover:text-foreground",
              collapsed && "justify-center px-0",
            )}
          >
            <Icon className="size-4 shrink-0" />
            {!collapsed && t(lang, item.key)}
          </Link>
        );
      })}
    </nav>
  );
}

function SidebarBody({ onNavigate }: { onNavigate?: () => void }) {
  const user = useAppStore((s) => s.user);
  const lang = useAppStore((s) => s.lang);
  const signOut = useAppStore((s) => s.signOut);
  const navigate = useNavigate();
  return (
    <div className="flex h-full flex-col">
      <Link to="/" className="px-2 py-3">
        <Logo />
      </Link>
      <Separator className="mb-3" />
      <div className="flex-1 overflow-y-auto px-1">
        <NavLinks onNavigate={onNavigate} />
      </div>
      {user && (
        <div className="mt-3 rounded-xl bg-muted/70 p-3">
          <p className="truncate text-sm font-semibold">{user.name}</p>
          <p className="truncate text-xs text-muted-foreground">{user.designation}</p>
          <p className="mt-1 text-[11px] uppercase tracking-wide text-muted-foreground">
            {user.role}
          </p>
          <Button
            variant="ghost"
            size="sm"
            className="mt-2 w-full justify-start"
            onClick={() => {
              signOut();
              navigate({ to: "/" });
              onNavigate?.();
            }}
          >
            <LogOut className="size-4" />
            {t(lang, "signOut")}
          </Button>
        </div>
      )}
    </div>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const hydrated = useHydrated();
  const user = useAppStore((s) => s.user);
  const theme = useAppStore((s) => s.theme);
  const setTheme = useAppStore((s) => s.setTheme);
  const lang = useAppStore((s) => s.lang);
  const setLang = useAppStore((s) => s.setLang);
  const navigate = useNavigate();

  useEffect(() => {
    if (hydrated && !user) navigate({ to: "/login" });
  }, [hydrated, user, navigate]);

  if (!hydrated) {
    return (
      <div className="min-h-screen bg-background p-6">
        <Skeleton className="h-14 w-full" />
        <Skeleton className="mt-6 h-64 w-full" />
      </div>
    );
  }
  if (!user) return null;

  return (
    <div className="min-h-screen bg-background">
      <div className="tricolor h-1 w-full" />
      <div className="flex min-h-[calc(100vh-4px)]">
        <aside className="hidden w-64 shrink-0 border-r border-border bg-card/70 p-3 lg:flex lg:flex-col">
          <SidebarBody />
        </aside>
        <div className="flex min-w-0 flex-1 flex-col">
          <header className="sticky top-0 z-30 flex h-14 items-center justify-between gap-3 border-b border-border bg-background/80 px-4 backdrop-blur-md">
            <div className="flex items-center gap-2 lg:hidden">
              <Button variant="ghost" size="icon" onClick={() => setOpen(true)} aria-label="Open menu">
                <Menu className="size-5" />
              </Button>
              <Logo compact />
            </div>
            <p className="hidden text-sm text-muted-foreground lg:block">
              {user.department} · {user.cadre} · {user.region}
            </p>
            <div className="ml-auto flex items-center gap-1">
              <Button
                variant="ghost"
                size="icon"
                aria-label="Toggle language"
                onClick={() => setLang(lang === "en" ? "hi" : "en")}
              >
                <Languages className="size-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                aria-label="Toggle theme"
                onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              >
                {theme === "dark" ? <Sun className="size-4" /> : <Moon className="size-4" />}
              </Button>
            </div>
          </header>
          <main className="flex-1 px-4 py-6 sm:px-6 lg:px-8">{children}</main>
        </div>
      </div>
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetContent side="left">
          <SidebarBody onNavigate={() => setOpen(false)} />
        </SheetContent>
      </Sheet>
      <AssistantDock />
    </div>
  );
}

export function PageHeader({
  eyebrow,
  title,
  description,
  actions,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  actions?: ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div>
        {eyebrow && (
          <p className="mb-1 text-xs font-semibold uppercase tracking-[0.16em] text-accent">
            {eyebrow}
          </p>
        )}
        <h1 className="font-display text-3xl font-semibold tracking-tight">{title}</h1>
        {description && (
          <p className="mt-2 max-w-2xl text-sm text-muted-foreground">{description}</p>
        )}
      </div>
      {actions}
    </div>
  );
}

export function MarketingNav() {
  const lang = useAppStore((s) => s.lang);
  const theme = useAppStore((s) => s.theme);
  const setTheme = useAppStore((s) => s.setTheme);
  const setLang = useAppStore((s) => s.setLang);
  const user = useAppStore((s) => s.user);
  const hydrated = useHydrated();
  return (
    <header className="sticky top-0 z-40">
      <div className="tricolor h-1 w-full" />
      <div className="flex items-center justify-between gap-3 border-b border-border bg-background/80 px-4 py-3 backdrop-blur-md sm:px-6">
        <Link to="/">
          <Logo />
        </Link>
        <div className="flex items-center gap-1 sm:gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLang(lang === "en" ? "hi" : "en")}
          >
            {lang === "en" ? "हिन्दी" : "EN"}
          </Button>
          <Button
            variant="ghost"
            size="icon"
            aria-label="Toggle theme"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          >
            {theme === "dark" ? <Sun className="size-4" /> : <Moon className="size-4" />}
          </Button>
          <Button asChild variant="accent" size="sm">
            <Link to={hydrated && user ? "/dashboard" : "/login"}>{t(lang, "signIn")}</Link>
          </Button>
        </div>
      </div>
    </header>
  );
}
