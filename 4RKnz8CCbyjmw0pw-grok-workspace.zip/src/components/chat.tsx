import { useState } from "react";
import { Bot, MessageCircle, Send, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/input";
import { chatAssistantFn } from "@/lib/ai";
import { useAppStore } from "@/lib/store";
import { t } from "@/lib/i18n";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const PROMPTS = [
  "Build a 90-day plan to close my Python gap.",
  "Which NSSTA TPAC course fits sampling for PLFS?",
  "How does DPDP Act 2023 affect PLFS public-use files?",
];

export function AssistantDock() {
  const open = useAppStore((s) => s.chatOpen);
  const setOpen = useAppStore((s) => s.setChatOpen);
  const messages = useAppStore((s) => s.chatMessages);
  const addChat = useAppStore((s) => s.addChat);
  const user = useAppStore((s) => s.user);
  const lang = useAppStore((s) => s.lang);
  const [draft, setDraft] = useState("");
  const [busy, setBusy] = useState(false);

  async function send(text: string) {
    const content = text.trim();
    if (!content || busy) return;
    setDraft("");
    addChat({ id: crypto.randomUUID(), role: "user", content });
    setBusy(true);
    try {
      const history = [...useAppStore.getState().chatMessages].slice(-8).map((m) => ({
        role: m.role,
        content: m.content.slice(0, 1500),
      }));
      const res = await chatAssistantFn({
        data: {
          messages: history,
          lang,
          learnerContext: user
            ? `${user.name}, ${user.designation}, ${user.department}, ${user.cadre}`
            : undefined,
        },
      });
      if (!res.ok) {
        toast.error(res.error);
        addChat({
          id: crypto.randomUUID(),
          role: "assistant",
          content:
            "The assistant is unavailable just now. Try a catalogue search on iGOT or the Assessment page for rule-based gap recommendations.",
        });
        return;
      }
      addChat({ id: crypto.randomUUID(), role: "assistant", content: res.text });
    } catch {
      toast.error("Could not reach the assistant.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="fixed bottom-5 right-5 z-40 flex size-14 items-center justify-center rounded-full bg-accent text-accent-foreground shadow-lift transition-transform duration-150 hover:scale-105 active:scale-[0.96]"
        aria-label={t(lang, "assistant")}
      >
        {open ? <X className="size-5" /> : <MessageCircle className="size-5" />}
      </button>
      <div
        className={cn(
          "fixed bottom-24 right-5 z-40 flex w-[min(22rem,calc(100vw-1.5rem))] flex-col overflow-hidden rounded-2xl bg-card shadow-lift transition-[opacity,transform] duration-200",
          open
            ? "pointer-events-auto translate-y-0 opacity-100"
            : "pointer-events-none translate-y-2 opacity-0",
        )}
      >
        <div className="flex items-center gap-2 border-b border-border bg-navy px-4 py-3 text-on-navy dark:bg-indigo">
          <Bot className="size-4 text-saffron" />
          <div>
            <p className="text-sm font-semibold">{t(lang, "assistant")}</p>
            <p className="text-[11px] text-on-navy/70">Grounded in MoSPI / NSSTA curricula</p>
          </div>
        </div>
        <div className="flex max-h-80 flex-col gap-2 overflow-y-auto p-3">
          {messages.length === 0 && (
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">
                Ask about competency gaps, iGOT courses, or a survey-cycle study plan.
              </p>
              {PROMPTS.map((p) => (
                <button
                  key={p}
                  type="button"
                  className="block w-full rounded-xl bg-muted/80 px-3 py-2 text-left text-xs hover:bg-muted"
                  onClick={() => send(p)}
                >
                  {p}
                </button>
              ))}
            </div>
          )}
          {messages.map((m) => (
            <div
              key={m.id}
              className={cn(
                "max-w-[92%] rounded-xl px-3 py-2 text-sm leading-relaxed",
                m.role === "user"
                  ? "ml-auto bg-indigo text-on-navy"
                  : "bg-muted text-foreground",
              )}
            >
              {m.content}
            </div>
          ))}
          {busy && (
            <div className="h-8 w-24 rounded-xl bg-muted shimmer" aria-label="Thinking" />
          )}
        </div>
        <form
          className="flex items-end gap-2 border-t border-border p-3"
          onSubmit={(e) => {
            e.preventDefault();
            void send(draft);
          }}
        >
          <Textarea
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder="Ask StatSkill…"
            className="min-h-12 resize-none"
            rows={2}
          />
          <Button type="submit" size="icon" variant="accent" disabled={busy || !draft.trim()}>
            <Send className="size-4" />
          </Button>
        </form>
      </div>
    </>
  );
}
