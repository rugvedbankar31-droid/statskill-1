import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const quizInput = z.object({
  content: z.string().min(40).max(9000),
  sourceName: z.string().max(180),
  count: z.number().min(3).max(12),
  difficulty: z.enum(["easy", "medium", "hard", "mixed"]),
  language: z.enum(["English", "Hindi", "Bilingual"]),
  durationMin: z.number().min(5).max(60),
});

const chatInput = z.object({
  messages: z
    .array(
      z.object({
        role: z.enum(["user", "assistant"]),
        content: z.string().max(2000),
      }),
    )
    .max(10),
  lang: z.enum(["en", "hi"]),
  learnerContext: z.string().max(500).optional(),
});

const insightInput = z.object({
  profileSummary: z.string().min(20).max(2500),
});

type ChatCompletion = {
  choices?: { message?: { content?: string } }[];
};

async function grokChat(
  messages: { role: "system" | "user" | "assistant"; content: string }[],
  maxTokens: number,
) {
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) return { ok: false as const, error: "AI is not available in this environment." };

  const res = await fetch("https://api.x.ai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "grok-4.5",
      messages,
      temperature: 0.4,
      max_tokens: maxTokens,
    }),
  });

  if (!res.ok) {
    return { ok: false as const, error: `AI service returned ${res.status}.` };
  }
  const body = (await res.json()) as ChatCompletion;
  const text = body.choices?.[0]?.message?.content?.trim() ?? "";
  if (!text) return { ok: false as const, error: "Empty AI response." };
  return { ok: true as const, text };
}

function extractJson(text: string): unknown {
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const raw = (fenced?.[1] ?? text).trim();
  const start = raw.indexOf("{");
  const end = raw.lastIndexOf("}");
  if (start < 0 || end <= start) throw new Error("No JSON object in model output");
  return JSON.parse(raw.slice(start, end + 1));
}

export const generateQuizFn = createServerFn({ method: "POST" })
  .validator((input: unknown) => quizInput.parse(input))
  .handler(async ({ data }) => {
    const system = `You are StatSkill AI, generating assessments for India's Official Statistical System (MoSPI, NSO, NSSTA, ISS/SSS officers).
Return ONLY valid JSON with this shape:
{
  "title": string,
  "questions": [
    {
      "question": string,
      "options": [string, string, string, string],
      "correctIndex": 0-3,
      "explanation": string,
      "difficulty": "easy"|"medium"|"hard",
      "topic": string,
      "tags": string[]
    }
  ]
}
Rules:
- Exactly ${data.count} questions.
- Difficulty: ${data.difficulty}.
- Language: ${data.language}. If Hindi, write questions and explanations in Hindi (Devanagari). If Bilingual, question in English and a short Hindi gloss in the explanation.
- Options must be plausible. Explanations teach the concept, 2-4 sentences.
- Ground every item in the source material; do not invent contradicting facts.
- Topics should map to official statistics (sampling, SNA, PLFS, Python/R/SQL, privacy, etc.) when relevant.`;

    const result = await grokChat(
      [
        { role: "system", content: system },
        {
          role: "user",
          content: `Source: ${data.sourceName}\nTarget duration: ${data.durationMin} minutes.\n\nMATERIAL:\n${data.content}`,
        },
      ],
      2200,
    );

    if (!result.ok) return result;

    try {
      const parsed = extractJson(result.text) as {
        title?: string;
        questions?: Array<{
          question: string;
          options: string[];
          correctIndex: number;
          explanation: string;
          difficulty: "easy" | "medium" | "hard";
          topic: string;
          tags?: string[];
        }>;
      };
      const questions = (parsed.questions ?? [])
        .filter((q) => q.question && Array.isArray(q.options) && q.options.length >= 4)
        .slice(0, data.count)
        .map((q, i) => ({
          id: `ai-${Date.now()}-${i}`,
          question: q.question,
          options: q.options.slice(0, 4),
          correctIndex: Math.min(3, Math.max(0, Number(q.correctIndex) || 0)),
          explanation: q.explanation ?? "",
          difficulty: q.difficulty ?? "medium",
          topic: q.topic ?? "Official Statistics",
          tags: q.tags ?? [],
          approved: false,
        }));
      if (questions.length < 3) {
        return { ok: false as const, error: "AI returned too few usable questions." };
      }
      return {
        ok: true as const,
        quiz: {
          title: parsed.title ?? `Assessment · ${data.sourceName}`,
          questions,
        },
      };
    } catch {
      return { ok: false as const, error: "Could not parse AI quiz JSON." };
    }
  });

export const chatAssistantFn = createServerFn({ method: "POST" })
  .validator((input: unknown) => chatInput.parse(input))
  .handler(async ({ data }) => {
    const langLine =
      data.lang === "hi"
        ? "Respond in Hindi (Devanagari), professional and concise."
        : "Respond in clear professional English.";
    const system = `You are StatSkill AI, the learning assistant for officers of India's Official Statistical System (MoSPI, NSO, NSSO/FOD, NAD, NSSTA, State DES).
Help with competency gaps, iGOT Karmayogi / NSSTA TPAC courses, survey design, sampling, national accounts, Python/R/SQL, GIS, data visualization, AI/ML, cybersecurity, DPDP/privacy, leadership and project management.
Be practical. Recommend named courses from the StatSkill catalogue when useful (Python for Official Statistics, Sampling Techniques for Large-Scale Household Surveys, National Accounts Compilation, DPDP Act 2023, GIS for Census).
Do not invent ministry circular numbers. Keep answers under 180 words unless asked for a plan.
${langLine}
Learner context: ${data.learnerContext ?? "ISS/SSS officer on StatSkill AI."}`;

    const messages = [
      { role: "system" as const, content: system },
      ...data.messages.map((m) => ({
        role: m.role as "user" | "assistant",
        content: m.content,
      })),
    ];
    return grokChat(messages, 420);
  });

export const competencyNarrativeFn = createServerFn({ method: "POST" })
  .validator((input: unknown) => insightInput.parse(input))
  .handler(async ({ data }) => {
    const result = await grokChat(
      [
        {
          role: "system",
          content:
            "You are StatSkill AI writing a competency briefing for an ISS/SSS officer. Return 3 short paragraphs: (1) current fit to role, (2) top three skill gaps with why they matter for India's statistical system, (3) a 90-day learning sequence citing iGOT Karmayogi or NSSTA TPAC style programmes. No markdown headings. No bullet emojis. Under 220 words.",
        },
        { role: "user", content: data.profileSummary },
      ],
      500,
    );
    return result;
  });
