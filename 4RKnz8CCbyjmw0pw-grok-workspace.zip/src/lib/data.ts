import type {
  AssessmentProfile,
  Competency,
  CompetencyDomain,
  Course,
  UpcomingItem,
  User,
  WorkforceMember,
} from "./types";

export const COMPETENCIES: Competency[] = [
  { id: "survey-design", name: "Survey Design", domain: "statistical", score: 78, target: 88 },
  { id: "sampling", name: "Sampling", domain: "statistical", score: 72, target: 90 },
  { id: "national-accounts", name: "National Accounts", domain: "statistical", score: 86, target: 92 },
  { id: "python", name: "Python", domain: "technical", score: 48, target: 75 },
  { id: "r", name: "R", domain: "technical", score: 62, target: 78 },
  { id: "sql", name: "SQL", domain: "technical", score: 58, target: 80 },
  { id: "gis", name: "GIS", domain: "technical", score: 41, target: 65 },
  { id: "dataviz", name: "Data Visualization", domain: "technical", score: 67, target: 80 },
  { id: "aiml", name: "AI / ML", domain: "technical", score: 32, target: 70 },
  { id: "cyber", name: "Cybersecurity", domain: "digital", score: 54, target: 75 },
  { id: "privacy", name: "Data Privacy", domain: "digital", score: 61, target: 82 },
  { id: "leadership", name: "Leadership", domain: "behavioural", score: 74, target: 85 },
  { id: "communication", name: "Communication", domain: "behavioural", score: 81, target: 85 },
  { id: "pm", name: "Project Management", domain: "behavioural", score: 69, target: 80 },
];

export const DOMAIN_LABEL: Record<CompetencyDomain, string> = {
  statistical: "Statistical",
  technical: "Technical",
  digital: "Digital Governance",
  behavioural: "Behavioural",
};

export const DEMO_USERS: User[] = [
  {
    id: "u-priya",
    name: "Priya Sharma",
    email: "priya.sharma@mospi.gov.in",
    role: "learner",
    designation: "Joint Director",
    department: "National Accounts Division, NSO",
    cadre: "ISS 2012",
    region: "Delhi",
    experienceYears: 12,
    education: "M.Stat, Indian Statistical Institute, Kolkata",
    batch: "ISS 2012",
    profileCompletion: 82,
    competencyScore: 64,
    learningHours: 46,
    certificates: 7,
    completedModules: 18,
    upcomingAssessments: 2,
  },
  {
    id: "u-venkatesh",
    name: "Dr. R. Venkatesh",
    email: "r.venkatesh@nssta.gov.in",
    role: "trainer",
    designation: "Faculty (Sampling Theory)",
    department: "NSSTA, Greater Noida",
    cadre: "ISS 2004",
    region: "Uttar Pradesh",
    experienceYears: 21,
    education: "Ph.D. Statistics, IIT Bombay",
    profileCompletion: 94,
    competencyScore: 88,
    learningHours: 120,
    certificates: 14,
    completedModules: 40,
    upcomingAssessments: 1,
  },
  {
    id: "u-kavita",
    name: "Kavita Nair",
    email: "kavita.nair@mospi.gov.in",
    role: "admin",
    designation: "Additional Director General",
    department: "Capacity Building Division, MoSPI",
    cadre: "ISS 1998",
    region: "Delhi",
    experienceYears: 27,
    education: "M.A. Economics, DSE; M.Stat, ISI Delhi",
    profileCompletion: 100,
    competencyScore: 91,
    learningHours: 86,
    certificates: 11,
    completedModules: 32,
    upcomingAssessments: 0,
  },
  {
    id: "u-suresh",
    name: "Suresh Bhatnagar",
    email: "suresh.bhatnagar@mospi.gov.in",
    role: "superadmin",
    designation: "Deputy Director General",
    department: "Training & NSSTA Coordination, MoSPI",
    cadre: "ISS 1995",
    region: "Delhi",
    experienceYears: 30,
    education: "M.Stat, ISI Kolkata",
    profileCompletion: 100,
    competencyScore: 93,
    learningHours: 64,
    certificates: 9,
    completedModules: 22,
    upcomingAssessments: 0,
  },
];

export const COURSES: Course[] = [
  {
    id: "c-foundations",
    title: "Foundations of Official Statistics in India",
    provider: "iGOT Karmayogi",
    skills: ["Survey Design", "National Accounts", "Communication"],
    durationHours: 8,
    rating: 4.7,
    level: "Foundation",
    description:
      "Orientation to the Indian Statistical System, MoSPI mandate, and the National Statistical Commission framework.",
    language: "English / Hindi",
    competencyIds: ["survey-design", "national-accounts", "communication"],
    modules: 6,
  },
  {
    id: "c-sampling",
    title: "Sampling Techniques for Large-Scale Household Surveys",
    provider: "NSSTA TPAC",
    skills: ["Sampling", "Survey Design"],
    durationHours: 24,
    rating: 4.8,
    level: "Advanced",
    description:
      "Stratification, PPS, and multi-stage designs used in PLFS, HCES, and NSS rounds, with design-weight practice.",
    language: "English",
    competencyIds: ["sampling", "survey-design"],
    modules: 10,
  },
  {
    id: "c-na",
    title: "National Accounts Compilation: SNA 2008 to SNA 2025",
    provider: "NSSTA TPAC",
    skills: ["National Accounts", "SQL"],
    durationHours: 20,
    rating: 4.6,
    level: "Advanced",
    description:
      "Sequence of accounts, supply-use tables, and bridging to the new SNA revision for NAD officers.",
    language: "English",
    competencyIds: ["national-accounts", "sql"],
    modules: 8,
  },
  {
    id: "c-python",
    title: "Python for Official Statistics",
    provider: "iGOT Karmayogi",
    skills: ["Python", "Data Visualization"],
    durationHours: 16,
    rating: 4.5,
    level: "Intermediate",
    description:
      "Pandas pipelines for microdata, reproducible notebooks, and publication-grade tables from unit-level files.",
    language: "English",
    competencyIds: ["python", "dataviz"],
    modules: 9,
  },
  {
    id: "c-r",
    title: "Statistical Computing with R for NSS and PLFS",
    provider: "NSSTA TPAC",
    skills: ["R", "Sampling", "Data Visualization"],
    durationHours: 18,
    rating: 4.6,
    level: "Intermediate",
    description:
      "survey and srvyr packages, replicate weights, and ggplot2 for official releases.",
    language: "English",
    competencyIds: ["r", "sampling", "dataviz"],
    modules: 8,
  },
  {
    id: "c-sql",
    title: "SQL for ASUSE, PLFS and e-Sankhyiki Warehouses",
    provider: "NSSTA TPAC",
    skills: ["SQL", "Data Privacy"],
    durationHours: 12,
    rating: 4.4,
    level: "Intermediate",
    description:
      "Querying enterprise and labour-force warehouses with audit-safe joins and suppression rules.",
    language: "English / Hindi",
    competencyIds: ["sql", "privacy"],
    modules: 6,
  },
  {
    id: "c-gis",
    title: "GIS for Census, FASAL and Local-Level Statistics",
    provider: "iGOT Karmayogi",
    skills: ["GIS", "Survey Design"],
    durationHours: 14,
    rating: 4.3,
    level: "Intermediate",
    description:
      "QGIS workflows for enumeration-block mapping, crop statistics, and geo-enabled sample frames.",
    language: "English",
    competencyIds: ["gis", "survey-design"],
    modules: 7,
  },
  {
    id: "c-viz",
    title: "Data Visualization for Policy Briefs",
    provider: "iGOT Karmayogi",
    skills: ["Data Visualization", "Communication"],
    durationHours: 6,
    rating: 4.5,
    level: "Foundation",
    description:
      "Chart discipline for PIB releases, dashboarding for senior officers, and accessible colour systems.",
    language: "English / Hindi",
    competencyIds: ["dataviz", "communication"],
    modules: 4,
  },
  {
    id: "c-aiml",
    title: "AI and Machine Learning for Statistical Production",
    provider: "StatSkill AI",
    skills: ["AI / ML", "Python"],
    durationHours: 16,
    rating: 4.7,
    level: "Advanced",
    description:
      "Nowcasting, imputation, anomaly detection, and responsible-AI checks on official microdata.",
    language: "English",
    competencyIds: ["aiml", "python"],
    modules: 8,
  },
  {
    id: "c-cyber",
    title: "Cybersecurity for Government Statistical Systems",
    provider: "iGOT Karmayogi",
    skills: ["Cybersecurity", "Data Privacy"],
    durationHours: 8,
    rating: 4.4,
    level: "Foundation",
    description:
      "NIC cloud controls, MeitY guidelines, and incident hygiene for data-holding divisions.",
    language: "English / Hindi",
    competencyIds: ["cyber", "privacy"],
    modules: 5,
  },
  {
    id: "c-dpdp",
    title: "DPDP Act 2023 and Confidentiality in Official Statistics",
    provider: "iGOT Karmayogi",
    skills: ["Data Privacy", "Leadership"],
    durationHours: 5,
    rating: 4.6,
    level: "Foundation",
    description:
      "Lawful processing, anonymisation standards, and the Collection of Statistics Act interface.",
    language: "English / Hindi",
    competencyIds: ["privacy", "leadership"],
    modules: 4,
  },
  {
    id: "c-lead",
    title: "Leadership in Public Service: Mission Karmayogi",
    provider: "iGOT Karmayogi",
    skills: ["Leadership", "Communication", "Project Management"],
    durationHours: 10,
    rating: 4.5,
    level: "Intermediate",
    description:
      "Competency-based HR, FRAC, and leading mixed ISS–SSS teams through survey cycles.",
    language: "Hindi / English",
    competencyIds: ["leadership", "communication", "pm"],
    modules: 6,
  },
  {
    id: "c-comm",
    title: "Writing for Policy: Notes, Releases and Parliamentary Replies",
    provider: "iGOT Karmayogi",
    skills: ["Communication"],
    durationHours: 6,
    rating: 4.4,
    level: "Foundation",
    description:
      "Plain-language statistical communication for Cabinet notes and standing-committee briefs.",
    language: "English / Hindi",
    competencyIds: ["communication"],
    modules: 4,
  },
  {
    id: "c-pm",
    title: "Project Management for Survey Operations",
    provider: "NSSTA TPAC",
    skills: ["Project Management", "Survey Design", "Leadership"],
    durationHours: 12,
    rating: 4.5,
    level: "Intermediate",
    description:
      "Field calendar control, vendor SLAs, and risk registers for all-India survey rounds.",
    language: "English",
    competencyIds: ["pm", "survey-design", "leadership"],
    modules: 7,
  },
];

export const WORKFORCE: WorkforceMember[] = [
  {
    id: "w1",
    name: "Priya Sharma",
    designation: "Joint Director",
    department: "National Accounts Division",
    region: "Delhi",
    cadre: "ISS",
    score: 64,
    completionRate: 71,
    hours: 46,
    topGap: "Python",
    domainScores: { statistical: 79, technical: 51, digital: 58, behavioural: 75 },
  },
  {
    id: "w2",
    name: "Arjun Patel",
    designation: "Deputy Director",
    department: "Field Operations Division",
    region: "Gujarat",
    cadre: "ISS",
    score: 61,
    completionRate: 54,
    hours: 28,
    topGap: "AI / ML",
    domainScores: { statistical: 82, technical: 44, digital: 49, behavioural: 70 },
  },
  {
    id: "w3",
    name: "Meera Krishnan",
    designation: "Director",
    department: "Price Statistics Division",
    region: "Tamil Nadu",
    cadre: "ISS",
    score: 77,
    completionRate: 88,
    hours: 62,
    topGap: "GIS",
    domainScores: { statistical: 85, technical: 63, digital: 72, behavioural: 81 },
  },
  {
    id: "w4",
    name: "Farhan Qureshi",
    designation: "Senior Statistical Officer",
    department: "Survey Design & Research",
    region: "Uttar Pradesh",
    cadre: "SSS",
    score: 58,
    completionRate: 41,
    hours: 19,
    topGap: "Python",
    domainScores: { statistical: 74, technical: 38, digital: 46, behavioural: 64 },
  },
  {
    id: "w5",
    name: "Ananya Bose",
    designation: "Joint Director",
    department: "Data Informatics & Innovation",
    region: "West Bengal",
    cadre: "ISS",
    score: 81,
    completionRate: 79,
    hours: 71,
    topGap: "Leadership",
    domainScores: { statistical: 70, technical: 88, digital: 84, behavioural: 68 },
  },
  {
    id: "w6",
    name: "Vikram Singh",
    designation: "Deputy Director",
    department: "Industrial Statistics",
    region: "Rajasthan",
    cadre: "ISS",
    score: 66,
    completionRate: 63,
    hours: 34,
    topGap: "Data Privacy",
    domainScores: { statistical: 76, technical: 55, digital: 52, behavioural: 72 },
  },
  {
    id: "w7",
    name: "Lakshmi Nair",
    designation: "Additional Director General",
    department: "Social Statistics Division",
    region: "Kerala",
    cadre: "ISS",
    score: 84,
    completionRate: 91,
    hours: 58,
    topGap: "AI / ML",
    domainScores: { statistical: 90, technical: 61, digital: 77, behavioural: 88 },
  },
  {
    id: "w8",
    name: "Rohit Joshi",
    designation: "Junior Statistical Officer",
    department: "Sampling Design",
    region: "Maharashtra",
    cadre: "SSS",
    score: 52,
    completionRate: 33,
    hours: 14,
    topGap: "SQL",
    domainScores: { statistical: 68, technical: 35, digital: 40, behavioural: 58 },
  },
  {
    id: "w9",
    name: "Fatima Sheikh",
    designation: "Director",
    department: "Data Informatics & Innovation",
    region: "Telangana",
    cadre: "ISS",
    score: 79,
    completionRate: 84,
    hours: 67,
    topGap: "Communication",
    domainScores: { statistical: 72, technical: 86, digital: 81, behavioural: 69 },
  },
  {
    id: "w10",
    name: "C. Murugan",
    designation: "Deputy Director",
    department: "Agriculture Statistics",
    region: "Karnataka",
    cadre: "ISS",
    score: 63,
    completionRate: 57,
    hours: 31,
    topGap: "Python",
    domainScores: { statistical: 80, technical: 46, digital: 55, behavioural: 71 },
  },
  {
    id: "w11",
    name: "Neha Verma",
    designation: "Senior Statistical Officer",
    department: "National Accounts Division",
    region: "Madhya Pradesh",
    cadre: "SSS",
    score: 57,
    completionRate: 48,
    hours: 22,
    topGap: "R",
    domainScores: { statistical: 73, technical: 41, digital: 50, behavioural: 62 },
  },
  {
    id: "w12",
    name: "Tenzin Dorjee",
    designation: "Deputy Director",
    department: "Directorate of Economics & Statistics",
    region: "Sikkim",
    cadre: "ISS",
    score: 70,
    completionRate: 76,
    hours: 39,
    topGap: "Cybersecurity",
    domainScores: { statistical: 77, technical: 58, digital: 61, behavioural: 78 },
  },
];

export const DEPARTMENTS = [
  "National Accounts Division",
  "Field Operations Division",
  "Price Statistics Division",
  "Survey Design & Research",
  "Data Informatics & Innovation",
  "Industrial Statistics",
  "Social Statistics Division",
  "Sampling Design",
  "Agriculture Statistics",
  "Directorate of Economics & Statistics",
];

export const DESIGNATIONS = [
  "Junior Statistical Officer",
  "Senior Statistical Officer",
  "Deputy Director",
  "Joint Director",
  "Director",
  "Additional Director General",
  "Deputy Director General",
  "Faculty (Sampling Theory)",
];

export const REGIONS = [
  "Delhi",
  "Gujarat",
  "Tamil Nadu",
  "Uttar Pradesh",
  "West Bengal",
  "Rajasthan",
  "Kerala",
  "Maharashtra",
  "Telangana",
  "Karnataka",
  "Madhya Pradesh",
  "Sikkim",
];

export const JOB_ROLES = [
  "National Accounts Compiler",
  "Survey Operations Manager",
  "Sampling Methodologist",
  "Price Index Analyst",
  "Data Engineer (Official Statistics)",
  "Field Supervision (FOD)",
  "State DES Coordinator",
  "Training Faculty, NSSTA",
];

export const CAREER_PATHS = [
  "Director / DDG track (generalist ISS)",
  "Specialist — Data Science & AI",
  "Specialist — National Accounts",
  "Specialist — Survey Methodology",
  "State DES leadership",
  "NSSTA faculty",
];

export const UPCOMING: UpcomingItem[] = [
  {
    id: "ua1",
    title: "Mid-career competency check — NAD cohort",
    date: "12 Sep 2026",
    type: "assessment",
    venue: "Online · StatSkill AI",
  },
  {
    id: "ua2",
    title: "NSSTA TPAC: Sampling refresher (Week 2)",
    date: "18 Sep 2026",
    type: "workshop",
    venue: "NSSTA, Greater Noida",
  },
  {
    id: "ua3",
    title: "iGOT: DPDP Act module completion window",
    date: "30 Sep 2026",
    type: "course",
    venue: "iGOT Karmayogi",
  },
];

export const SAMPLE_DOCUMENTS = [
  {
    id: "plfs",
    name: "PLFS sampling note (excerpt).md",
    title: "Periodic Labour Force Survey — sampling design",
    content: `Periodic Labour Force Survey (PLFS) of the National Statistical Office uses a rotational panel design in urban areas and a visit-based design in rural areas.

First-stage units (FSUs) are census villages in rural areas and Urban Frame Survey blocks in urban areas. FSUs are selected by Probability Proportional to Size with Replacement (PPSWR), size being population as per the latest census.

Second-stage stratification: households are stratified by household type (self-employed, regular wage/salary, casual labour, others) before selecting second-stage units (SSUs) by Simple Random Sampling Without Replacement (SRSWOR).

Design weights equal the inverse of the inclusion probability at each stage, adjusted for non-response at FSU and household levels. Multiplier files released with unit-level data must be used for unbiased estimates of labour-force indicators such as LFPR, WPR and UR.

Key quality risks: frame ageing between censuses, substitution of FSUs, and under-coverage of seasonal migrant households. Officers compiling state-level estimates must check coefficient of variation before release.`,
  },
  {
    id: "sna",
    name: "NAD compilation brief.md",
    title: "National Accounts — GVA compilation",
    content: `Gross Value Added (GVA) at basic prices is the central balancing item of the production account in the System of National Accounts.

For India, NAD compiles GVA by economic activity using a mix of census/survey benchmarks (ASI, ASUSE, livestock census) and current indicators (IIP, GST, corporate filings).

The production approach: output minus intermediate consumption. The income approach: compensation of employees + mixed income + other taxes on production + consumption of fixed capital + net operating surplus.

Double deflation is preferred for volume measures; where intermediate-consumption deflators are weak, single deflation is still used in some informal-sector activities.

SNA 2025 will expand treatment of data as an asset, unpaid household service work satellite accounts, and natural capital. NAD officers should map current compilation sheets to the new sequence of accounts before the next base-year revision.`,
  },
];

export const DEFAULT_PROFILE: AssessmentProfile = {
  designation: "Joint Director",
  department: "National Accounts Division, NSO",
  jobRole: "National Accounts Compiler",
  education: "M.Stat, Indian Statistical Institute, Kolkata",
  experienceYears: 12,
  previousTrainings: "NSSTA induction; iGOT Mission Karmayogi foundation; SNA 2008 workshop 2023",
  currentAssignment: "GVA compilation for manufacturing and bridging ASI with GST filings",
  careerPath: "Specialist — Data Science & AI",
};

export const ROLE_TARGETS: Record<string, Record<string, number>> = {
  "National Accounts Compiler": {
    "national-accounts": 92,
    sql: 80,
    python: 75,
    r: 70,
    dataviz: 78,
    aiml: 68,
    privacy: 80,
    communication: 82,
  },
  "Survey Operations Manager": {
    "survey-design": 90,
    sampling: 85,
    pm: 88,
    leadership: 85,
    communication: 84,
    gis: 70,
    python: 60,
  },
  "Sampling Methodologist": {
    sampling: 95,
    "survey-design": 90,
    r: 85,
    python: 80,
    sql: 70,
    dataviz: 75,
  },
  "Data Engineer (Official Statistics)": {
    python: 92,
    sql: 92,
    aiml: 85,
    cyber: 82,
    privacy: 85,
    r: 70,
    dataviz: 80,
  },
  "State DES Coordinator": {
    leadership: 88,
    pm: 85,
    communication: 88,
    "survey-design": 80,
    privacy: 78,
    dataviz: 75,
  },
  default: {
    "survey-design": 80,
    sampling: 80,
    "national-accounts": 75,
    python: 70,
    r: 70,
    sql: 72,
    gis: 60,
    dataviz: 75,
    aiml: 65,
    cyber: 70,
    privacy: 78,
    leadership: 80,
    communication: 82,
    pm: 75,
  },
};

export const CAREER_BOOSTS: Record<string, Record<string, number>> = {
  "Specialist — Data Science & AI": { python: 15, aiml: 20, sql: 8, r: 8 },
  "Specialist — National Accounts": { "national-accounts": 12, sql: 8, dataviz: 6 },
  "Specialist — Survey Methodology": { sampling: 12, "survey-design": 10, r: 8 },
  "State DES leadership": { leadership: 10, pm: 10, communication: 8 },
  "NSSTA faculty": { communication: 10, leadership: 8, sampling: 6 },
  "Director / DDG track (generalist ISS)": { leadership: 12, pm: 10, communication: 8 },
};

export function computeCompetencies(profile: AssessmentProfile): Competency[] {
  const base = COMPETENCIES.map((c) => ({ ...c }));
  const role = ROLE_TARGETS[profile.jobRole] ?? ROLE_TARGETS.default;
  const boosts = CAREER_BOOSTS[profile.careerPath] ?? {};
  const exp = Math.min(profile.experienceYears, 25);
  const train = profile.previousTrainings.toLowerCase();

  return base.map((c) => {
    const target = Math.min(98, (role[c.id] ?? c.target) + (boosts[c.id] ?? 0));
    let score = 38 + exp * 1.1;
    if (c.domain === "statistical") score += 18;
    if (c.domain === "behavioural") score += 12;
    if (train.includes("python") && c.id === "python") score += 18;
    if (train.includes("sna") && c.id === "national-accounts") score += 16;
    if (train.includes("sampling") && c.id === "sampling") score += 14;
    if (train.includes("karmayogi") && c.domain === "behavioural") score += 8;
    if (train.includes("dpdp") && c.id === "privacy") score += 12;
    if (profile.education.toLowerCase().includes("isi") && c.domain === "statistical") score += 10;
    if (profile.education.toLowerCase().includes("iit") && c.domain === "technical") score += 10;
    if (profile.jobRole.includes("Data Engineer") && c.domain === "technical") score += 16;
    if (profile.jobRole.includes("National Accounts") && c.id === "national-accounts") score += 14;
    if (profile.currentAssignment.toLowerCase().includes("gst") && c.id === "sql") score += 8;
    if (profile.currentAssignment.toLowerCase().includes("ai") && c.id === "aiml") score += 12;
    score = Math.max(18, Math.min(96, Math.round(score)));
    return { ...c, score, target };
  });
}

export function domainAverages(list: Competency[]) {
  const acc: Record<CompetencyDomain, { sum: number; n: number; t: number }> = {
    statistical: { sum: 0, n: 0, t: 0 },
    technical: { sum: 0, n: 0, t: 0 },
    digital: { sum: 0, n: 0, t: 0 },
    behavioural: { sum: 0, n: 0, t: 0 },
  };
  for (const c of list) {
    acc[c.domain].sum += c.score;
    acc[c.domain].t += c.target;
    acc[c.domain].n += 1;
  }
  return (Object.keys(acc) as CompetencyDomain[]).map((domain) => ({
    domain,
    label: DOMAIN_LABEL[domain],
    score: Math.round(acc[domain].sum / acc[domain].n),
    target: Math.round(acc[domain].t / acc[domain].n),
  }));
}

export function overallScore(list: Competency[]) {
  if (!list.length) return 0;
  return Math.round(list.reduce((s, c) => s + c.score, 0) / list.length);
}

export function recommendCourses(list: Competency[], limit = 4) {
  const gaps = [...list].sort((a, b) => b.target - b.score - (a.target - a.score));
  const picked: Course[] = [];
  for (const g of gaps) {
    for (const course of COURSES) {
      if (picked.find((p) => p.id === course.id)) continue;
      if (course.competencyIds.includes(g.id)) {
        picked.push(course);
        if (picked.length >= limit) return picked;
      }
    }
  }
  return picked;
}

export const INSIGHTS = [
  {
    title: "High demand for Python and AI/ML skills",
    body: "Eight of twelve divisions show a 20+ point gap on Python. NAD and FOD cohorts will miss SNA 2025 automation targets without a dedicated NSSTA TPAC track.",
    tag: "Demand",
  },
  {
    title: "Privacy competence lags DPDP timelines",
    body: "Mean Data Privacy score is 58. Divisions holding unit-level PLFS and HCES files should complete the DPDP module before the next public-use file release.",
    tag: "Risk",
  },
  {
    title: "Field Operations completion is the bottleneck",
    body: "FOD officers average 54% learning completion against 79% in DIID. Recommend protecting two hours a week during non-survey months.",
    tag: "Delivery",
  },
  {
    title: "SSS cadre needs a foundation SQL pathway",
    body: "Junior and Senior Statistical Officers cluster below 45 on SQL. A 12-hour iGOT + practical warehouse lab would close the largest volume gap.",
    tag: "Cadre",
  },
];
