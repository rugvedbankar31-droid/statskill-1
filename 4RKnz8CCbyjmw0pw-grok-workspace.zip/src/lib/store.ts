import { create } from "zustand";
import { persist } from "zustand/middleware";
import type {
  AssessmentProfile,
  AssessmentResult,
  ChatMessage,
  GeneratedQuiz,
  QuizQuestion,
  Role,
  User,
} from "./types";
import {
  COMPETENCIES,
  DEFAULT_PROFILE,
  DEMO_USERS,
  computeCompetencies,
  overallScore,
  recommendCourses,
} from "./data";
import type { Lang } from "./i18n";

export interface Enrolment {
  courseId: string;
  status: "not_started" | "in_progress" | "completed";
  progress: number;
}

interface AppState {
  user: User | null;
  theme: "light" | "dark";
  lang: Lang;
  profile: AssessmentProfile;
  assessmentResult: AssessmentResult | null;
  enrolments: Enrolment[];
  quizzes: GeneratedQuiz[];
  activeQuizId: string | null;
  quizAnswers: Record<string, number | null>;
  quizStartedAt: number | null;
  chatMessages: ChatMessage[];
  chatOpen: boolean;
  signIn: (role: Role) => void;
  signOut: () => void;
  setTheme: (theme: "light" | "dark") => void;
  setLang: (lang: Lang) => void;
  setProfile: (profile: AssessmentProfile) => void;
  saveAssessment: (narrative?: string) => void;
  enrol: (courseId: string) => void;
  advanceCourse: (courseId: string) => void;
  addQuiz: (quiz: GeneratedQuiz) => void;
  updateQuestion: (quizId: string, question: QuizQuestion) => void;
  setQuizStatus: (quizId: string, status: GeneratedQuiz["status"]) => void;
  deleteQuiz: (quizId: string) => void;
  startQuiz: (quizId: string) => void;
  answerQuestion: (questionId: string, index: number) => void;
  resetQuizRun: () => void;
  setChatOpen: (open: boolean) => void;
  addChat: (msg: ChatMessage) => void;
  clearChat: () => void;
}

function applyTheme(theme: "light" | "dark") {
  if (typeof document === "undefined") return;
  document.documentElement.classList.toggle("dark", theme === "dark");
  localStorage.setItem("statskill-theme", theme);
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      user: null,
      theme: "light",
      lang: "en",
      profile: DEFAULT_PROFILE,
      assessmentResult: null,
      enrolments: [
        { courseId: "c-na", status: "in_progress", progress: 62 },
        { courseId: "c-foundations", status: "completed", progress: 100 },
        { courseId: "c-python", status: "not_started", progress: 0 },
      ],
      quizzes: [],
      activeQuizId: null,
      quizAnswers: {},
      quizStartedAt: null,
      chatMessages: [],
      chatOpen: false,
      signIn: (role) => {
        const user = DEMO_USERS.find((u) => u.role === role) ?? DEMO_USERS[0];
        set({ user });
      },
      signOut: () => set({ user: null, chatOpen: false }),
      setTheme: (theme) => {
        applyTheme(theme);
        set({ theme });
      },
      setLang: (lang) => {
        if (typeof document !== "undefined") document.documentElement.lang = lang;
        set({ lang });
      },
      setProfile: (profile) => set({ profile }),
      saveAssessment: (narrative) => {
        const profile = get().profile;
        const competencies = computeCompetencies(profile);
        const recommended = recommendCourses(competencies).map((c) => c.id);
        set({
          assessmentResult: {
            profile,
            competencies,
            narrative:
              narrative ??
              "Role and career-path targets updated. Technical gaps (Python, AI/ML, GIS) remain the primary constraint on a data-science track.",
            recommendedCourseIds: recommended,
            generatedAt: new Date().toISOString(),
          },
        });
      },
      enrol: (courseId) => {
        const enrolments = get().enrolments;
        if (enrolments.some((e) => e.courseId === courseId)) {
          set({
            enrolments: enrolments.map((e) =>
              e.courseId === courseId && e.status === "not_started"
                ? { ...e, status: "in_progress", progress: 8 }
                : e,
            ),
          });
          return;
        }
        set({
          enrolments: [...enrolments, { courseId, status: "in_progress", progress: 8 }],
        });
      },
      advanceCourse: (courseId) => {
        set({
          enrolments: get().enrolments.map((e) => {
            if (e.courseId !== courseId) return e;
            const progress = Math.min(100, e.progress + 20);
            return {
              ...e,
              progress,
              status: progress >= 100 ? "completed" : "in_progress",
            };
          }),
        });
      },
      addQuiz: (quiz) => set({ quizzes: [quiz, ...get().quizzes] }),
      updateQuestion: (quizId, question) => {
        set({
          quizzes: get().quizzes.map((q) =>
            q.id === quizId
              ? {
                  ...q,
                  questions: q.questions.map((item) =>
                    item.id === question.id ? question : item,
                  ),
                }
              : q,
          ),
        });
      },
      setQuizStatus: (quizId, status) => {
        set({
          quizzes: get().quizzes.map((q) =>
            q.id === quizId ? { ...q, status, published: status === "published" } : q,
          ),
        });
      },
      deleteQuiz: (quizId) =>
        set({ quizzes: get().quizzes.filter((q) => q.id !== quizId) }),
      startQuiz: (quizId) => {
        const quiz = get().quizzes.find((q) => q.id === quizId);
        const answers: Record<string, number | null> = {};
        quiz?.questions.forEach((qn) => {
          answers[qn.id] = null;
        });
        set({ activeQuizId: quizId, quizAnswers: answers, quizStartedAt: Date.now() });
      },
      answerQuestion: (questionId, index) => {
        set({ quizAnswers: { ...get().quizAnswers, [questionId]: index } });
      },
      resetQuizRun: () =>
        set({ activeQuizId: null, quizAnswers: {}, quizStartedAt: null }),
      setChatOpen: (open) => set({ chatOpen: open }),
      addChat: (msg) =>
        set({ chatMessages: [...get().chatMessages, msg].slice(-24) }),
      clearChat: () => set({ chatMessages: [] }),
    }),
    {
      name: "statskill-ai",
      partialize: (s) => ({
        user: s.user,
        theme: s.theme,
        lang: s.lang,
        profile: s.profile,
        assessmentResult: s.assessmentResult,
        enrolments: s.enrolments,
        quizzes: s.quizzes,
        chatMessages: s.chatMessages,
      }),
    },
  ),
);

export function currentCompetencies(): typeof COMPETENCIES {
  const result = useAppStore.getState().assessmentResult;
  return result?.competencies ?? COMPETENCIES;
}

export function currentOverall(): number {
  const user = useAppStore.getState().user;
  const result = useAppStore.getState().assessmentResult;
  if (result) return overallScore(result.competencies);
  return user?.competencyScore ?? 64;
}
