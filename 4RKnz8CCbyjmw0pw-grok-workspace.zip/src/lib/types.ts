export type Role = "learner" | "trainer" | "admin" | "superadmin";

export type CompetencyDomain =
  | "statistical"
  | "technical"
  | "digital"
  | "behavioural";

export type CourseProvider = "iGOT Karmayogi" | "NSSTA TPAC" | "StatSkill AI";

export type CourseLevel = "Foundation" | "Intermediate" | "Advanced";

export type EnrolmentStatus = "not_started" | "in_progress" | "completed";

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  designation: string;
  department: string;
  cadre: string;
  region: string;
  experienceYears: number;
  education: string;
  batch?: string;
  profileCompletion: number;
  competencyScore: number;
  learningHours: number;
  certificates: number;
  completedModules: number;
  upcomingAssessments: number;
}

export interface Competency {
  id: string;
  name: string;
  domain: CompetencyDomain;
  score: number;
  target: number;
}

export interface Course {
  id: string;
  title: string;
  provider: CourseProvider;
  skills: string[];
  durationHours: number;
  rating: number;
  level: CourseLevel;
  description: string;
  language: string;
  competencyIds: string[];
  modules: number;
}

export interface WorkforceMember {
  id: string;
  name: string;
  designation: string;
  department: string;
  region: string;
  cadre: string;
  score: number;
  completionRate: number;
  hours: number;
  topGap: string;
  domainScores: Record<CompetencyDomain, number>;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  difficulty: "easy" | "medium" | "hard";
  topic: string;
  tags: string[];
  approved?: boolean;
}

export interface GeneratedQuiz {
  id: string;
  title: string;
  sourceName: string;
  language: string;
  durationMin: number;
  difficulty: "easy" | "medium" | "hard" | "mixed";
  questions: QuizQuestion[];
  createdAt: string;
  published: boolean;
  status: "draft" | "approved" | "published";
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
}

export interface AssessmentProfile {
  designation: string;
  department: string;
  jobRole: string;
  education: string;
  experienceYears: number;
  previousTrainings: string;
  currentAssignment: string;
  careerPath: string;
}

export interface AssessmentResult {
  profile: AssessmentProfile;
  competencies: Competency[];
  narrative: string;
  recommendedCourseIds: string[];
  generatedAt: string;
}

export interface UpcomingItem {
  id: string;
  title: string;
  date: string;
  type: "assessment" | "course" | "workshop";
  venue: string;
}
