import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { _ as domainAverages, c as DESIGNATIONS, d as JOB_ROLES, g as computeCompetencies, n as useAppStore, r as CAREER_PATHS, v as overallScore, y as recommendCourses } from "./router-LYI7r0H-.mjs";
import { _ as competencyNarrativeFn, a as CardContent, c as Input, f as PageHeader, g as Textarea, i as Card, l as Label, n as Badge, o as CardHeader, r as Button, s as CardTitle, t as AppShell } from "./card-DlolnDSg.mjs";
import { i as ScoreRing, n as GapBars, r as Heatmap, t as DomainRadar } from "./charts-BJ_ujbxC.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DbRRFmVH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/assessment-DzzwTKud.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AssessmentPage() {
	const profile = useAppStore((s) => s.profile);
	const setProfile = useAppStore((s) => s.setProfile);
	const saveAssessment = useAppStore((s) => s.saveAssessment);
	const result = useAppStore((s) => s.assessmentResult);
	const enrol = useAppStore((s) => s.enrol);
	const [errors, setErrors] = (0, import_react.useState)({});
	const [busy, setBusy] = (0, import_react.useState)(false);
	const live = result?.competencies ?? computeCompetencies(profile);
	const domains = domainAverages(live);
	const score = overallScore(live);
	const recs = recommendCourses(live, 4);
	function update(key, value) {
		setProfile({
			...profile,
			[key]: value
		});
	}
	function validate() {
		const next = {};
		if (!profile.designation) next.designation = "Select a designation.";
		if (!profile.jobRole) next.jobRole = "Select a job role.";
		if (!profile.education.trim()) next.education = "Education is required.";
		if (!profile.currentAssignment.trim()) next.currentAssignment = "Describe the current assignment.";
		if (profile.experienceYears < 0 || profile.experienceYears > 40) next.experienceYears = "Enter 0–40 years.";
		setErrors(next);
		return Object.keys(next).length === 0;
	}
	async function run(withAi) {
		if (!validate()) {
			toast.error("Please complete the highlighted fields.");
			return;
		}
		saveAssessment();
		if (!withAi) {
			toast.success("Competency heatmap updated from role and career path.");
			return;
		}
		setBusy(true);
		try {
			const gaps = [...computeCompetencies(profile)].sort((a, b) => b.target - b.score - (a.target - a.score)).slice(0, 5).map((c) => `${c.name}: ${c.score}/${c.target}`).join("; ");
			const res = await competencyNarrativeFn({ data: { profileSummary: `${profile.designation}, ${profile.jobRole}, ${profile.department}. Education: ${profile.education}. Experience: ${profile.experienceYears} years. Trainings: ${profile.previousTrainings}. Assignment: ${profile.currentAssignment}. Career path: ${profile.careerPath}. Gaps: ${gaps}.` } });
			if (!res.ok) {
				toast.error(res.error);
				saveAssessment();
			} else {
				saveAssessment(res.text);
				toast.success("AI briefing added to the competency file.");
			}
		} catch {
			toast.error("Could not generate the AI briefing.");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "Competency engine",
			title: "AI competency assessment",
			description: "Capture the officer file, then generate a heatmap, radar and skill-gap recommendations against the chosen career path."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-6 lg:grid-cols-[0.95fr_1.05fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Officer profile" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Designation",
						error: errors.designation,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: profile.designation,
							onValueChange: (v) => update("designation", v),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Select" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: DESIGNATIONS.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: d,
								children: d
							}, d)) })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Department",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: profile.department,
							onChange: (e) => update("department", e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Job role",
						error: errors.jobRole,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: profile.jobRole,
							onValueChange: (v) => update("jobRole", v),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Select" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: JOB_ROLES.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: d,
								children: d
							}, d)) })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Education",
						error: errors.education,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: profile.education,
							onChange: (e) => update("education", e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Experience (years)",
						error: errors.experienceYears,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							min: 0,
							max: 40,
							value: profile.experienceYears,
							onChange: (e) => update("experienceYears", Number(e.target.value))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Previous trainings",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							value: profile.previousTrainings,
							onChange: (e) => update("previousTrainings", e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Current assignment",
						error: errors.currentAssignment,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							value: profile.currentAssignment,
							onChange: (e) => update("currentAssignment", e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Future career path",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: profile.careerPath,
							onValueChange: (v) => update("careerPath", v),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: CAREER_PATHS.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: d,
								children: d
							}, d)) })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => void run(false),
							variant: "outline",
							children: "Update heatmap"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => void run(true),
							variant: "accent",
							disabled: busy,
							children: busy ? "Writing briefing…" : "Generate AI briefing"
						})]
					})
				]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "flex flex-col items-center gap-4 p-6 sm:flex-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreRing, { value: score }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold uppercase tracking-[0.14em] text-accent",
								children: "Composite"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-2xl font-semibold",
								children: "Competency file"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: "Targets rise when you pick a specialist career path. Saffron is current score; indigo is the role bar."
							})
						]
					})]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Domain radar" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DomainRadar, { data: domains }) })] })]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Competency heatmap" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heatmap, { items: live }) })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 grid gap-4 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Priority gaps" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GapBars, { items: live }) })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Linked programmes" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "space-y-3",
				children: recs.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-3 rounded-xl bg-muted/60 p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: c.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [
							c.provider,
							" · ",
							c.durationHours,
							"h"
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "outline",
						onClick: () => {
							enrol(c.id);
							toast.success(`Enrolled in ${c.title}`);
						},
						children: "Enrol"
					})]
				}, c.id))
			})] })]
		}),
		result?.narrative && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
				className: "flex-row items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "AI briefing" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: "accent",
					children: "Generated"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "whitespace-pre-wrap text-sm leading-relaxed text-muted-foreground",
				children: result.narrative
			}) })]
		})
	] });
}
function Field({ label, error, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-1.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }),
			children,
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-destructive",
				children: error
			})
		]
	});
}
//#endregion
export { AssessmentPage as component };
