import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as createRootRoute, b as useRouter, g as createFileRoute, h as lazyRouteComponent, l as Scripts, m as Outlet, p as createRouter, u as HeadContent } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as object, i as number, o as string, r as literal, s as union } from "../_libs/zod.mjs";
import { r as TriangleAlert } from "../_libs/lucide-react.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { n as Portal, r as Provider, t as Content2 } from "../_libs/radix-ui__react-tooltip.mjs";
import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-LYI7r0H-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: error.message || "An unexpected error occurred. Try reloading the page."
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	if (typeof window === "undefined") return () => {};
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	const parentOrigin = resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		if (envelope.data.type === "hello") {
			if (!HelloSchema.safeParse(event.data).success) return;
			announce();
			return;
		}
		if (envelope.data.type === "navigate") {
			const parsed = NavigateSchema.safeParse(event.data);
			if (!parsed.success) return;
			navigate(parsed.data.path);
			queueMicrotask(reportLocation);
			return;
		}
		if (envelope.data.type === "history") {
			const parsed = HistorySchema.safeParse(event.data);
			if (!parsed.success) return;
			if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
			window.history.go(parsed.data.delta);
		}
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function useHydrated() {
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setHydrated(true);
	}, []);
	return hydrated;
}
function downloadText(filename, content, mime = "text/plain") {
	const blob = new Blob([content], { type: mime });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	a.click();
	URL.revokeObjectURL(url);
}
var TooltipProvider = Provider;
var TooltipContent = import_react.forwardRef(({ className, sideOffset = 6, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	sideOffset,
	className: cn("z-50 overflow-hidden rounded-lg bg-primary px-3 py-1.5 text-xs text-primary-foreground shadow-lift", className),
	...props
}) }));
TooltipContent.displayName = Content2.displayName;
var COMPETENCIES = [
	{
		id: "survey-design",
		name: "Survey Design",
		domain: "statistical",
		score: 78,
		target: 88
	},
	{
		id: "sampling",
		name: "Sampling",
		domain: "statistical",
		score: 72,
		target: 90
	},
	{
		id: "national-accounts",
		name: "National Accounts",
		domain: "statistical",
		score: 86,
		target: 92
	},
	{
		id: "python",
		name: "Python",
		domain: "technical",
		score: 48,
		target: 75
	},
	{
		id: "r",
		name: "R",
		domain: "technical",
		score: 62,
		target: 78
	},
	{
		id: "sql",
		name: "SQL",
		domain: "technical",
		score: 58,
		target: 80
	},
	{
		id: "gis",
		name: "GIS",
		domain: "technical",
		score: 41,
		target: 65
	},
	{
		id: "dataviz",
		name: "Data Visualization",
		domain: "technical",
		score: 67,
		target: 80
	},
	{
		id: "aiml",
		name: "AI / ML",
		domain: "technical",
		score: 32,
		target: 70
	},
	{
		id: "cyber",
		name: "Cybersecurity",
		domain: "digital",
		score: 54,
		target: 75
	},
	{
		id: "privacy",
		name: "Data Privacy",
		domain: "digital",
		score: 61,
		target: 82
	},
	{
		id: "leadership",
		name: "Leadership",
		domain: "behavioural",
		score: 74,
		target: 85
	},
	{
		id: "communication",
		name: "Communication",
		domain: "behavioural",
		score: 81,
		target: 85
	},
	{
		id: "pm",
		name: "Project Management",
		domain: "behavioural",
		score: 69,
		target: 80
	}
];
var DOMAIN_LABEL = {
	statistical: "Statistical",
	technical: "Technical",
	digital: "Digital Governance",
	behavioural: "Behavioural"
};
var DEMO_USERS = [
	{
		id: "u-priya",
		name: "Priya Sharma",
		email: "priya.sharma@mospi.gov.in",
		role: "learner",
		designation: "Joint Director",
		department: "National Accounts Division, NSO",
		cadre: "ISS 2012",
		region: "Delhi",
		experienceYears: 12,
		education: "M.Stat, Indian Statistical Institute, Kolkata",
		batch: "ISS 2012",
		profileCompletion: 82,
		competencyScore: 64,
		learningHours: 46,
		certificates: 7,
		completedModules: 18,
		upcomingAssessments: 2
	},
	{
		id: "u-venkatesh",
		name: "Dr. R. Venkatesh",
		email: "r.venkatesh@nssta.gov.in",
		role: "trainer",
		designation: "Faculty (Sampling Theory)",
		department: "NSSTA, Greater Noida",
		cadre: "ISS 2004",
		region: "Uttar Pradesh",
		experienceYears: 21,
		education: "Ph.D. Statistics, IIT Bombay",
		profileCompletion: 94,
		competencyScore: 88,
		learningHours: 120,
		certificates: 14,
		completedModules: 40,
		upcomingAssessments: 1
	},
	{
		id: "u-kavita",
		name: "Kavita Nair",
		email: "kavita.nair@mospi.gov.in",
		role: "admin",
		designation: "Additional Director General",
		department: "Capacity Building Division, MoSPI",
		cadre: "ISS 1998",
		region: "Delhi",
		experienceYears: 27,
		education: "M.A. Economics, DSE; M.Stat, ISI Delhi",
		profileCompletion: 100,
		competencyScore: 91,
		learningHours: 86,
		certificates: 11,
		completedModules: 32,
		upcomingAssessments: 0
	},
	{
		id: "u-suresh",
		name: "Suresh Bhatnagar",
		email: "suresh.bhatnagar@mospi.gov.in",
		role: "superadmin",
		designation: "Deputy Director General",
		department: "Training & NSSTA Coordination, MoSPI",
		cadre: "ISS 1995",
		region: "Delhi",
		experienceYears: 30,
		education: "M.Stat, ISI Kolkata",
		profileCompletion: 100,
		competencyScore: 93,
		learningHours: 64,
		certificates: 9,
		completedModules: 22,
		upcomingAssessments: 0
	}
];
var COURSES = [
	{
		id: "c-foundations",
		title: "Foundations of Official Statistics in India",
		provider: "iGOT Karmayogi",
		skills: [
			"Survey Design",
			"National Accounts",
			"Communication"
		],
		durationHours: 8,
		rating: 4.7,
		level: "Foundation",
		description: "Orientation to the Indian Statistical System, MoSPI mandate, and the National Statistical Commission framework.",
		language: "English / Hindi",
		competencyIds: [
			"survey-design",
			"national-accounts",
			"communication"
		],
		modules: 6
	},
	{
		id: "c-sampling",
		title: "Sampling Techniques for Large-Scale Household Surveys",
		provider: "NSSTA TPAC",
		skills: ["Sampling", "Survey Design"],
		durationHours: 24,
		rating: 4.8,
		level: "Advanced",
		description: "Stratification, PPS, and multi-stage designs used in PLFS, HCES, and NSS rounds, with design-weight practice.",
		language: "English",
		competencyIds: ["sampling", "survey-design"],
		modules: 10
	},
	{
		id: "c-na",
		title: "National Accounts Compilation: SNA 2008 to SNA 2025",
		provider: "NSSTA TPAC",
		skills: ["National Accounts", "SQL"],
		durationHours: 20,
		rating: 4.6,
		level: "Advanced",
		description: "Sequence of accounts, supply-use tables, and bridging to the new SNA revision for NAD officers.",
		language: "English",
		competencyIds: ["national-accounts", "sql"],
		modules: 8
	},
	{
		id: "c-python",
		title: "Python for Official Statistics",
		provider: "iGOT Karmayogi",
		skills: ["Python", "Data Visualization"],
		durationHours: 16,
		rating: 4.5,
		level: "Intermediate",
		description: "Pandas pipelines for microdata, reproducible notebooks, and publication-grade tables from unit-level files.",
		language: "English",
		competencyIds: ["python", "dataviz"],
		modules: 9
	},
	{
		id: "c-r",
		title: "Statistical Computing with R for NSS and PLFS",
		provider: "NSSTA TPAC",
		skills: [
			"R",
			"Sampling",
			"Data Visualization"
		],
		durationHours: 18,
		rating: 4.6,
		level: "Intermediate",
		description: "survey and srvyr packages, replicate weights, and ggplot2 for official releases.",
		language: "English",
		competencyIds: [
			"r",
			"sampling",
			"dataviz"
		],
		modules: 8
	},
	{
		id: "c-sql",
		title: "SQL for ASUSE, PLFS and e-Sankhyiki Warehouses",
		provider: "NSSTA TPAC",
		skills: ["SQL", "Data Privacy"],
		durationHours: 12,
		rating: 4.4,
		level: "Intermediate",
		description: "Querying enterprise and labour-force warehouses with audit-safe joins and suppression rules.",
		language: "English / Hindi",
		competencyIds: ["sql", "privacy"],
		modules: 6
	},
	{
		id: "c-gis",
		title: "GIS for Census, FASAL and Local-Level Statistics",
		provider: "iGOT Karmayogi",
		skills: ["GIS", "Survey Design"],
		durationHours: 14,
		rating: 4.3,
		level: "Intermediate",
		description: "QGIS workflows for enumeration-block mapping, crop statistics, and geo-enabled sample frames.",
		language: "English",
		competencyIds: ["gis", "survey-design"],
		modules: 7
	},
	{
		id: "c-viz",
		title: "Data Visualization for Policy Briefs",
		provider: "iGOT Karmayogi",
		skills: ["Data Visualization", "Communication"],
		durationHours: 6,
		rating: 4.5,
		level: "Foundation",
		description: "Chart discipline for PIB releases, dashboarding for senior officers, and accessible colour systems.",
		language: "English / Hindi",
		competencyIds: ["dataviz", "communication"],
		modules: 4
	},
	{
		id: "c-aiml",
		title: "AI and Machine Learning for Statistical Production",
		provider: "StatSkill AI",
		skills: ["AI / ML", "Python"],
		durationHours: 16,
		rating: 4.7,
		level: "Advanced",
		description: "Nowcasting, imputation, anomaly detection, and responsible-AI checks on official microdata.",
		language: "English",
		competencyIds: ["aiml", "python"],
		modules: 8
	},
	{
		id: "c-cyber",
		title: "Cybersecurity for Government Statistical Systems",
		provider: "iGOT Karmayogi",
		skills: ["Cybersecurity", "Data Privacy"],
		durationHours: 8,
		rating: 4.4,
		level: "Foundation",
		description: "NIC cloud controls, MeitY guidelines, and incident hygiene for data-holding divisions.",
		language: "English / Hindi",
		competencyIds: ["cyber", "privacy"],
		modules: 5
	},
	{
		id: "c-dpdp",
		title: "DPDP Act 2023 and Confidentiality in Official Statistics",
		provider: "iGOT Karmayogi",
		skills: ["Data Privacy", "Leadership"],
		durationHours: 5,
		rating: 4.6,
		level: "Foundation",
		description: "Lawful processing, anonymisation standards, and the Collection of Statistics Act interface.",
		language: "English / Hindi",
		competencyIds: ["privacy", "leadership"],
		modules: 4
	},
	{
		id: "c-lead",
		title: "Leadership in Public Service: Mission Karmayogi",
		provider: "iGOT Karmayogi",
		skills: [
			"Leadership",
			"Communication",
			"Project Management"
		],
		durationHours: 10,
		rating: 4.5,
		level: "Intermediate",
		description: "Competency-based HR, FRAC, and leading mixed ISS–SSS teams through survey cycles.",
		language: "Hindi / English",
		competencyIds: [
			"leadership",
			"communication",
			"pm"
		],
		modules: 6
	},
	{
		id: "c-comm",
		title: "Writing for Policy: Notes, Releases and Parliamentary Replies",
		provider: "iGOT Karmayogi",
		skills: ["Communication"],
		durationHours: 6,
		rating: 4.4,
		level: "Foundation",
		description: "Plain-language statistical communication for Cabinet notes and standing-committee briefs.",
		language: "English / Hindi",
		competencyIds: ["communication"],
		modules: 4
	},
	{
		id: "c-pm",
		title: "Project Management for Survey Operations",
		provider: "NSSTA TPAC",
		skills: [
			"Project Management",
			"Survey Design",
			"Leadership"
		],
		durationHours: 12,
		rating: 4.5,
		level: "Intermediate",
		description: "Field calendar control, vendor SLAs, and risk registers for all-India survey rounds.",
		language: "English",
		competencyIds: [
			"pm",
			"survey-design",
			"leadership"
		],
		modules: 7
	}
];
var WORKFORCE = [
	{
		id: "w1",
		name: "Priya Sharma",
		designation: "Joint Director",
		department: "National Accounts Division",
		region: "Delhi",
		cadre: "ISS",
		score: 64,
		completionRate: 71,
		hours: 46,
		topGap: "Python",
		domainScores: {
			statistical: 79,
			technical: 51,
			digital: 58,
			behavioural: 75
		}
	},
	{
		id: "w2",
		name: "Arjun Patel",
		designation: "Deputy Director",
		department: "Field Operations Division",
		region: "Gujarat",
		cadre: "ISS",
		score: 61,
		completionRate: 54,
		hours: 28,
		topGap: "AI / ML",
		domainScores: {
			statistical: 82,
			technical: 44,
			digital: 49,
			behavioural: 70
		}
	},
	{
		id: "w3",
		name: "Meera Krishnan",
		designation: "Director",
		department: "Price Statistics Division",
		region: "Tamil Nadu",
		cadre: "ISS",
		score: 77,
		completionRate: 88,
		hours: 62,
		topGap: "GIS",
		domainScores: {
			statistical: 85,
			technical: 63,
			digital: 72,
			behavioural: 81
		}
	},
	{
		id: "w4",
		name: "Farhan Qureshi",
		designation: "Senior Statistical Officer",
		department: "Survey Design & Research",
		region: "Uttar Pradesh",
		cadre: "SSS",
		score: 58,
		completionRate: 41,
		hours: 19,
		topGap: "Python",
		domainScores: {
			statistical: 74,
			technical: 38,
			digital: 46,
			behavioural: 64
		}
	},
	{
		id: "w5",
		name: "Ananya Bose",
		designation: "Joint Director",
		department: "Data Informatics & Innovation",
		region: "West Bengal",
		cadre: "ISS",
		score: 81,
		completionRate: 79,
		hours: 71,
		topGap: "Leadership",
		domainScores: {
			statistical: 70,
			technical: 88,
			digital: 84,
			behavioural: 68
		}
	},
	{
		id: "w6",
		name: "Vikram Singh",
		designation: "Deputy Director",
		department: "Industrial Statistics",
		region: "Rajasthan",
		cadre: "ISS",
		score: 66,
		completionRate: 63,
		hours: 34,
		topGap: "Data Privacy",
		domainScores: {
			statistical: 76,
			technical: 55,
			digital: 52,
			behavioural: 72
		}
	},
	{
		id: "w7",
		name: "Lakshmi Nair",
		designation: "Additional Director General",
		department: "Social Statistics Division",
		region: "Kerala",
		cadre: "ISS",
		score: 84,
		completionRate: 91,
		hours: 58,
		topGap: "AI / ML",
		domainScores: {
			statistical: 90,
			technical: 61,
			digital: 77,
			behavioural: 88
		}
	},
	{
		id: "w8",
		name: "Rohit Joshi",
		designation: "Junior Statistical Officer",
		department: "Sampling Design",
		region: "Maharashtra",
		cadre: "SSS",
		score: 52,
		completionRate: 33,
		hours: 14,
		topGap: "SQL",
		domainScores: {
			statistical: 68,
			technical: 35,
			digital: 40,
			behavioural: 58
		}
	},
	{
		id: "w9",
		name: "Fatima Sheikh",
		designation: "Director",
		department: "Data Informatics & Innovation",
		region: "Telangana",
		cadre: "ISS",
		score: 79,
		completionRate: 84,
		hours: 67,
		topGap: "Communication",
		domainScores: {
			statistical: 72,
			technical: 86,
			digital: 81,
			behavioural: 69
		}
	},
	{
		id: "w10",
		name: "C. Murugan",
		designation: "Deputy Director",
		department: "Agriculture Statistics",
		region: "Karnataka",
		cadre: "ISS",
		score: 63,
		completionRate: 57,
		hours: 31,
		topGap: "Python",
		domainScores: {
			statistical: 80,
			technical: 46,
			digital: 55,
			behavioural: 71
		}
	},
	{
		id: "w11",
		name: "Neha Verma",
		designation: "Senior Statistical Officer",
		department: "National Accounts Division",
		region: "Madhya Pradesh",
		cadre: "SSS",
		score: 57,
		completionRate: 48,
		hours: 22,
		topGap: "R",
		domainScores: {
			statistical: 73,
			technical: 41,
			digital: 50,
			behavioural: 62
		}
	},
	{
		id: "w12",
		name: "Tenzin Dorjee",
		designation: "Deputy Director",
		department: "Directorate of Economics & Statistics",
		region: "Sikkim",
		cadre: "ISS",
		score: 70,
		completionRate: 76,
		hours: 39,
		topGap: "Cybersecurity",
		domainScores: {
			statistical: 77,
			technical: 58,
			digital: 61,
			behavioural: 78
		}
	}
];
var DEPARTMENTS = [
	"National Accounts Division",
	"Field Operations Division",
	"Price Statistics Division",
	"Survey Design & Research",
	"Data Informatics & Innovation",
	"Industrial Statistics",
	"Social Statistics Division",
	"Sampling Design",
	"Agriculture Statistics",
	"Directorate of Economics & Statistics"
];
var DESIGNATIONS = [
	"Junior Statistical Officer",
	"Senior Statistical Officer",
	"Deputy Director",
	"Joint Director",
	"Director",
	"Additional Director General",
	"Deputy Director General",
	"Faculty (Sampling Theory)"
];
var REGIONS = [
	"Delhi",
	"Gujarat",
	"Tamil Nadu",
	"Uttar Pradesh",
	"West Bengal",
	"Rajasthan",
	"Kerala",
	"Maharashtra",
	"Telangana",
	"Karnataka",
	"Madhya Pradesh",
	"Sikkim"
];
var JOB_ROLES = [
	"National Accounts Compiler",
	"Survey Operations Manager",
	"Sampling Methodologist",
	"Price Index Analyst",
	"Data Engineer (Official Statistics)",
	"Field Supervision (FOD)",
	"State DES Coordinator",
	"Training Faculty, NSSTA"
];
var CAREER_PATHS = [
	"Director / DDG track (generalist ISS)",
	"Specialist — Data Science & AI",
	"Specialist — National Accounts",
	"Specialist — Survey Methodology",
	"State DES leadership",
	"NSSTA faculty"
];
var UPCOMING = [
	{
		id: "ua1",
		title: "Mid-career competency check — NAD cohort",
		date: "12 Sep 2026",
		type: "assessment",
		venue: "Online · StatSkill AI"
	},
	{
		id: "ua2",
		title: "NSSTA TPAC: Sampling refresher (Week 2)",
		date: "18 Sep 2026",
		type: "workshop",
		venue: "NSSTA, Greater Noida"
	},
	{
		id: "ua3",
		title: "iGOT: DPDP Act module completion window",
		date: "30 Sep 2026",
		type: "course",
		venue: "iGOT Karmayogi"
	}
];
var SAMPLE_DOCUMENTS = [{
	id: "plfs",
	name: "PLFS sampling note (excerpt).md",
	title: "Periodic Labour Force Survey — sampling design",
	content: `Periodic Labour Force Survey (PLFS) of the National Statistical Office uses a rotational panel design in urban areas and a visit-based design in rural areas.

First-stage units (FSUs) are census villages in rural areas and Urban Frame Survey blocks in urban areas. FSUs are selected by Probability Proportional to Size with Replacement (PPSWR), size being population as per the latest census.

Second-stage stratification: households are stratified by household type (self-employed, regular wage/salary, casual labour, others) before selecting second-stage units (SSUs) by Simple Random Sampling Without Replacement (SRSWOR).

Design weights equal the inverse of the inclusion probability at each stage, adjusted for non-response at FSU and household levels. Multiplier files released with unit-level data must be used for unbiased estimates of labour-force indicators such as LFPR, WPR and UR.

Key quality risks: frame ageing between censuses, substitution of FSUs, and under-coverage of seasonal migrant households. Officers compiling state-level estimates must check coefficient of variation before release.`
}, {
	id: "sna",
	name: "NAD compilation brief.md",
	title: "National Accounts — GVA compilation",
	content: `Gross Value Added (GVA) at basic prices is the central balancing item of the production account in the System of National Accounts.

For India, NAD compiles GVA by economic activity using a mix of census/survey benchmarks (ASI, ASUSE, livestock census) and current indicators (IIP, GST, corporate filings).

The production approach: output minus intermediate consumption. The income approach: compensation of employees + mixed income + other taxes on production + consumption of fixed capital + net operating surplus.

Double deflation is preferred for volume measures; where intermediate-consumption deflators are weak, single deflation is still used in some informal-sector activities.

SNA 2025 will expand treatment of data as an asset, unpaid household service work satellite accounts, and natural capital. NAD officers should map current compilation sheets to the new sequence of accounts before the next base-year revision.`
}];
var DEFAULT_PROFILE = {
	designation: "Joint Director",
	department: "National Accounts Division, NSO",
	jobRole: "National Accounts Compiler",
	education: "M.Stat, Indian Statistical Institute, Kolkata",
	experienceYears: 12,
	previousTrainings: "NSSTA induction; iGOT Mission Karmayogi foundation; SNA 2008 workshop 2023",
	currentAssignment: "GVA compilation for manufacturing and bridging ASI with GST filings",
	careerPath: "Specialist — Data Science & AI"
};
var ROLE_TARGETS = {
	"National Accounts Compiler": {
		"national-accounts": 92,
		sql: 80,
		python: 75,
		r: 70,
		dataviz: 78,
		aiml: 68,
		privacy: 80,
		communication: 82
	},
	"Survey Operations Manager": {
		"survey-design": 90,
		sampling: 85,
		pm: 88,
		leadership: 85,
		communication: 84,
		gis: 70,
		python: 60
	},
	"Sampling Methodologist": {
		sampling: 95,
		"survey-design": 90,
		r: 85,
		python: 80,
		sql: 70,
		dataviz: 75
	},
	"Data Engineer (Official Statistics)": {
		python: 92,
		sql: 92,
		aiml: 85,
		cyber: 82,
		privacy: 85,
		r: 70,
		dataviz: 80
	},
	"State DES Coordinator": {
		leadership: 88,
		pm: 85,
		communication: 88,
		"survey-design": 80,
		privacy: 78,
		dataviz: 75
	},
	default: {
		"survey-design": 80,
		sampling: 80,
		"national-accounts": 75,
		python: 70,
		r: 70,
		sql: 72,
		gis: 60,
		dataviz: 75,
		aiml: 65,
		cyber: 70,
		privacy: 78,
		leadership: 80,
		communication: 82,
		pm: 75
	}
};
var CAREER_BOOSTS = {
	"Specialist — Data Science & AI": {
		python: 15,
		aiml: 20,
		sql: 8,
		r: 8
	},
	"Specialist — National Accounts": {
		"national-accounts": 12,
		sql: 8,
		dataviz: 6
	},
	"Specialist — Survey Methodology": {
		sampling: 12,
		"survey-design": 10,
		r: 8
	},
	"State DES leadership": {
		leadership: 10,
		pm: 10,
		communication: 8
	},
	"NSSTA faculty": {
		communication: 10,
		leadership: 8,
		sampling: 6
	},
	"Director / DDG track (generalist ISS)": {
		leadership: 12,
		pm: 10,
		communication: 8
	}
};
function computeCompetencies(profile) {
	const base = COMPETENCIES.map((c) => ({ ...c }));
	const role = ROLE_TARGETS[profile.jobRole] ?? ROLE_TARGETS.default;
	const boosts = CAREER_BOOSTS[profile.careerPath] ?? {};
	const exp = Math.min(profile.experienceYears, 25);
	const train = profile.previousTrainings.toLowerCase();
	return base.map((c) => {
		const target = Math.min(98, (role[c.id] ?? c.target) + (boosts[c.id] ?? 0));
		let score = 38 + exp * 1.1;
		if (c.domain === "statistical") score += 18;
		if (c.domain === "behavioural") score += 12;
		if (train.includes("python") && c.id === "python") score += 18;
		if (train.includes("sna") && c.id === "national-accounts") score += 16;
		if (train.includes("sampling") && c.id === "sampling") score += 14;
		if (train.includes("karmayogi") && c.domain === "behavioural") score += 8;
		if (train.includes("dpdp") && c.id === "privacy") score += 12;
		if (profile.education.toLowerCase().includes("isi") && c.domain === "statistical") score += 10;
		if (profile.education.toLowerCase().includes("iit") && c.domain === "technical") score += 10;
		if (profile.jobRole.includes("Data Engineer") && c.domain === "technical") score += 16;
		if (profile.jobRole.includes("National Accounts") && c.id === "national-accounts") score += 14;
		if (profile.currentAssignment.toLowerCase().includes("gst") && c.id === "sql") score += 8;
		if (profile.currentAssignment.toLowerCase().includes("ai") && c.id === "aiml") score += 12;
		score = Math.max(18, Math.min(96, Math.round(score)));
		return {
			...c,
			score,
			target
		};
	});
}
function domainAverages(list) {
	const acc = {
		statistical: {
			sum: 0,
			n: 0,
			t: 0
		},
		technical: {
			sum: 0,
			n: 0,
			t: 0
		},
		digital: {
			sum: 0,
			n: 0,
			t: 0
		},
		behavioural: {
			sum: 0,
			n: 0,
			t: 0
		}
	};
	for (const c of list) {
		acc[c.domain].sum += c.score;
		acc[c.domain].t += c.target;
		acc[c.domain].n += 1;
	}
	return Object.keys(acc).map((domain) => ({
		domain,
		label: DOMAIN_LABEL[domain],
		score: Math.round(acc[domain].sum / acc[domain].n),
		target: Math.round(acc[domain].t / acc[domain].n)
	}));
}
function overallScore(list) {
	if (!list.length) return 0;
	return Math.round(list.reduce((s, c) => s + c.score, 0) / list.length);
}
function recommendCourses(list, limit = 4) {
	const gaps = [...list].sort((a, b) => b.target - b.score - (a.target - a.score));
	const picked = [];
	for (const g of gaps) for (const course of COURSES) {
		if (picked.find((p) => p.id === course.id)) continue;
		if (course.competencyIds.includes(g.id)) {
			picked.push(course);
			if (picked.length >= limit) return picked;
		}
	}
	return picked;
}
var INSIGHTS = [
	{
		title: "High demand for Python and AI/ML skills",
		body: "Eight of twelve divisions show a 20+ point gap on Python. NAD and FOD cohorts will miss SNA 2025 automation targets without a dedicated NSSTA TPAC track.",
		tag: "Demand"
	},
	{
		title: "Privacy competence lags DPDP timelines",
		body: "Mean Data Privacy score is 58. Divisions holding unit-level PLFS and HCES files should complete the DPDP module before the next public-use file release.",
		tag: "Risk"
	},
	{
		title: "Field Operations completion is the bottleneck",
		body: "FOD officers average 54% learning completion against 79% in DIID. Recommend protecting two hours a week during non-survey months.",
		tag: "Delivery"
	},
	{
		title: "SSS cadre needs a foundation SQL pathway",
		body: "Junior and Senior Statistical Officers cluster below 45 on SQL. A 12-hour iGOT + practical warehouse lab would close the largest volume gap.",
		tag: "Cadre"
	}
];
function applyTheme(theme) {
	if (typeof document === "undefined") return;
	document.documentElement.classList.toggle("dark", theme === "dark");
	localStorage.setItem("statskill-theme", theme);
}
var useAppStore = create()(persist((set, get) => ({
	user: null,
	theme: "light",
	lang: "en",
	profile: DEFAULT_PROFILE,
	assessmentResult: null,
	enrolments: [
		{
			courseId: "c-na",
			status: "in_progress",
			progress: 62
		},
		{
			courseId: "c-foundations",
			status: "completed",
			progress: 100
		},
		{
			courseId: "c-python",
			status: "not_started",
			progress: 0
		}
	],
	quizzes: [],
	activeQuizId: null,
	quizAnswers: {},
	quizStartedAt: null,
	chatMessages: [],
	chatOpen: false,
	signIn: (role) => {
		set({ user: DEMO_USERS.find((u) => u.role === role) ?? DEMO_USERS[0] });
	},
	signOut: () => set({
		user: null,
		chatOpen: false
	}),
	setTheme: (theme) => {
		applyTheme(theme);
		set({ theme });
	},
	setLang: (lang) => {
		if (typeof document !== "undefined") document.documentElement.lang = lang;
		set({ lang });
	},
	setProfile: (profile) => set({ profile }),
	saveAssessment: (narrative) => {
		const profile = get().profile;
		const competencies = computeCompetencies(profile);
		const recommended = recommendCourses(competencies).map((c) => c.id);
		set({ assessmentResult: {
			profile,
			competencies,
			narrative: narrative ?? "Role and career-path targets updated. Technical gaps (Python, AI/ML, GIS) remain the primary constraint on a data-science track.",
			recommendedCourseIds: recommended,
			generatedAt: (/* @__PURE__ */ new Date()).toISOString()
		} });
	},
	enrol: (courseId) => {
		const enrolments = get().enrolments;
		if (enrolments.some((e) => e.courseId === courseId)) {
			set({ enrolments: enrolments.map((e) => e.courseId === courseId && e.status === "not_started" ? {
				...e,
				status: "in_progress",
				progress: 8
			} : e) });
			return;
		}
		set({ enrolments: [...enrolments, {
			courseId,
			status: "in_progress",
			progress: 8
		}] });
	},
	advanceCourse: (courseId) => {
		set({ enrolments: get().enrolments.map((e) => {
			if (e.courseId !== courseId) return e;
			const progress = Math.min(100, e.progress + 20);
			return {
				...e,
				progress,
				status: progress >= 100 ? "completed" : "in_progress"
			};
		}) });
	},
	addQuiz: (quiz) => set({ quizzes: [quiz, ...get().quizzes] }),
	updateQuestion: (quizId, question) => {
		set({ quizzes: get().quizzes.map((q) => q.id === quizId ? {
			...q,
			questions: q.questions.map((item) => item.id === question.id ? question : item)
		} : q) });
	},
	setQuizStatus: (quizId, status) => {
		set({ quizzes: get().quizzes.map((q) => q.id === quizId ? {
			...q,
			status,
			published: status === "published"
		} : q) });
	},
	deleteQuiz: (quizId) => set({ quizzes: get().quizzes.filter((q) => q.id !== quizId) }),
	startQuiz: (quizId) => {
		const quiz = get().quizzes.find((q) => q.id === quizId);
		const answers = {};
		quiz?.questions.forEach((qn) => {
			answers[qn.id] = null;
		});
		set({
			activeQuizId: quizId,
			quizAnswers: answers,
			quizStartedAt: Date.now()
		});
	},
	answerQuestion: (questionId, index) => {
		set({ quizAnswers: {
			...get().quizAnswers,
			[questionId]: index
		} });
	},
	resetQuizRun: () => set({
		activeQuizId: null,
		quizAnswers: {},
		quizStartedAt: null
	}),
	setChatOpen: (open) => set({ chatOpen: open }),
	addChat: (msg) => set({ chatMessages: [...get().chatMessages, msg].slice(-24) }),
	clearChat: () => set({ chatMessages: [] })
}), {
	name: "statskill-ai",
	partialize: (s) => ({
		user: s.user,
		theme: s.theme,
		lang: s.lang,
		profile: s.profile,
		assessmentResult: s.assessmentResult,
		enrolments: s.enrolments,
		quizzes: s.quizzes,
		chatMessages: s.chatMessages
	})
}));
function AppProviders({ children }) {
	const theme = useAppStore((s) => s.theme);
	const lang = useAppStore((s) => s.lang);
	(0, import_react.useEffect)(() => {
		document.documentElement.classList.toggle("dark", theme === "dark");
		localStorage.setItem("statskill-theme", theme);
	}, [theme]);
	(0, import_react.useEffect)(() => {
		document.documentElement.lang = lang;
	}, [lang]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TooltipProvider, {
		delayDuration: 250,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
			position: "top-center",
			richColors: true,
			closeButton: true,
			theme,
			toastOptions: { className: "font-sans" }
		})]
	});
}
var styles_default = "/assets/styles-DlyamLDD.css";
var APP_NAME = "StatSkill AI";
var THEME_SCRIPT = `(function(){try{var t=localStorage.getItem("statskill-theme");if(!t){var raw=localStorage.getItem("statskill-ai");if(raw)t=JSON.parse(raw).state&&JSON.parse(raw).state.theme;}if(t==="dark")document.documentElement.classList.add("dark");}catch(e){}})();`;
var Route$10 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "StatSkill AI — skill intelligence and learning for India’s Official Statistical System."
			},
			{
				name: "theme-color",
				content: "#0B1D36"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:ital,wght@0,400;0,500;0,600;0,700;1,400&family=Source+Serif+4:opsz,wght@8..60,500;8..60,600;8..60,700&display=swap"
			}
		]
	}),
	errorComponent: AppErrorComponent,
	notFoundComponent: NotFound,
	component: RootDocument
});
function NotFound() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 bg-background px-6 text-center text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold uppercase tracking-[0.16em] text-accent",
				children: "404"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl font-semibold",
				children: "Page not in the statistical system"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm text-muted-foreground",
				children: "That route is not on StatSkill AI. Return to the landing page or sign in."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "/",
				className: "text-sm font-medium text-indigo underline-offset-4 hover:underline",
				children: "Back to home"
			})
		]
	});
}
function RootDocument() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "font-sans antialiased",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", { dangerouslySetInnerHTML: { __html: THEME_SCRIPT } }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppProviders, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	});
}
var $$splitComponentImporter$9 = () => import("./routes-Dm_LG0jG.mjs");
var Route$9 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("./admin-CIB4h-il.mjs");
var Route$8 = createFileRoute("/admin")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./assessment-DzzwTKud.mjs");
var Route$7 = createFileRoute("/assessment")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./courses-D69wF8S0.mjs");
var Route$6 = createFileRoute("/courses")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./dashboard-C50njsxk.mjs");
var Route$5 = createFileRoute("/dashboard")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./login-Rmh7BGK9.mjs");
var Route$4 = createFileRoute("/login")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./security-CfEonN_U.mjs");
var Route$3 = createFileRoute("/security")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./quiz.index-DhiE2xh3.mjs");
var Route$2 = createFileRoute("/quiz/")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./quiz.take-DwFdI-yS.mjs");
var Route$1 = createFileRoute("/quiz/take")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./quiz.trainer-pVUxXP9X.mjs");
var Route = createFileRoute("/quiz/trainer")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var IndexRoute = Route$9.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$10
});
var AdminRoute = Route$8.update({
	id: "/admin",
	path: "/admin",
	getParentRoute: () => Route$10
});
var AssessmentRoute = Route$7.update({
	id: "/assessment",
	path: "/assessment",
	getParentRoute: () => Route$10
});
var CoursesRoute = Route$6.update({
	id: "/courses",
	path: "/courses",
	getParentRoute: () => Route$10
});
var DashboardRoute = Route$5.update({
	id: "/dashboard",
	path: "/dashboard",
	getParentRoute: () => Route$10
});
var LoginRoute = Route$4.update({
	id: "/login",
	path: "/login",
	getParentRoute: () => Route$10
});
var SecurityRoute = Route$3.update({
	id: "/security",
	path: "/security",
	getParentRoute: () => Route$10
});
var QuizIndexRoute = Route$2.update({
	id: "/quiz/",
	path: "/quiz/",
	getParentRoute: () => Route$10
});
var rootRouteChildren = {
	IndexRoute,
	AdminRoute,
	AssessmentRoute,
	CoursesRoute,
	DashboardRoute,
	LoginRoute,
	SecurityRoute,
	QuizTakeRoute: Route$1.update({
		id: "/quiz/take",
		path: "/quiz/take",
		getParentRoute: () => Route$10
	}),
	QuizTrainerRoute: Route.update({
		id: "/quiz/trainer",
		path: "/quiz/trainer",
		getParentRoute: () => Route$10
	}),
	QuizIndexRoute
};
var routeTree = Route$10._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { useHydrated as S, domainAverages as _, COURSES as a, cn as b, DESIGNATIONS as c, JOB_ROLES as d, REGIONS as f, computeCompetencies as g, WORKFORCE as h, COMPETENCIES as i, DOMAIN_LABEL as l, UPCOMING as m, useAppStore as n, DEMO_USERS as o, SAMPLE_DOCUMENTS as p, CAREER_PATHS as r, DEPARTMENTS as s, router_exports as t, INSIGHTS as u, overallScore as v, downloadText as x, recommendCourses as y };
