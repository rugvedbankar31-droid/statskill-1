import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { d as useRouterState, v as Link, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Slot, s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as object, i as number, n as array, o as string, t as _enum } from "../_libs/zod.mjs";
import { D as ClipboardCheck, F as BookOpen, N as Brain, P as Bot, _ as ListChecks, a as Sun, f as Moon, h as LogOut, j as ChartColumn, l as Send, m as Menu, o as Shield, p as MessageCircle, t as X, v as LayoutDashboard, y as Languages } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as DialogPortal, i as DialogOverlay, n as DialogClose, r as DialogContent, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { S as useHydrated, b as cn, n as useAppStore } from "./router-LYI7r0H-.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { t as Root } from "../_libs/radix-ui__react-label.mjs";
import { n as Root$1, t as Indicator } from "../_libs/radix-ui__react-progress.mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/radix-ui__react-switch.mjs";
import { t as Root$2 } from "../_libs/radix-ui__react-separator.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/card-DlolnDSg.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LogoMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: cn("size-8", className),
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "32",
				height: "32",
				rx: "8",
				className: "fill-navy dark:fill-indigo"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "6",
				y: "18",
				width: "4.2",
				height: "8",
				rx: "1",
				className: "fill-saffron"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "12.2",
				y: "13",
				width: "4.2",
				height: "13",
				rx: "1",
				className: "fill-card"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "18.4",
				y: "8",
				width: "4.2",
				height: "18",
				rx: "1",
				className: "fill-card"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "25.2",
				cy: "9.2",
				r: "2.6",
				className: "fill-saffron"
			})
		]
	});
}
function Logo({ compact = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "flex items-center gap-2.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoMark, {}), !compact && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex flex-col leading-none",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-[15px] font-semibold tracking-tight text-foreground",
				children: "StatSkill AI"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-0.5 text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground",
				children: "Official Statistics"
			})]
		})]
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-lg text-sm font-medium transition-[color,background-color,box-shadow,transform,opacity] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70 disabled:pointer-events-none disabled:opacity-50 active:not-disabled:scale-[0.96] [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:bg-primary/90 shadow-card",
			accent: "bg-accent text-accent-foreground hover:bg-accent/90 shadow-card",
			outline: "border border-border bg-transparent text-foreground hover:bg-muted/70",
			secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
			ghost: "text-foreground hover:bg-muted/70",
			navy: "bg-indigo text-on-navy hover:bg-indigo/90",
			link: "text-indigo underline-offset-4 hover:underline"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 rounded-md px-3 text-xs",
			lg: "h-12 rounded-xl px-6",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var Sheet = Dialog;
var SheetContent = import_react.forwardRef(({ className, children, side = "left", ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-50 bg-navy/50 backdrop-blur-sm" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
	ref,
	className: cn("fixed z-50 flex h-full w-[min(20rem,88vw)] flex-col bg-card p-4 text-card-foreground shadow-lift", side === "left" ? "inset-y-0 left-0" : "inset-y-0 right-0", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-3 top-3 rounded-md p-1 text-muted-foreground hover:bg-muted",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
SheetContent.displayName = "SheetContent";
var Label = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	className: cn("text-sm font-medium leading-none text-foreground peer-disabled:opacity-70", className),
	...props
}));
Label.displayName = Root.displayName;
var badgeVariants = cva("inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium transition-colors", {
	variants: { variant: {
		default: "border-transparent bg-primary text-primary-foreground",
		accent: "border-transparent bg-accent/15 text-accent",
		outline: "border-border text-foreground",
		muted: "border-transparent bg-muted text-muted-foreground",
		success: "border-transparent bg-success/12 text-success",
		navy: "border-transparent bg-indigo/10 text-indigo"
	} },
	defaultVariants: { variant: "muted" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
var Progress = import_react.forwardRef(({ className, value, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root$1, {
	ref,
	className: cn("relative h-2 w-full overflow-hidden rounded-full bg-muted", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicator, {
		className: "h-full bg-accent transition-transform duration-500 ease-[cubic-bezier(0.22,1,0.36,1)]",
		style: { transform: `translateX(-${100 - (value || 0)}%)` }
	})
}));
Progress.displayName = Root$1.displayName;
var Switch = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
	className: cn("peer inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-accent data-[state=unchecked]:bg-muted", className),
	...props,
	ref,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: "pointer-events-none block size-5 rounded-full bg-card shadow-card ring-0 transition-transform data-[state=checked]:translate-x-5 data-[state=unchecked]:translate-x-0" })
}));
Switch.displayName = Switch$1.displayName;
var Separator = import_react.forwardRef(({ className, orientation = "horizontal", decorative = true, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root$2, {
	ref,
	decorative,
	orientation,
	className: cn("shrink-0 bg-border", orientation === "horizontal" ? "h-px w-full" : "h-full w-px", className),
	...props
}));
Separator.displayName = Root$2.displayName;
function Skeleton({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("animate-pulse rounded-lg bg-muted", className),
		...props
	});
}
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
	type,
	className: cn("flex h-11 w-full rounded-lg border border-input bg-card px-3 py-2 text-sm text-foreground shadow-card transition-[box-shadow,border-color] duration-150 placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70 disabled:cursor-not-allowed disabled:opacity-50", className),
	ref,
	...props
}));
Input.displayName = "Input";
var Textarea = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
	className: cn("flex min-h-28 w-full rounded-xl border border-input bg-card px-3 py-2 text-sm text-foreground shadow-card transition-[box-shadow,border-color] duration-150 placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70 disabled:cursor-not-allowed disabled:opacity-50", className),
	ref,
	...props
}));
Textarea.displayName = "Textarea";
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var quizInput = object({
	content: string().min(40).max(9e3),
	sourceName: string().max(180),
	count: number().min(3).max(12),
	difficulty: _enum([
		"easy",
		"medium",
		"hard",
		"mixed"
	]),
	language: _enum([
		"English",
		"Hindi",
		"Bilingual"
	]),
	durationMin: number().min(5).max(60)
});
var chatInput = object({
	messages: array(object({
		role: _enum(["user", "assistant"]),
		content: string().max(2e3)
	})).max(10),
	lang: _enum(["en", "hi"]),
	learnerContext: string().max(500).optional()
});
var insightInput = object({ profileSummary: string().min(20).max(2500) });
var generateQuizFn = createServerFn({ method: "POST" }).validator((input) => quizInput.parse(input)).handler(createSsrRpc("ec45b7171d1dfd81134b61f1e77afa0501e03bcb339faf7f8c6ff8766e822dbf"));
var chatAssistantFn = createServerFn({ method: "POST" }).validator((input) => chatInput.parse(input)).handler(createSsrRpc("5bdd17b3c46c31d7bdf35051d3222279bcfde07b5d96a18a205ccf932db639d8"));
var competencyNarrativeFn = createServerFn({ method: "POST" }).validator((input) => insightInput.parse(input)).handler(createSsrRpc("60bf5185720447ea393fa19c90000d8091b98f41386d223e032749213bfef49f"));
var dict = {
	en: {
		app: "StatSkill AI",
		tagline: "Skill Intelligence for Official Statistics",
		heroTitle: "Build a Future-Ready Statistical Workforce",
		heroBody: "AI competency assessment, personalised learning paths, and quiz generation for officers of India’s Official Statistical System — aligned with iGOT Karmayogi and NSSTA TPAC.",
		ctaPath: "Explore Learning Path",
		ctaAdmin: "Admin Dashboard",
		signIn: "Sign in",
		featuresTitle: "Designed for MoSPI, NSO and State DES cadres",
		feat1: "AI Skill Gap Analysis",
		feat1b: "Map role, assignment and career path to 14 competencies across four domains.",
		feat2: "iGOT Karmayogi Integration",
		feat2b: "Catalogue search, enrolment status and recommendations tied to live skill gaps.",
		feat3: "Smart Assessments",
		feat3b: "Turn manuals, decks and lecture video notes into tagged MCQs with explanations.",
		feat4: "Workforce Analytics",
		feat4b: "Department comparisons, completion rates and emerging skill demand for ADG/DDG.",
		navDashboard: "Dashboard",
		navAssessment: "Assessment",
		navQuiz: "Quiz Studio",
		navTrainer: "Trainer Desk",
		navCourses: "iGOT Catalogue",
		navAdmin: "Admin",
		navSecurity: "Security",
		welcome: "Welcome back",
		competency: "Competency score",
		hours: "Learning hours",
		certs: "Certificates",
		modules: "Modules completed",
		upcoming: "Upcoming assessments",
		roadmap: "Personalised learning roadmap",
		start: "Start Learning",
		continue: "Continue",
		enrol: "Enrol",
		enrolled: "Enrolled",
		recommended: "Recommended for your gaps",
		assistant: "Learning assistant",
		language: "Language",
		theme: "Theme",
		signOut: "Sign out",
		ssoTitle: "Continue with organisational SSO",
		ssoBody: "iGOT Karmayogi · NIC identity · MoSPI directory"
	},
	hi: {
		app: "StatSkill AI",
		tagline: "आधिकारिक सांख्यिकी के लिए कौशल बुद्धिमत्ता",
		heroTitle: "भविष्य के लिए तैयार सांख्यिकीय कार्यबल का निर्माण",
		heroBody: "भारत की आधिकारिक सांख्यिकी प्रणाली के अधिकारियों के लिए एआई दक्षता आकलन, व्यक्तिगत शिक्षण पथ और प्रश्नोत्तरी निर्माण — iGOT कर्मयोगी और NSSTA TPAC के अनुरूप।",
		ctaPath: "शिक्षण पथ देखें",
		ctaAdmin: "प्रशासक डैशबोर्ड",
		signIn: "साइन इन",
		featuresTitle: "MoSPI, NSO और राज्य DES काडर के लिए निर्मित",
		feat1: "एआई कौशल अंतर विश्लेषण",
		feat1b: "भूमिका, कार्य और करियर पथ को चार क्षेत्रों की 14 दक्षताओं से जोड़ें।",
		feat2: "iGOT कर्मयोगी एकीकरण",
		feat2b: "सूची खोज, नामांकन स्थिति और कौशल अंतर से जुड़ी सिफारिशें।",
		feat3: "स्मार्ट आकलन",
		feat3b: "नियमावली, प्रस्तुतियाँ और व्याख्यान नोट्स से व्याख्या सहित MCQ बनाएँ।",
		feat4: "कार्यबल विश्लेषण",
		feat4b: "विभाग तुलना, पूर्णता दर और उभरती कौशल मांग — ADG/DDG के लिए।",
		navDashboard: "डैशबोर्ड",
		navAssessment: "आकलन",
		navQuiz: "प्रश्नोत्तरी स्टूडियो",
		navTrainer: "प्रशिक्षक डेस्क",
		navCourses: "iGOT सूची",
		navAdmin: "प्रशासन",
		navSecurity: "सुरक्षा",
		welcome: "वापसी पर स्वागत है",
		competency: "दक्षता अंक",
		hours: "अध्ययन घंटे",
		certs: "प्रमाणपत्र",
		modules: "पूर्ण मॉड्यूल",
		upcoming: "आगामी आकलन",
		roadmap: "व्यक्तिगत शिक्षण पथ",
		start: "अध्ययन शुरू करें",
		continue: "जारी रखें",
		enrol: "नामांकन",
		enrolled: "नामांकित",
		recommended: "आपके अंतर के लिए अनुशंसित",
		assistant: "अध्ययन सहायक",
		language: "भाषा",
		theme: "थीम",
		signOut: "साइन आउट",
		ssoTitle: "संगठनात्मक SSO से जारी रखें",
		ssoBody: "iGOT कर्मयोगी · NIC पहचान · MoSPI निर्देशिका"
	}
};
function t(lang, key) {
	return dict[lang][key] ?? dict.en[key];
}
var PROMPTS = [
	"Build a 90-day plan to close my Python gap.",
	"Which NSSTA TPAC course fits sampling for PLFS?",
	"How does DPDP Act 2023 affect PLFS public-use files?"
];
function AssistantDock() {
	const open = useAppStore((s) => s.chatOpen);
	const setOpen = useAppStore((s) => s.setChatOpen);
	const messages = useAppStore((s) => s.chatMessages);
	const addChat = useAppStore((s) => s.addChat);
	const user = useAppStore((s) => s.user);
	const lang = useAppStore((s) => s.lang);
	const [draft, setDraft] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function send(text) {
		const content = text.trim();
		if (!content || busy) return;
		setDraft("");
		addChat({
			id: crypto.randomUUID(),
			role: "user",
			content
		});
		setBusy(true);
		try {
			const res = await chatAssistantFn({ data: {
				messages: [...useAppStore.getState().chatMessages].slice(-8).map((m) => ({
					role: m.role,
					content: m.content.slice(0, 1500)
				})),
				lang,
				learnerContext: user ? `${user.name}, ${user.designation}, ${user.department}, ${user.cadre}` : void 0
			} });
			if (!res.ok) {
				toast.error(res.error);
				addChat({
					id: crypto.randomUUID(),
					role: "assistant",
					content: "The assistant is unavailable just now. Try a catalogue search on iGOT or the Assessment page for rule-based gap recommendations."
				});
				return;
			}
			addChat({
				id: crypto.randomUUID(),
				role: "assistant",
				content: res.text
			});
		} catch {
			toast.error("Could not reach the assistant.");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick: () => setOpen(!open),
		className: "fixed bottom-5 right-5 z-40 flex size-14 items-center justify-center rounded-full bg-accent text-accent-foreground shadow-lift transition-transform duration-150 hover:scale-105 active:scale-[0.96]",
		"aria-label": t(lang, "assistant"),
		children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-5" })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("fixed bottom-24 right-5 z-40 flex w-[min(22rem,calc(100vw-1.5rem))] flex-col overflow-hidden rounded-2xl bg-card shadow-lift transition-[opacity,transform] duration-200", open ? "pointer-events-auto translate-y-0 opacity-100" : "pointer-events-none translate-y-2 opacity-0"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 border-b border-border bg-navy px-4 py-3 text-on-navy dark:bg-indigo",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bot, { className: "size-4 text-saffron" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold",
					children: t(lang, "assistant")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] text-on-navy/70",
					children: "Grounded in MoSPI / NSSTA curricula"
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex max-h-80 flex-col gap-2 overflow-y-auto p-3",
				children: [
					messages.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "Ask about competency gaps, iGOT courses, or a survey-cycle study plan."
						}), PROMPTS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "block w-full rounded-xl bg-muted/80 px-3 py-2 text-left text-xs hover:bg-muted",
							onClick: () => send(p),
							children: p
						}, p))]
					}),
					messages.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("max-w-[92%] rounded-xl px-3 py-2 text-sm leading-relaxed", m.role === "user" ? "ml-auto bg-indigo text-on-navy" : "bg-muted text-foreground"),
						children: m.content
					}, m.id)),
					busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-8 w-24 rounded-xl bg-muted shimmer",
						"aria-label": "Thinking"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex items-end gap-2 border-t border-border p-3",
				onSubmit: (e) => {
					e.preventDefault();
					send(draft);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					value: draft,
					onChange: (e) => setDraft(e.target.value),
					placeholder: "Ask StatSkill…",
					className: "min-h-12 resize-none",
					rows: 2
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					size: "icon",
					variant: "accent",
					disabled: busy || !draft.trim(),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" })
				})]
			})
		]
	})] });
}
var NAV = [
	{
		to: "/dashboard",
		key: "navDashboard",
		icon: LayoutDashboard,
		roles: "all"
	},
	{
		to: "/assessment",
		key: "navAssessment",
		icon: Brain,
		roles: "all"
	},
	{
		to: "/quiz",
		key: "navQuiz",
		icon: ListChecks,
		roles: "all"
	},
	{
		to: "/quiz/trainer",
		key: "navTrainer",
		icon: ClipboardCheck,
		roles: [
			"trainer",
			"admin",
			"superadmin"
		]
	},
	{
		to: "/courses",
		key: "navCourses",
		icon: BookOpen,
		roles: "all"
	},
	{
		to: "/admin",
		key: "navAdmin",
		icon: ChartColumn,
		roles: ["admin", "superadmin"]
	},
	{
		to: "/security",
		key: "navSecurity",
		icon: Shield,
		roles: ["admin", "superadmin"]
	}
];
function allowed(roles, role) {
	return roles === "all" || roles.includes(role);
}
function NavLinks({ onNavigate, collapsed }) {
	const lang = useAppStore((s) => s.lang);
	const user = useAppStore((s) => s.user);
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	if (!user) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "flex flex-col gap-1",
		children: NAV.filter((n) => allowed(n.roles, user.role)).map((item) => {
			const active = item.to === "/quiz" ? pathname === "/quiz" : pathname === item.to || pathname.startsWith(`${item.to}/`);
			const Icon = item.icon;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: item.to,
				onClick: onNavigate,
				className: cn("flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors", active ? "bg-indigo/12 text-indigo dark:bg-accent/15 dark:text-accent" : "text-muted-foreground hover:bg-muted hover:text-foreground", collapsed && "justify-center px-0"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4 shrink-0" }), !collapsed && t(lang, item.key)]
			}, item.to);
		})
	});
}
function SidebarBody({ onNavigate }) {
	const user = useAppStore((s) => s.user);
	const lang = useAppStore((s) => s.lang);
	const signOut = useAppStore((s) => s.signOut);
	const navigate = useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "px-2 py-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, { className: "mb-3" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex-1 overflow-y-auto px-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLinks, { onNavigate })
			}),
			user && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 rounded-xl bg-muted/70 p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-sm font-semibold",
						children: user.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-xs text-muted-foreground",
						children: user.designation
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-[11px] uppercase tracking-wide text-muted-foreground",
						children: user.role
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						size: "sm",
						className: "mt-2 w-full justify-start",
						onClick: () => {
							signOut();
							navigate({ to: "/" });
							onNavigate?.();
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" }), t(lang, "signOut")]
					})
				]
			})
		]
	});
}
function AppShell({ children }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const hydrated = useHydrated();
	const user = useAppStore((s) => s.user);
	const theme = useAppStore((s) => s.theme);
	const setTheme = useAppStore((s) => s.setTheme);
	const lang = useAppStore((s) => s.lang);
	const setLang = useAppStore((s) => s.setLang);
	const navigate = useNavigate();
	(0, import_react.useEffect)(() => {
		if (hydrated && !user) navigate({ to: "/login" });
	}, [
		hydrated,
		user,
		navigate
	]);
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-14 w-full" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "mt-6 h-64 w-full" })]
	});
	if (!user) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tricolor h-1 w-full" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-[calc(100vh-4px)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
					className: "hidden w-64 shrink-0 border-r border-border bg-card/70 p-3 lg:flex lg:flex-col",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarBody, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 flex-1 flex-col",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "sticky top-0 z-30 flex h-14 items-center justify-between gap-3 border-b border-border bg-background/80 px-4 backdrop-blur-md",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 lg:hidden",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon",
									onClick: () => setOpen(true),
									"aria-label": "Open menu",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { compact: true })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "hidden text-sm text-muted-foreground lg:block",
								children: [
									user.department,
									" · ",
									user.cadre,
									" · ",
									user.region
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "ml-auto flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon",
									"aria-label": "Toggle language",
									onClick: () => setLang(lang === "en" ? "hi" : "en"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Languages, { className: "size-4" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon",
									"aria-label": "Toggle theme",
									onClick: () => setTheme(theme === "dark" ? "light" : "dark"),
									children: theme === "dark" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-4" })
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
						className: "flex-1 px-4 py-6 sm:px-6 lg:px-8",
						children
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open,
				onOpenChange: setOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetContent, {
					side: "left",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarBody, { onNavigate: () => setOpen(false) })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AssistantDock, {})
		]
	});
}
function PageHeader({ eyebrow, title, description, actions }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			eyebrow && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-1 text-xs font-semibold uppercase tracking-[0.16em] text-accent",
				children: eyebrow
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl font-semibold tracking-tight",
				children: title
			}),
			description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-2xl text-sm text-muted-foreground",
				children: description
			})
		] }), actions]
	});
}
function MarketingNav() {
	const lang = useAppStore((s) => s.lang);
	const theme = useAppStore((s) => s.theme);
	const setTheme = useAppStore((s) => s.setTheme);
	const setLang = useAppStore((s) => s.setLang);
	const user = useAppStore((s) => s.user);
	const hydrated = useHydrated();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-40",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "tricolor h-1 w-full" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-3 border-b border-border bg-background/80 px-4 py-3 backdrop-blur-md sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-1 sm:gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "sm",
						onClick: () => setLang(lang === "en" ? "hi" : "en"),
						children: lang === "en" ? "हिन्दी" : "EN"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						"aria-label": "Toggle theme",
						onClick: () => setTheme(theme === "dark" ? "light" : "dark"),
						children: theme === "dark" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "accent",
						size: "sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: hydrated && user ? "/dashboard" : "/login",
							children: t(lang, "signIn")
						})
					})
				]
			})]
		})]
	});
}
var Card = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("rounded-2xl bg-card text-card-foreground shadow-card", className),
	...props
}));
Card.displayName = "Card";
var CardHeader = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("flex flex-col gap-1.5 p-6", className),
	...props
}));
CardHeader.displayName = "CardHeader";
var CardTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("font-display text-lg font-semibold leading-snug tracking-tight", className),
	...props
}));
CardTitle.displayName = "CardTitle";
var CardDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
CardDescription.displayName = "CardDescription";
var CardContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("p-6 pt-0", className),
	...props
}));
CardContent.displayName = "CardContent";
var CardFooter = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("flex items-center p-6 pt-0", className),
	...props
}));
CardFooter.displayName = "CardFooter";
//#endregion
export { competencyNarrativeFn as _, CardContent as a, Input as c, MarketingNav as d, PageHeader as f, Textarea as g, Switch as h, Card as i, Label as l, Skeleton as m, Badge as n, CardHeader as o, Progress as p, Button as r, CardTitle as s, AppShell as t, LogoMark as u, generateQuizFn as v, t as y };
