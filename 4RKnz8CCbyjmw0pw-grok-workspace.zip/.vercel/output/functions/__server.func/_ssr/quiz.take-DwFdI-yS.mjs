import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { b as cn, n as useAppStore } from "./router-LYI7r0H-.mjs";
import { a as CardContent, f as PageHeader, i as Card, n as Badge, p as Progress, r as Button, t as AppShell } from "./card-DlolnDSg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quiz.take-DwFdI-yS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function QuizTakePage() {
	const quizzes = useAppStore((s) => s.quizzes);
	const activeQuizId = useAppStore((s) => s.activeQuizId);
	const answers = useAppStore((s) => s.quizAnswers);
	const startedAt = useAppStore((s) => s.quizStartedAt);
	const answerQuestion = useAppStore((s) => s.answerQuestion);
	const reset = useAppStore((s) => s.resetQuizRun);
	const navigate = useNavigate();
	const quiz = quizzes.find((q) => q.id === activeQuizId) ?? quizzes[0];
	const [index, setIndex] = (0, import_react.useState)(0);
	const [submitted, setSubmitted] = (0, import_react.useState)(false);
	const [now, setNow] = (0, import_react.useState)(Date.now());
	(0, import_react.useEffect)(() => {
		if (!quiz) return;
		const id = window.setInterval(() => setNow(Date.now()), 1e3);
		return () => window.clearInterval(id);
	}, [quiz]);
	const remaining = (0, import_react.useMemo)(() => {
		if (!quiz || !startedAt) return quiz ? quiz.durationMin * 60 : 0;
		const elapsed = Math.floor((now - startedAt) / 1e3);
		return Math.max(0, quiz.durationMin * 60 - elapsed);
	}, [
		quiz,
		startedAt,
		now
	]);
	(0, import_react.useEffect)(() => {
		if (quiz && remaining === 0 && !submitted) setSubmitted(true);
	}, [
		remaining,
		submitted,
		quiz
	]);
	if (!quiz) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		title: "No paper in session",
		description: "Generate a quiz first, then sit the paper."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		asChild: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/quiz",
			children: "Open Quiz Studio"
		})
	})] });
	const q = quiz.questions[index];
	const answered = Object.values(answers).filter((v) => v !== null && v !== void 0).length;
	const correct = quiz.questions.filter((item) => answers[item.id] === item.correctIndex).length;
	const pct = Math.round(answered / quiz.questions.length * 100);
	const mm = String(Math.floor(remaining / 60)).padStart(2, "0");
	const ss = String(remaining % 60).padStart(2, "0");
	if (submitted) {
		const scorePct = Math.round(correct / quiz.questions.length * 100);
		const weak = quiz.questions.filter((item) => answers[item.id] !== item.correctIndex);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				eyebrow: "Instant evaluation",
				title: `Score ${scorePct}%`,
				description: `${correct} of ${quiz.questions.length} correct · ${quiz.title}`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "mb-4 p-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm leading-relaxed text-muted-foreground",
					children: scorePct >= 80 ? "Strong command of this material. Consider writing a short teaching note for NSSTA peers on the items you missed." : scorePct >= 55 ? "Solid core, with gaps on method detail. Revisit the source excerpt and retake after a focused hour." : "Treat this as a diagnostic. Enrol in the matching iGOT / NSSTA module and sit a shorter paper in a week."
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3",
				children: quiz.questions.map((item, i) => {
					const ok = answers[item.id] === item.correctIndex;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: ok ? "success" : "muted",
									children: ok ? "Correct" : "Review"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-muted-foreground",
									children: [
										item.topic,
										" · ",
										item.difficulty
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 font-medium",
								children: [
									i + 1,
									". ",
									item.question
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted-foreground",
								children: item.explanation
							})
						]
					}, item.id);
				})
			}),
			weak.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-sm text-muted-foreground",
				children: [
					"Focus next: ",
					Array.from(new Set(weak.map((w) => w.topic))).join(", "),
					"."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 flex gap-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => {
						reset();
						navigate({ to: "/quiz" });
					},
					children: "Back to studio"
				})
			})
		] });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex flex-wrap items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold uppercase tracking-[0.14em] text-accent",
				children: quiz.sourceName
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl font-semibold",
				children: quiz.title
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3 rounded-xl bg-card px-4 py-2 shadow-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "font-mono text-lg tabular-nums",
					children: [
						mm,
						":",
						ss
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted-foreground",
					children: "remaining"
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
			value: pct,
			className: "mb-6"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
			className: "p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					children: [
						"Question ",
						index + 1,
						" of ",
						quiz.questions.length,
						" · ",
						q.topic,
						" · ",
						q.difficulty
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 font-display text-xl font-semibold leading-snug",
					children: q.question
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 grid gap-2",
					children: q.options.map((opt, i) => {
						const selected = answers[q.id] === i;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => answerQuestion(q.id, i),
							className: cn("rounded-xl border px-4 py-3 text-left text-sm transition-colors", selected ? "border-accent bg-accent/10" : "border-border bg-card hover:bg-muted/60"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mr-2 font-mono text-xs text-muted-foreground",
								children: String.fromCharCode(65 + i)
							}), opt]
						}, opt);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						disabled: index === 0,
						onClick: () => setIndex((i) => i - 1),
						children: "Previous"
					}), index < quiz.questions.length - 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => setIndex((i) => i + 1),
						children: "Next"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "accent",
						onClick: () => setSubmitted(true),
						children: "Submit paper"
					})]
				})
			]
		}) })
	] });
}
//#endregion
export { QuizTakePage as component };
