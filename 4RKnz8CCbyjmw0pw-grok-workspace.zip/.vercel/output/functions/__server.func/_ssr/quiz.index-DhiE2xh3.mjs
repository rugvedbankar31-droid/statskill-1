import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { d as Play, n as Upload, w as FileUp } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as useAppStore, p as SAMPLE_DOCUMENTS } from "./router-LYI7r0H-.mjs";
import { a as CardContent, c as Input, f as PageHeader, g as Textarea, i as Card, l as Label, n as Badge, o as CardHeader, p as Progress, r as Button, s as CardTitle, t as AppShell, v as generateQuizFn } from "./card-DlolnDSg.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DbRRFmVH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quiz.index-DhiE2xh3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STEPS = [
	"Upload",
	"Extract concepts",
	"Draft MCQs",
	"Tag difficulty"
];
function QuizStudio() {
	const addQuiz = useAppStore((s) => s.addQuiz);
	const quizzes = useAppStore((s) => s.quizzes);
	const startQuiz = useAppStore((s) => s.startQuiz);
	const navigate = useNavigate();
	const [sourceName, setSourceName] = (0, import_react.useState)("Untitled source");
	const [content, setContent] = (0, import_react.useState)("");
	const [count, setCount] = (0, import_react.useState)("6");
	const [difficulty, setDifficulty] = (0, import_react.useState)("mixed");
	const [language, setLanguage] = (0, import_react.useState)("English");
	const [durationMin, setDurationMin] = (0, import_react.useState)("15");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [step, setStep] = (0, import_react.useState)(0);
	const [fileError, setFileError] = (0, import_react.useState)("");
	const canGenerate = content.trim().length >= 40;
	async function onFile(file) {
		setFileError("");
		setSourceName(file.name);
		if (file.type.startsWith("text/") || /\.(md|txt|csv|json)$/i.test(file.name)) {
			const text = await file.text();
			setContent(text.slice(0, 9e3));
			toast.success(`Loaded ${file.name}`);
			return;
		}
		setContent((prev) => prev || `Document: ${file.name} (${Math.round(file.size / 1024)} KB, ${file.type || "binary"}).\n\nExtracted text is unavailable in the browser for this format. Paste an excerpt or load a sample PLFS / NAD note, then generate.`);
		toast.message("Binary formats need an excerpt. Paste key pages or use a sample document.");
	}
	async function generate() {
		if (!canGenerate) {
			setFileError("Add at least 40 characters of source material.");
			return;
		}
		setBusy(true);
		setStep(1);
		const timers = [window.setTimeout(() => setStep(2), 600), window.setTimeout(() => setStep(3), 1400)];
		try {
			const res = await generateQuizFn({ data: {
				content: content.slice(0, 8500),
				sourceName,
				count: Number(count),
				difficulty,
				language,
				durationMin: Number(durationMin)
			} });
			if (!res.ok) {
				toast.error(res.error);
				return;
			}
			const quiz = {
				id: crypto.randomUUID(),
				title: res.quiz.title,
				sourceName,
				language,
				durationMin: Number(durationMin),
				difficulty,
				questions: res.quiz.questions,
				createdAt: (/* @__PURE__ */ new Date()).toISOString(),
				published: false,
				status: "draft"
			};
			addQuiz(quiz);
			setStep(4);
			toast.success(`Drafted ${quiz.questions.length} questions. Open Trainer Desk to approve.`);
		} catch {
			toast.error("Generation failed.");
		} finally {
			timers.forEach(clearTimeout);
			setBusy(false);
		}
	}
	const progress = (0, import_react.useMemo)(() => busy ? Math.min(90, 20 + step * 22) : step >= 4 ? 100 : 0, [busy, step]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		eyebrow: "Assessment studio",
		title: "Quiz and MCQ generator",
		description: "Upload a note, deck excerpt or video transcript. StatSkill drafts tagged questions with explanations for NSSTA and iGOT programmes."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6 lg:grid-cols-[1.1fr_0.9fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Source material" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex cursor-pointer flex-col items-center justify-center rounded-2xl border border-dashed border-border bg-muted/40 px-4 py-8 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-6 text-indigo" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm font-medium",
							children: "Drop PDF, PPT, video notes or text"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "Text files load directly. For PDF/PPT, paste an excerpt."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							className: "sr-only",
							accept: ".pdf,.ppt,.pptx,.md,.txt,.csv,.json,video/*,application/pdf",
							onChange: (e) => {
								const file = e.target.files?.[0];
								if (file) onFile(file);
							}
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: SAMPLE_DOCUMENTS.map((doc) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						size: "sm",
						variant: "outline",
						onClick: () => {
							setSourceName(doc.name);
							setContent(doc.content);
							toast.success(`Loaded ${doc.title}`);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileUp, { className: "size-3.5" }), doc.title]
					}, doc.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Source name" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: sourceName,
						onChange: (e) => setSourceName(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Content" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							className: "min-h-40",
							value: content,
							onChange: (e) => setContent(e.target.value),
							placeholder: "Paste lecture notes, a chapter, or a methodology excerpt…"
						}),
						fileError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-destructive",
							children: fileError
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Questions",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: count,
								onValueChange: setCount,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: [
									"4",
									"6",
									"8",
									"10",
									"12"
								].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: n,
									children: n
								}, n)) })]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Difficulty",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: difficulty,
								onValueChange: (v) => setDifficulty(v),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "easy",
										children: "Easy"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "medium",
										children: "Medium"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "hard",
										children: "Hard"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "mixed",
										children: "Mixed"
									})
								] })]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Language",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: language,
								onValueChange: (v) => setLanguage(v),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "English",
										children: "English"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "Hindi",
										children: "Hindi"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "Bilingual",
										children: "Bilingual"
									})
								] })]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Duration (minutes)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: durationMin,
								onValueChange: setDurationMin,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: [
									"10",
									"15",
									"20",
									"30",
									"45"
								].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: n,
									children: n
								}, n)) })]
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "accent",
					disabled: busy,
					onClick: () => void generate(),
					className: "w-full sm:w-auto",
					children: busy ? "Generating…" : "Generate MCQs"
				}),
				(busy || step >= 4) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, { value: progress }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 flex flex-wrap gap-2 text-[11px] text-muted-foreground",
					children: STEPS.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: i < step ? "text-accent" : "",
						children: s
					}, s))
				})] })
			]
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Drafts in this session" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: quizzes.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-2xl bg-muted/50 px-4 py-10 text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-medium",
				children: "No quizzes yet"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Load the PLFS sampling note and generate a six-question paper to see the trainer flow."
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-3",
			children: quizzes.map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-xl border border-border p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: q.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [
							q.questions.length,
							" questions · ",
							q.durationMin,
							" min · ",
							q.difficulty
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: q.status === "published" ? "success" : "muted",
						children: q.status
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					className: "mt-3",
					onClick: () => {
						startQuiz(q.id);
						navigate({ to: "/quiz/take" });
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-3.5" }), "Sit paper"]
				})]
			}, q.id))
		}) })] })]
	})] });
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }), children]
	});
}
//#endregion
export { QuizStudio as component };
