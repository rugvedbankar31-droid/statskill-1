import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { C as Gauge, F as BookOpen, L as ArrowRight, N as Brain, O as CircleCheck, T as Cloud, g as Lock, i as TrendingUp, j as ChartColumn, o as Shield } from "../_libs/lucide-react.mjs";
import { S as useHydrated, n as useAppStore } from "./router-LYI7r0H-.mjs";
import { d as MarketingNav, i as Card, n as Badge, r as Button, u as LogoMark, y as t } from "./card-DlolnDSg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Dm_LG0jG.js
var import_jsx_runtime = require_jsx_runtime();
var FEATURES = [
	{
		key: "feat1",
		body: "feat1b",
		icon: Gauge
	},
	{
		key: "feat2",
		body: "feat2b",
		icon: BookOpen
	},
	{
		key: "feat3",
		body: "feat3b",
		icon: Brain
	},
	{
		key: "feat4",
		body: "feat4b",
		icon: ChartColumn
	}
];
var STEPS = [
	{
		n: "01",
		title: "Assess the officer, not a generic role",
		body: "Designation, assignment and career path drive a 14-competency heatmap across statistical, technical, digital and behavioural domains."
	},
	{
		n: "02",
		title: "Open a personalised iGOT / NSSTA path",
		body: "Recommendations bind to live gaps — Python for NAD compilers, sampling for FOD, DPDP for divisions holding unit-level files."
	},
	{
		n: "03",
		title: "Turn training material into quizzes",
		body: "Upload a PLFS note or SNA brief. StatSkill drafts tagged MCQs, trainers approve, learners sit a timed paper with explanations."
	}
];
function Home() {
	const lang = useAppStore((s) => s.lang);
	const user = useAppStore((s) => s.user);
	const authed = useHydrated() && Boolean(user);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarketingNav, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative overflow-hidden bg-navy text-on-navy",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hero-grid pointer-events-none absolute inset-0 opacity-70" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -right-24 -top-24 size-80 rounded-full bg-indigo/50 blur-3xl" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative mx-auto grid max-w-6xl gap-12 px-4 py-16 sm:px-6 lg:grid-cols-[1.1fr_0.9fr] lg:py-24",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "stagger-in",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "accent",
									className: "border-0 bg-saffron/15 text-saffron",
									children: "Mission Karmayogi · NSSTA TPAC · MoSPI"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "mt-5 font-display text-4xl font-semibold leading-[1.12] tracking-tight sm:text-5xl lg:text-[3.4rem]",
									children: t(lang, "heroTitle")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-5 max-w-xl text-base leading-relaxed text-on-navy/75 sm:text-lg",
									children: t(lang, "heroBody")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-8 flex flex-col gap-3 sm:flex-row",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										asChild: true,
										variant: "accent",
										size: "lg",
										className: "pr-3.5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
											to: authed ? "/dashboard" : "/login",
											children: [t(lang, "ctaPath"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										asChild: true,
										variant: "outline",
										size: "lg",
										className: "border-on-navy/20 bg-transparent text-on-navy hover:bg-on-navy/10",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: authed && (user?.role === "admin" || user?.role === "superadmin") ? "/admin" : "/login",
											children: t(lang, "ctaAdmin")
										})
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
									className: "mt-10 grid grid-cols-3 gap-4 border-t border-on-navy/10 pt-6 text-sm",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-on-navy/55",
											children: "Competencies"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "mt-1 font-display text-2xl font-semibold tabular-nums",
											children: "14"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-on-navy/55",
											children: "Catalogue"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "mt-1 font-display text-2xl font-semibold tabular-nums",
											children: "14"
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-on-navy/55",
											children: "Cadres"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "mt-1 font-display text-2xl font-semibold",
											children: "ISS · SSS"
										})] })
									]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroPreview, {})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "border-b border-border bg-card/60",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-4 px-4 py-4 text-xs font-medium uppercase tracking-[0.16em] text-muted-foreground sm:px-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "MoSPI" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "NSO" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "NSSTA" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "iGOT Karmayogi" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Mission Karmayogi" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "NIC Cloud ready" })
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto max-w-6xl px-4 py-16 sm:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-[0.16em] text-accent",
						children: "Platform"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 font-display text-3xl font-semibold",
						children: t(lang, "featuresTitle")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 grid gap-4 sm:grid-cols-2",
						children: FEATURES.map((f) => {
							const Icon = f.icon;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
								className: "glass-panel p-6 transition-shadow duration-200 hover:shadow-lift",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex size-10 items-center justify-center rounded-xl bg-indigo/10 text-indigo",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-4 font-display text-xl font-semibold",
										children: t(lang, f.key)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm leading-relaxed text-muted-foreground",
										children: t(lang, f.body)
									})
								]
							}, f.key);
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "bg-card/50 py-16",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-6xl gap-10 px-4 sm:px-6 lg:grid-cols-[0.9fr_1.1fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold uppercase tracking-[0.16em] text-accent",
							children: "How it works"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-2 font-display text-3xl font-semibold",
							children: "Three steps from role to ready"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-muted-foreground",
							children: "Built as a learning product, not a circular. Officers keep a living competency file that follows them from NSSTA induction to DDG."
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "space-y-4",
						children: STEPS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-4 rounded-2xl bg-card p-5 shadow-card",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-2xl text-accent",
								children: s.n
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-semibold",
								children: s.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: s.body
							})] })]
						}, s.n))
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mx-auto max-w-6xl px-4 py-16 sm:px-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-4 sm:grid-cols-3",
					children: [
						{
							icon: Lock,
							title: "Role-based access",
							body: "Learner, Trainer, Administrator, Super Admin — FRAC-aligned views."
						},
						{
							icon: Cloud,
							title: "Government-cloud ready",
							body: "Designed for NIC / MeghRaj hosting with audit-friendly data sharing marks."
						},
						{
							icon: Shield,
							title: "SSO with iGOT identity",
							body: "Directory login experience mapped to MoSPI and State DES officers."
						}
					].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "size-5 text-indigo" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-3 font-semibold",
								children: item.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: item.body
							})
						]
					}, item.title))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "px-4 pb-16 sm:px-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-col items-start justify-between gap-6 rounded-3xl bg-navy px-8 py-10 text-on-navy sm:flex-row sm:items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl font-semibold",
						children: "Ready for the next survey cycle?"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-lg text-sm text-on-navy/70",
						children: "Sign in as a learner, trainer or administrator to tour competency analytics, the iGOT catalogue and quiz studio."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "accent",
						size: "lg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/login",
							children: ["Enter the platform", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "border-t border-border px-4 py-8 text-sm text-muted-foreground sm:px-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-col gap-4 sm:flex-row sm:items-center sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoMark, { className: "size-7" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "StatSkill AI · Skill intelligence for official statistics" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "English · हिन्दी · regional-language ready" })]
				})
			})
		]
	});
}
function HeroPreview() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative hidden lg:block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-3xl border border-on-navy/15 bg-indigo/35 p-4 backdrop-blur-md",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between px-2 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoMark, { className: "size-7" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold text-on-navy",
							children: "Priya Sharma"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] text-on-navy/60",
							children: "Joint Director · NAD, NSO"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-full bg-saffron/20 px-2 py-0.5 text-[10px] font-medium text-saffron",
						children: "Score 64"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 grid grid-cols-2 gap-2",
					children: [
						[
							"Python",
							48,
							75
						],
						[
							"AI / ML",
							32,
							70
						],
						[
							"National Accounts",
							86,
							92
						],
						[
							"Data Privacy",
							61,
							82
						]
					].map(([name, score, target]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl bg-on-navy/8 p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-on-navy/70",
								children: name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 font-display text-xl text-on-navy",
								children: score
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 h-1.5 overflow-hidden rounded-full bg-on-navy/10",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full rounded-full bg-saffron",
									style: { width: `${score}%` }
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-[10px] text-on-navy/50",
								children: ["target ", target]
							})
						]
					}, String(name)))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex items-center gap-2 rounded-xl bg-on-navy/8 px-3 py-2 text-xs text-on-navy/80",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3.5 text-saffron" }), "Next: Python for Official Statistics · iGOT · 16h"]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "absolute -bottom-6 -left-6 hidden rounded-2xl bg-card p-3 text-foreground shadow-lift xl:block",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 text-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "size-3.5 text-accent" }), "High demand for Python and AI/ML"]
			})
		})]
	});
}
//#endregion
export { Home as component };
