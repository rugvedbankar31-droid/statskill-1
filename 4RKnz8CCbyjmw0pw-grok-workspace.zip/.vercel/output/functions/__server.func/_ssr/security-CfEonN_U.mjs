import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { S as Globe, T as Cloud, b as KeyRound, c as Server, g as Lock, s as ShieldCheck } from "../_libs/lucide-react.mjs";
import { f as PageHeader, i as Card, n as Badge, t as AppShell } from "./card-DlolnDSg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/security-CfEonN_U.js
var import_jsx_runtime = require_jsx_runtime();
var ROLES = [
	{
		role: "Learner",
		access: "Own competency file, catalogue, sit published papers, assistant"
	},
	{
		role: "Trainer",
		access: "Question bank edit/approve/publish, cohort results, NSSTA materials"
	},
	{
		role: "Administrator",
		access: "Workforce analytics, user directory, catalogues, reports"
	},
	{
		role: "Super Admin",
		access: "Framework versioning, tenant federation, SSO policy, audit export"
	}
];
function SecurityPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "System design",
			title: "Security and readiness",
			description: "Role-based access, iGOT SSO, government-cloud hosting posture and a multilingual shell — designed for MoSPI deployment, not a public LMS."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 md:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "size-5 text-indigo" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-xl font-semibold",
						children: "SSO login experience"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: "Officers authenticate through iGOT Karmayogi / NIC identity. Tokens carry cadre (ISS, SSS), posting and FRAC role. This preview uses named directory personas in place of a live IdP."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "navy",
								children: "SAML 2.0"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "navy",
								children: "OIDC"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "outline",
								children: "NIC IdP"
							})
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cloud, { className: "size-5 text-indigo" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-xl font-semibold",
						children: "Government-cloud ready"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: "Target hosting on NIC National Cloud / MeghRaj with no unit-level microdata at rest in the learning layer. Competency scores and enrolment metadata only."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "success",
							children: "MeitY empanelled path"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "outline",
							children: "No survey microdata"
						})]
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
			className: "mt-4 overflow-x-auto p-0",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full min-w-[520px] text-left text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "border-b border-border text-xs uppercase tracking-wide text-muted-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-5 py-3 font-medium",
						children: "Role"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-5 py-3 font-medium",
						children: "Access"
					})] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: ROLES.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-b border-border last:border-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-5 py-3 font-medium",
						children: r.role
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-5 py-3 text-muted-foreground",
						children: r.access
					})]
				}, r.role)) })]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 grid gap-4 sm:grid-cols-3",
			children: [
				{
					icon: ShieldCheck,
					title: "Secure data sharing",
					body: "Division-to-academy sharing is tagged purpose-limited. Exports are officer-level aggregates, never unit-level survey files."
				},
				{
					icon: Globe,
					title: "Multilingual",
					body: "English and Hindi ship in the shell. Regional language packs (Tamil, Bengali, Marathi) plug into the same key map."
				},
				{
					icon: Server,
					title: "Audit posture",
					body: "Role changes, paper publish events and report downloads are first-class audit events for internal inspection."
				}
			].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "size-5 text-accent" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-3 font-semibold",
						children: item.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: item.body
					})
				]
			}, item.title))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-4 flex items-start gap-3 p-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "mt-0.5 size-4 text-indigo" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Classification: Official (learning metadata). Do not upload identifiable respondent records from PLFS, HCES or ASI into Quiz Studio."
			})]
		})
	] });
}
//#endregion
export { SecurityPage as component };
