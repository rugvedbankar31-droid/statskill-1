import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { S as useHydrated, l as DOMAIN_LABEL } from "./router-LYI7r0H-.mjs";
import { m as Skeleton } from "./card-DlolnDSg.mjs";
import { a as CartesianGrid, c as PolarAngleAxis, d as Cell, f as ResponsiveContainer, i as XAxis, l as PolarRadiusAxis, m as Legend, n as BarChart, o as Bar, p as Tooltip, r as YAxis, s as Radar, t as RadarChart, u as PolarGrid } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/charts-BJ_ujbxC.js
var import_jsx_runtime = require_jsx_runtime();
function ClientOnly({ children, fallback }) {
	if (!useHydrated()) return fallback ?? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-56 w-full" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
function ScoreRing({ value, size = 148 }) {
	const r = 54;
	const c = 2 * Math.PI * r;
	const offset = c - Math.min(100, Math.max(0, value)) / 100 * c;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		width: size,
		height: size,
		viewBox: "0 0 128 128",
		className: "overflow-visible",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "64",
				cy: "64",
				r,
				fill: "none",
				className: "stroke-muted",
				strokeWidth: "10"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "64",
				cy: "64",
				r,
				fill: "none",
				className: "stroke-accent",
				strokeWidth: "10",
				strokeLinecap: "round",
				strokeDasharray: c,
				strokeDashoffset: offset,
				transform: "rotate(-90 64 64)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "64",
				y: "60",
				textAnchor: "middle",
				className: "fill-foreground font-sans",
				style: {
					fontSize: 28,
					fontWeight: 600
				},
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "64",
				y: "78",
				textAnchor: "middle",
				className: "fill-muted-foreground font-sans",
				style: {
					fontSize: 11,
					fontWeight: 500
				},
				children: "/ 100"
			})
		]
	});
}
var tooltipStyle = {
	background: "var(--card)",
	border: "1px solid var(--border)",
	borderRadius: 12,
	color: "var(--foreground)",
	fontSize: 12
};
function DomainRadar({ data }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClientOnly, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-64 w-full",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(RadarChart, {
			data,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarGrid, { stroke: "var(--border)" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarAngleAxis, {
					dataKey: "label",
					tick: {
						fill: "var(--muted-foreground)",
						fontSize: 11
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PolarRadiusAxis, {
					angle: 30,
					domain: [0, 100],
					tick: false,
					axisLine: false
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radar, {
					dataKey: "target",
					stroke: "var(--indigo)",
					fill: "var(--indigo)",
					fillOpacity: .08
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radar, {
					dataKey: "score",
					stroke: "var(--accent)",
					fill: "var(--accent)",
					fillOpacity: .28
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, { wrapperStyle: { fontSize: 12 } }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: tooltipStyle })
			]
		}) })
	}) });
}
function Heatmap({ items }) {
	function tone(score) {
		if (score >= 80) return "bg-success/20 text-success";
		if (score >= 60) return "bg-indigo/15 text-indigo";
		if (score >= 45) return "bg-warning/18 text-warning";
		return "bg-destructive/12 text-destructive";
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4",
		children: items.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: `rounded-xl px-3 py-3 ${tone(c.score)}`,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-medium uppercase tracking-wide opacity-80",
					children: DOMAIN_LABEL[c.domain]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm font-semibold leading-snug",
					children: c.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 font-mono text-lg tabular-nums",
					children: c.score
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[11px] opacity-80",
					children: ["target ", c.target]
				})
			]
		}, c.id))
	});
}
function GapBars({ items }) {
	const gaps = [...items].sort((a, b) => b.target - b.score - (a.target - a.score)).slice(0, 6);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-3",
		children: gaps.map((c) => {
			const gap = Math.max(0, c.target - c.score);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-1 flex items-baseline justify-between text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-medium",
					children: c.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "tabular-nums text-muted-foreground",
					children: [
						c.score,
						" · gap ",
						gap
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative h-2 overflow-hidden rounded-full bg-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-y-0 left-0 rounded-full bg-indigo/35",
					style: { width: `${c.target}%` }
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-y-0 left-0 rounded-full bg-accent",
					style: { width: `${c.score}%` }
				})]
			})] }, c.id);
		})
	});
}
function WorkforceBars({ rows }) {
	const byDept = /* @__PURE__ */ new Map();
	for (const r of rows) {
		const cur = byDept.get(r.department) ?? {
			name: r.department,
			score: 0,
			n: 0,
			completion: 0
		};
		cur.score += r.score;
		cur.completion += r.completionRate;
		cur.n += 1;
		byDept.set(r.department, cur);
	}
	const data = [...byDept.values()].map((d) => ({
		name: d.name.replace(" Division", "").replace(" & Research", "").replace(" & Innovation", ""),
		score: Math.round(d.score / d.n),
		completion: Math.round(d.completion / d.n)
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClientOnly, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-72 w-full",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
			data,
			margin: {
				left: 0,
				right: 8,
				top: 8,
				bottom: 24
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
					stroke: "var(--border)",
					vertical: false
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
					dataKey: "name",
					tick: {
						fill: "var(--muted-foreground)",
						fontSize: 10
					},
					interval: 0,
					angle: -22,
					textAnchor: "end",
					height: 48
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
					domain: [0, 100],
					tick: {
						fill: "var(--muted-foreground)",
						fontSize: 11
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: tooltipStyle }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
					dataKey: "score",
					name: "Competency",
					fill: "var(--indigo)",
					radius: [
						6,
						6,
						0,
						0
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
					dataKey: "completion",
					name: "Completion %",
					fill: "var(--accent)",
					radius: [
						6,
						6,
						0,
						0
					]
				})
			]
		}) })
	}) });
}
function SkillDistribution({ rows }) {
	const data = [
		"statistical",
		"technical",
		"digital",
		"behavioural"
	].map((d) => ({
		name: DOMAIN_LABEL[d],
		value: Math.round(rows.reduce((s, r) => s + r.domainScores[d], 0) / Math.max(1, rows.length))
	}));
	const colors = [
		"var(--indigo)",
		"var(--accent)",
		"var(--success)",
		"var(--navy)"
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClientOnly, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-64 w-full",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
			data,
			layout: "vertical",
			margin: {
				left: 16,
				right: 16
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
					stroke: "var(--border)",
					horizontal: false
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
					type: "number",
					domain: [0, 100],
					tick: {
						fill: "var(--muted-foreground)",
						fontSize: 11
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
					type: "category",
					dataKey: "name",
					width: 128,
					tick: {
						fill: "var(--foreground)",
						fontSize: 12
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: tooltipStyle }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
					dataKey: "value",
					name: "Mean score",
					radius: [
						0,
						8,
						8,
						0
					],
					children: data.map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: colors[i] }, data[i].name))
				})
			]
		}) })
	}) });
}
//#endregion
export { SkillDistribution as a, ScoreRing as i, GapBars as n, WorkforceBars as o, Heatmap as r, DomainRadar as t };
