import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as COURSES, b as cn, c as DESIGNATIONS, f as REGIONS, h as WORKFORCE, o as DEMO_USERS, s as DEPARTMENTS, u as INSIGHTS, x as downloadText } from "./router-LYI7r0H-.mjs";
import { a as CardContent, f as PageHeader, i as Card, n as Badge, o as CardHeader, r as Button, s as CardTitle, t as AppShell } from "./card-DlolnDSg.mjs";
import { a as SkillDistribution, o as WorkforceBars } from "./charts-BJ_ujbxC.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DbRRFmVH.mjs";
import { i as Trigger, n as List, r as Root2, t as Content } from "../_libs/radix-ui__react-tabs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-CIB4h-il.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Tabs = Root2;
var TabsList = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {
	ref,
	className: cn("inline-flex h-11 items-center justify-center rounded-xl bg-muted p-1 text-muted-foreground", className),
	...props
}));
TabsList.displayName = List.displayName;
var TabsTrigger = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trigger, {
	ref,
	className: cn("inline-flex items-center justify-center whitespace-nowrap rounded-lg px-3 py-1.5 text-sm font-medium transition-[background-color,color,box-shadow] duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-card data-[state=active]:text-foreground data-[state=active]:shadow-card", className),
	...props
}));
TabsTrigger.displayName = Trigger.displayName;
var TabsContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content, {
	ref,
	className: cn("mt-4 focus-visible:outline-none", className),
	...props
}));
TabsContent.displayName = Content.displayName;
function AdminPage() {
	const [department, setDepartment] = (0, import_react.useState)("all");
	const [designation, setDesignation] = (0, import_react.useState)("all");
	const [region, setRegion] = (0, import_react.useState)("all");
	const [domain, setDomain] = (0, import_react.useState)("all");
	const rows = (0, import_react.useMemo)(() => {
		return WORKFORCE.filter((w) => {
			if (department !== "all" && w.department !== department) return false;
			if (designation !== "all" && w.designation !== designation) return false;
			if (region !== "all" && w.region !== region) return false;
			if (domain !== "all") {
				if (w.domainScores[domain] >= 70) return false;
			}
			return true;
		});
	}, [
		department,
		designation,
		region,
		domain
	]);
	const mean = rows.length ? Math.round(rows.reduce((s, r) => s + r.score, 0) / rows.length) : 0;
	const completion = rows.length ? Math.round(rows.reduce((s, r) => s + r.completionRate, 0) / rows.length) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "Capacity building division",
			title: "Administrator dashboard",
			description: "Organisation-wide competency analytics for MoSPI, NSO and participating State DES units.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: () => {
					downloadText("statskill-workforce.json", JSON.stringify(rows, null, 2), "application/json");
					toast.success("Workforce extract downloaded.");
				},
				children: "Export report"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Filter, {
					label: "Department",
					value: department,
					onChange: setDepartment,
					options: DEPARTMENTS
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Filter, {
					label: "Designation",
					value: designation,
					onChange: setDesignation,
					options: DESIGNATIONS
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Filter, {
					label: "Region",
					value: region,
					onChange: setRegion,
					options: REGIONS
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Filter, {
					label: "Competency domain",
					value: domain,
					onChange: setDomain,
					options: [
						{
							value: "statistical",
							label: "Statistical"
						},
						{
							value: "technical",
							label: "Technical"
						},
						{
							value: "digital",
							label: "Digital Governance"
						},
						{
							value: "behavioural",
							label: "Behavioural"
						}
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Filter, {
					label: "Date range",
					value: "fy",
					onChange: () => toast.message("FY 2026–27 is the active training year."),
					options: [{
						value: "fy",
						label: "FY 2026–27"
					}],
					hideAll: true
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3 sm:grid-cols-4",
			children: [
				["Officers in view", String(rows.length)],
				["Mean competency", String(mean)],
				["Learning completion", `${completion}%`],
				["Hours logged", String(rows.reduce((s, r) => s + r.hours, 0))]
			].map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: k
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 font-display text-2xl font-semibold tabular-nums",
					children: v
				})]
			}, k))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 grid gap-4 lg:grid-cols-2",
			children: INSIGHTS.map((ins) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: "accent",
						children: ins.tag
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-3 font-display text-lg font-semibold",
						children: ins.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: ins.body
					})
				]
			}, ins.title))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 grid gap-4 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Department comparison" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: rows.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkforceBars, { rows }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Workforce skill distribution" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: rows.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkillDistribution, { rows }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {}) })] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
			defaultValue: "people",
			className: "mt-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "people",
						children: "Users"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "framework",
						children: "Frameworks"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "catalogue",
						children: "Course catalogues"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "assess",
						children: "Assessments"
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "people",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "overflow-x-auto p-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full min-w-[640px] text-left text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "border-b border-border text-xs uppercase tracking-wide text-muted-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-4 py-3 font-medium",
										children: "Officer"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-4 py-3 font-medium",
										children: "Designation"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-4 py-3 font-medium",
										children: "Department"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-4 py-3 font-medium",
										children: "Score"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-4 py-3 font-medium",
										children: "Completion"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-4 py-3 font-medium",
										children: "Top gap"
									})
								] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-border last:border-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-4 py-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-medium",
											children: r.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs text-muted-foreground",
											children: [
												r.cadre,
												" · ",
												r.region
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: r.designation
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: r.department
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 tabular-nums",
										children: r.score
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-4 py-3 tabular-nums",
										children: [r.completionRate, "%"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: r.topGap
									})
								]
							}, r.id)) })]
						}), rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "framework",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-semibold",
								children: "NSSTA / FRAC competency framework"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted-foreground",
								children: "Four domains, fourteen skills. Super Admins can version the framework at the start of each training year. Current version: FY 2026–27 v3."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-4 grid gap-2 sm:grid-cols-2",
								children: [
									"Statistical",
									"Technical",
									"Digital Governance",
									"Behavioural"
								].map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "rounded-xl bg-muted/60 px-3 py-2 text-sm",
									children: [d, " domain · active"]
								}, d))
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "catalogue",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-3 md:grid-cols-2",
						children: COURSES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "navy",
									children: c.provider
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 font-medium",
									children: c.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: [
										c.durationHours,
										"h · ",
										c.level,
										" · rating ",
										c.rating
									]
								})
							]
						}, c.id))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
					value: "assess",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "Live papers sit in Trainer Desk. Directory identities in this preview:"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-3 space-y-2 text-sm",
							children: DEMO_USERS.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
								u.name,
								" · ",
								u.role,
								" · ",
								u.email
							] }, u.id))
						})]
					})
				})
			]
		})
	] });
}
function Filter({ label, value, onChange, options, hideAll }) {
	const items = options.map((o) => typeof o === "string" ? {
		value: o,
		label: o
	} : o);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block text-xs font-medium text-muted-foreground",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
			value,
			onValueChange: onChange,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
				className: "mt-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [!hideAll && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
				value: "all",
				children: "All"
			}), items.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
				value: o.value,
				children: o.label
			}, o.value))] })]
		})]
	});
}
function Empty() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "px-4 py-10 text-center text-sm text-muted-foreground",
		children: "No officers match these filters. Clear a dimension to widen the view."
	});
}
//#endregion
export { AdminPage as component };
