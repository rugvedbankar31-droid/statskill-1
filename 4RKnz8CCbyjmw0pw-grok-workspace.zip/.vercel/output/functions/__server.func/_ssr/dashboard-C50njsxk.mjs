import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { E as Clock3, F as BookOpen, I as Award, L as ArrowRight, x as GraduationCap } from "../_libs/lucide-react.mjs";
import { _ as domainAverages, a as COURSES, i as COMPETENCIES, m as UPCOMING, n as useAppStore, v as overallScore, y as recommendCourses } from "./router-LYI7r0H-.mjs";
import { a as CardContent, f as PageHeader, i as Card, n as Badge, o as CardHeader, p as Progress, r as Button, s as CardTitle, t as AppShell, y as t } from "./card-DlolnDSg.mjs";
import { i as ScoreRing, n as GapBars } from "./charts-BJ_ujbxC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-C50njsxk.js
var import_jsx_runtime = require_jsx_runtime();
function DashboardPage() {
	const user = useAppStore((s) => s.user);
	const lang = useAppStore((s) => s.lang);
	const enrolments = useAppStore((s) => s.enrolments);
	const result = useAppStore((s) => s.assessmentResult);
	const enrol = useAppStore((s) => s.enrol);
	const advance = useAppStore((s) => s.advanceCourse);
	if (!user) return null;
	const competencies = result?.competencies ?? COMPETENCIES;
	const score = result ? overallScore(competencies) : user.competencyScore;
	const domains = domainAverages(competencies);
	const recommended = recommendCourses(competencies, 4);
	const roadmap = COURSES.filter((c) => enrolments.some((e) => e.courseId === c.id) || recommended.some((r) => r.id === c.id)).slice(0, 5);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: user.cadre,
			title: `${t(lang, "welcome")}, ${user.name.split(" ")[0]}`,
			description: `${user.designation} · ${user.department}`
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 lg:grid-cols-[1.2fr_0.8fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "overflow-hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "grid gap-6 p-6 sm:grid-cols-[auto_1fr] sm:items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreRing, { value: score }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold uppercase tracking-[0.14em] text-accent",
							children: t(lang, "competency")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-1 font-display text-2xl font-semibold",
							children: "Role-fit snapshot"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm text-muted-foreground",
							children: [
								"Profile ",
								user.profileCompletion,
								"% complete. ",
								user.education,
								"."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-1 flex justify-between text-xs text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Profile completion" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "tabular-nums",
									children: [user.profileCompletion, "%"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, { value: user.profileCompletion })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "outline",
							size: "sm",
							className: "mt-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/assessment",
								children: "Update assessment"
							})
						})
					] })]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [
					{
						icon: Clock3,
						label: t(lang, "hours"),
						value: user.learningHours
					},
					{
						icon: Award,
						label: t(lang, "certs"),
						value: user.certificates
					},
					{
						icon: BookOpen,
						label: t(lang, "modules"),
						value: user.completedModules
					},
					{
						icon: GraduationCap,
						label: t(lang, "upcoming"),
						value: user.upcomingAssessments
					}
				].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(s.icon, { className: "size-4 text-indigo" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 font-display text-2xl font-semibold tabular-nums",
							children: s.value
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: s.label
						})
					]
				}, s.label))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 grid gap-4 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Skill-gap insights" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Statistical, technical, digital governance and behavioural domains."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-5 grid grid-cols-2 gap-2 sm:grid-cols-4",
				children: domains.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-muted/70 p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] text-muted-foreground",
						children: d.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xl tabular-nums",
						children: d.score
					})]
				}, d.domain))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GapBars, { items: competencies })] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Upcoming" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "space-y-3",
				children: UPCOMING.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-border p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-wide text-accent",
							children: u.type
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 font-medium",
							children: u.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								u.date,
								" · ",
								u.venue
							]
						})
					]
				}, u.id))
			})] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-end justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl font-semibold",
					children: t(lang, "roadmap")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "link",
					size: "sm",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/courses",
						children: "Full catalogue"
					})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 md:grid-cols-2 xl:grid-cols-3",
				children: roadmap.map((course) => {
					const enr = enrolments.find((e) => e.courseId === course.id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "flex flex-col p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "navy",
									children: course.provider
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-muted-foreground",
									children: course.level
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-3 font-semibold leading-snug",
								children: course.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-xs text-muted-foreground",
								children: [
									course.durationHours,
									"h · ",
									course.modules,
									" modules · ",
									course.skills.join(" · ")
								]
							}),
							enr && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, { value: enr.progress }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-[11px] text-muted-foreground tabular-nums",
									children: [
										enr.progress,
										"% · ",
										enr.status.replace("_", " ")
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-4 flex gap-2",
								children: enr ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "accent",
									onClick: () => advance(course.id),
									children: enr.status === "completed" ? "Revise" : t(lang, "continue")
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "accent",
									onClick: () => enrol(course.id),
									children: t(lang, "start")
								})
							})
						]
					}, course.id);
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
				className: "flex-row items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: t(lang, "recommended") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/courses",
					className: "text-sm text-indigo",
					children: ["iGOT Karmayogi", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "ml-1 inline size-3.5" })]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "grid gap-3 sm:grid-cols-2",
				children: recommended.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3 rounded-xl bg-muted/60 p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: c.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [
							c.provider,
							" · ",
							c.durationHours,
							"h · ",
							c.level
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "outline",
						onClick: () => enrol(c.id),
						children: t(lang, "enrol")
					})]
				}, c.id))
			})]
		})
	] });
}
//#endregion
export { DashboardPage as component };
