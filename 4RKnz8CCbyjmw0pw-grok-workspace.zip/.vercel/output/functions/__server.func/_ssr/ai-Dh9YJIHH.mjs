import { a as object, i as number, n as array, o as string, t as _enum } from "../_libs/zod.mjs";
import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ai-Dh9YJIHH.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var quizInput = object({
	content: string().min(40).max(9e3),
	sourceName: string().max(180),
	count: number().min(3).max(12),
	difficulty: _enum([
		"easy",
		"medium",
		"hard",
		"mixed"
	]),
	language: _enum([
		"English",
		"Hindi",
		"Bilingual"
	]),
	durationMin: number().min(5).max(60)
});
var chatInput = object({
	messages: array(object({
		role: _enum(["user", "assistant"]),
		content: string().max(2e3)
	})).max(10),
	lang: _enum(["en", "hi"]),
	learnerContext: string().max(500).optional()
});
var insightInput = object({ profileSummary: string().min(20).max(2500) });
async function grokChat(messages, maxTokens) {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "AI is not available in this environment."
	};
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify({
			model: "grok-4.5",
			messages,
			temperature: .4,
			max_tokens: maxTokens
		})
	});
	if (!res.ok) return {
		ok: false,
		error: `AI service returned ${res.status}.`
	};
	const text = (await res.json()).choices?.[0]?.message?.content?.trim() ?? "";
	if (!text) return {
		ok: false,
		error: "Empty AI response."
	};
	return {
		ok: true,
		text
	};
}
function extractJson(text) {
	const raw = (text.match(/```(?:json)?\s*([\s\S]*?)```/i)?.[1] ?? text).trim();
	const start = raw.indexOf("{");
	const end = raw.lastIndexOf("}");
	if (start < 0 || end <= start) throw new Error("No JSON object in model output");
	return JSON.parse(raw.slice(start, end + 1));
}
var generateQuizFn_createServerFn_handler = createServerRpc({
	id: "ec45b7171d1dfd81134b61f1e77afa0501e03bcb339faf7f8c6ff8766e822dbf",
	name: "generateQuizFn",
	filename: "src/lib/ai.ts"
}, (opts) => generateQuizFn.__executeServer(opts));
var generateQuizFn = createServerFn({ method: "POST" }).validator((input) => quizInput.parse(input)).handler(generateQuizFn_createServerFn_handler, async ({ data }) => {
	const result = await grokChat([{
		role: "system",
		content: `You are StatSkill AI, generating assessments for India's Official Statistical System (MoSPI, NSO, NSSTA, ISS/SSS officers).
Return ONLY valid JSON with this shape:
{
  "title": string,
  "questions": [
    {
      "question": string,
      "options": [string, string, string, string],
      "correctIndex": 0-3,
      "explanation": string,
      "difficulty": "easy"|"medium"|"hard",
      "topic": string,
      "tags": string[]
    }
  ]
}
Rules:
- Exactly ${data.count} questions.
- Difficulty: ${data.difficulty}.
- Language: ${data.language}. If Hindi, write questions and explanations in Hindi (Devanagari). If Bilingual, question in English and a short Hindi gloss in the explanation.
- Options must be plausible. Explanations teach the concept, 2-4 sentences.
- Ground every item in the source material; do not invent contradicting facts.
- Topics should map to official statistics (sampling, SNA, PLFS, Python/R/SQL, privacy, etc.) when relevant.`
	}, {
		role: "user",
		content: `Source: ${data.sourceName}\nTarget duration: ${data.durationMin} minutes.\n\nMATERIAL:\n${data.content}`
	}], 2200);
	if (!result.ok) return result;
	try {
		const parsed = extractJson(result.text);
		const questions = (parsed.questions ?? []).filter((q) => q.question && Array.isArray(q.options) && q.options.length >= 4).slice(0, data.count).map((q, i) => ({
			id: `ai-${Date.now()}-${i}`,
			question: q.question,
			options: q.options.slice(0, 4),
			correctIndex: Math.min(3, Math.max(0, Number(q.correctIndex) || 0)),
			explanation: q.explanation ?? "",
			difficulty: q.difficulty ?? "medium",
			topic: q.topic ?? "Official Statistics",
			tags: q.tags ?? [],
			approved: false
		}));
		if (questions.length < 3) return {
			ok: false,
			error: "AI returned too few usable questions."
		};
		return {
			ok: true,
			quiz: {
				title: parsed.title ?? `Assessment · ${data.sourceName}`,
				questions
			}
		};
	} catch {
		return {
			ok: false,
			error: "Could not parse AI quiz JSON."
		};
	}
});
var chatAssistantFn_createServerFn_handler = createServerRpc({
	id: "5bdd17b3c46c31d7bdf35051d3222279bcfde07b5d96a18a205ccf932db639d8",
	name: "chatAssistantFn",
	filename: "src/lib/ai.ts"
}, (opts) => chatAssistantFn.__executeServer(opts));
var chatAssistantFn = createServerFn({ method: "POST" }).validator((input) => chatInput.parse(input)).handler(chatAssistantFn_createServerFn_handler, async ({ data }) => {
	return grokChat([{
		role: "system",
		content: `You are StatSkill AI, the learning assistant for officers of India's Official Statistical System (MoSPI, NSO, NSSO/FOD, NAD, NSSTA, State DES).
Help with competency gaps, iGOT Karmayogi / NSSTA TPAC courses, survey design, sampling, national accounts, Python/R/SQL, GIS, data visualization, AI/ML, cybersecurity, DPDP/privacy, leadership and project management.
Be practical. Recommend named courses from the StatSkill catalogue when useful (Python for Official Statistics, Sampling Techniques for Large-Scale Household Surveys, National Accounts Compilation, DPDP Act 2023, GIS for Census).
Do not invent ministry circular numbers. Keep answers under 180 words unless asked for a plan.
${data.lang === "hi" ? "Respond in Hindi (Devanagari), professional and concise." : "Respond in clear professional English."}
Learner context: ${data.learnerContext ?? "ISS/SSS officer on StatSkill AI."}`
	}, ...data.messages.map((m) => ({
		role: m.role,
		content: m.content
	}))], 420);
});
var competencyNarrativeFn_createServerFn_handler = createServerRpc({
	id: "60bf5185720447ea393fa19c90000d8091b98f41386d223e032749213bfef49f",
	name: "competencyNarrativeFn",
	filename: "src/lib/ai.ts"
}, (opts) => competencyNarrativeFn.__executeServer(opts));
var competencyNarrativeFn = createServerFn({ method: "POST" }).validator((input) => insightInput.parse(input)).handler(competencyNarrativeFn_createServerFn_handler, async ({ data }) => {
	return await grokChat([{
		role: "system",
		content: "You are StatSkill AI writing a competency briefing for an ISS/SSS officer. Return 3 short paragraphs: (1) current fit to role, (2) top three skill gaps with why they matter for India's statistical system, (3) a 90-day learning sequence citing iGOT Karmayogi or NSSTA TPAC style programmes. No markdown headings. No bullet emojis. Under 220 words."
	}, {
		role: "user",
		content: data.profileSummary
	}], 500);
});
//#endregion
export { chatAssistantFn_createServerFn_handler, competencyNarrativeFn_createServerFn_handler, generateQuizFn_createServerFn_handler };
