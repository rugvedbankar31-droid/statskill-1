import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as useAppStore, x as downloadText } from "./router-LYI7r0H-.mjs";
import { c as Input, f as PageHeader, g as Textarea, h as Switch, i as Card, l as Label, n as Badge, r as Button, t as AppShell } from "./card-DlolnDSg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quiz.trainer-pVUxXP9X.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TrainerDesk() {
	const quizzes = useAppStore((s) => s.quizzes);
	const updateQuestion = useAppStore((s) => s.updateQuestion);
	const setQuizStatus = useAppStore((s) => s.setQuizStatus);
	const deleteQuiz = useAppStore((s) => s.deleteQuiz);
	const [activeId, setActiveId] = (0, import_react.useState)(quizzes[0]?.id ?? null);
	const quiz = quizzes.find((q) => q.id === activeId) ?? quizzes[0];
	function exportQuiz() {
		if (!quiz) return;
		downloadText(`${quiz.title.replace(/\s+/g, "-").toLowerCase()}.json`, JSON.stringify(quiz, null, 2), "application/json");
		toast.success("Question paper exported as JSON.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		eyebrow: "NSSTA / iGOT faculty",
		title: "Trainer desk",
		description: "Edit, approve, publish and export generated questions before they reach a cohort.",
		actions: quiz ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: exportQuiz,
					children: "Export JSON"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => {
						setQuizStatus(quiz.id, "approved");
						toast.success("Paper approved.");
					},
					children: "Approve"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "accent",
					onClick: () => {
						setQuizStatus(quiz.id, "published");
						toast.success("Published to the learner catalogue.");
					},
					children: "Publish"
				})
			]
		}) : void 0
	}), quizzes.length === 0 || !quiz ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "px-6 py-16 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-xl font-semibold",
			children: "Nothing to review"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted-foreground",
			children: "Generate a paper in Quiz Studio. Drafts appear here for faculty edit-and-approve."
		})]
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 lg:grid-cols-[16rem_1fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
			className: "h-fit p-3",
			children: quizzes.map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setActiveId(q.id),
				className: `mb-1 w-full rounded-xl px-3 py-2 text-left text-sm ${q.id === quiz.id ? "bg-muted font-medium" : "hover:bg-muted/60"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block truncate",
					children: q.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[11px] text-muted-foreground",
					children: q.status
				})]
			}, q.id))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
						variant: "navy",
						children: [quiz.questions.length, " items"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: quiz.difficulty }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: "accent",
						children: quiz.status
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "ghost",
						onClick: () => {
							deleteQuiz(quiz.id);
							setActiveId(null);
						},
						children: "Delete draft"
					})
				]
			}), quiz.questions.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuestionEditor, {
				index: i,
				question: item,
				onChange: (next) => updateQuestion(quiz.id, next)
			}, item.id))]
		})]
	})] });
}
function QuestionEditor({ question, index, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs font-semibold uppercase tracking-wide text-muted-foreground",
					children: [
						"Item ",
						index + 1,
						" · ",
						question.topic,
						" · ",
						question.difficulty
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-2 text-xs",
					children: ["Approved", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						checked: Boolean(question.approved),
						onCheckedChange: (v) => onChange({
							...question,
							approved: v
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Stem" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
				className: "mt-1",
				value: question.question,
				onChange: (e) => onChange({
					...question,
					question: e.target.value
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid gap-2",
				children: question.options.map((opt, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "radio",
						name: `correct-${question.id}`,
						checked: question.correctIndex === i,
						onChange: () => onChange({
							...question,
							correctIndex: i
						}),
						className: "size-4 accent-[var(--accent)]",
						"aria-label": `Mark option ${i + 1} correct`
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: opt,
						onChange: (e) => {
							const options = [...question.options];
							options[i] = e.target.value;
							onChange({
								...question,
								options
							});
						}
					})]
				}, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				className: "mt-3 block",
				children: "Explanation"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
				className: "mt-1",
				value: question.explanation,
				onChange: (e) => onChange({
					...question,
					explanation: e.target.value
				})
			})
		]
	});
}
//#endregion
export { TrainerDesk as component };
