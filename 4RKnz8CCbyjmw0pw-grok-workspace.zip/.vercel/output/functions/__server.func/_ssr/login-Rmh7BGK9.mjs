import { y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { M as Building2, g as Lock, s as ShieldCheck } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as useAppStore, o as DEMO_USERS } from "./router-LYI7r0H-.mjs";
import { d as MarketingNav, i as Card, n as Badge, r as Button, y as t } from "./card-DlolnDSg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-Rmh7BGK9.js
var import_jsx_runtime = require_jsx_runtime();
var ROLE_COPY = {
	learner: "Competency file, learning path, quizzes",
	trainer: "Question bank, approve & publish, NSSTA desk",
	admin: "Workforce analytics, catalogues, reports",
	superadmin: "Frameworks, tenants, security controls"
};
function LoginPage() {
	const lang = useAppStore((s) => s.lang);
	const signIn = useAppStore((s) => s.signIn);
	const navigate = useNavigate();
	function enter(role) {
		signIn(role);
		toast.success("Signed in with iGOT SSO (demo directory).");
		if (role === "admin" || role === "superadmin") navigate({ to: "/admin" });
		else if (role === "trainer") navigate({ to: "/quiz/trainer" });
		else navigate({ to: "/dashboard" });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarketingNav, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-10 px-4 py-12 sm:px-6 lg:grid-cols-[0.9fr_1.1fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: "navy",
					children: "Secure access"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-4 font-display text-4xl font-semibold",
					children: t(lang, "ssoTitle")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-muted-foreground",
					children: t(lang, "ssoBody")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-8 space-y-3 text-sm",
					children: [
						{
							icon: ShieldCheck,
							text: "SAML / OIDC with NIC identity and iGOT Karmayogi"
						},
						{
							icon: Lock,
							text: "Role tokens: Learner, Trainer, Administrator, Super Admin"
						},
						{
							icon: Building2,
							text: "MoSPI directory + State DES federation (demo personas below)"
						}
					].map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-3 rounded-xl bg-card p-3 shadow-card",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(row.icon, { className: "mt-0.5 size-4 text-accent" }), row.text]
					}, row.text))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-xs text-muted-foreground",
					children: "Production SSO is directory-backed. This preview uses named officers so you can tour each role without a government IdP."
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: DEMO_USERS.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "flex flex-col p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] font-semibold uppercase tracking-[0.14em] text-accent",
							children: u.role
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-2 font-display text-xl font-semibold",
							children: u.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: u.designation
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs text-muted-foreground",
							children: [
								u.department,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								u.cadre,
								" · ",
								u.region
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 flex-1 text-xs text-muted-foreground",
							children: ROLE_COPY[u.role]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							className: "mt-4 w-full",
							variant: u.role === "learner" ? "accent" : "default",
							onClick: () => enter(u.role),
							children: ["Continue as ", u.name.split(" ")[0]]
						})
					]
				}, u.id))
			})]
		})]
	});
}
//#endregion
export { LoginPage as component };
