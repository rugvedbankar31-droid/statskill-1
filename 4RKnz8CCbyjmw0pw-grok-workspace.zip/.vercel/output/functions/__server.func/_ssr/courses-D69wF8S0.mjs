import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { u as Search } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as COURSES, i as COMPETENCIES, n as useAppStore, y as recommendCourses } from "./router-LYI7r0H-.mjs";
import { c as Input, f as PageHeader, i as Card, n as Badge, p as Progress, r as Button, t as AppShell, y as t } from "./card-DlolnDSg.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DbRRFmVH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/courses-D69wF8S0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CoursesPage() {
	const lang = useAppStore((s) => s.lang);
	const enrolments = useAppStore((s) => s.enrolments);
	const enrol = useAppStore((s) => s.enrol);
	const result = useAppStore((s) => s.assessmentResult);
	const [q, setQ] = (0, import_react.useState)("");
	const [provider, setProvider] = (0, import_react.useState)("all");
	const [level, setLevel] = (0, import_react.useState)("all");
	const recIds = new Set(recommendCourses(result?.competencies ?? COMPETENCIES, 5).map((c) => c.id));
	const list = (0, import_react.useMemo)(() => {
		const query = q.trim().toLowerCase();
		return COURSES.filter((c) => {
			if (provider !== "all" && c.provider !== provider) return false;
			if (level !== "all" && c.level !== level) return false;
			if (!query) return true;
			return `${c.title} ${c.skills.join(" ")} ${c.description} ${c.provider}`.toLowerCase().includes(query) || c.skills.some((s) => s.toLowerCase().startsWith(query));
		});
	}, [
		q,
		provider,
		level
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			eyebrow: "iGOT Karmayogi + NSSTA TPAC",
			title: "Course catalogue",
			description: "Semantic search across Mission Karmayogi and NSSTA programmes. Recommendations stay linked to your competency gaps."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-5 grid gap-3 md:grid-cols-[1fr_12rem_12rem]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "pl-9",
						placeholder: "Search skills, SNA, PLFS, Python…",
						value: q,
						onChange: (e) => setQ(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: provider,
					onValueChange: setProvider,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Provider" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "all",
							children: "All providers"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "iGOT Karmayogi",
							children: "iGOT Karmayogi"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "NSSTA TPAC",
							children: "NSSTA TPAC"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "StatSkill AI",
							children: "StatSkill AI"
						})
					] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: level,
					onValueChange: setLevel,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Level" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "all",
							children: "All levels"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "Foundation",
							children: "Foundation"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "Intermediate",
							children: "Intermediate"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "Advanced",
							children: "Advanced"
						})
					] })]
				})
			]
		}),
		list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "px-6 py-16 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold",
					children: "No programmes match"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Clear filters or try “sampling”, “Python”, or “DPDP”."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-4",
					variant: "outline",
					onClick: () => {
						setQ("");
						setProvider("all");
						setLevel("all");
					},
					children: "Reset filters"
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3 md:grid-cols-2",
			children: list.map((c) => {
				const enr = enrolments.find((e) => e.courseId === c.id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "flex flex-col p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "navy",
									children: c.provider
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "outline",
									children: c.level
								}),
								recIds.has(c.id) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "accent",
									children: "Gap-linked"
								}),
								enr && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: enr.status === "completed" ? "success" : "muted",
									children: enr.status.replace("_", " ")
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-3 font-display text-lg font-semibold leading-snug",
							children: c.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 flex-1 text-sm text-muted-foreground",
							children: c.description
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-xs text-muted-foreground",
							children: [
								c.durationHours,
								"h · ",
								c.modules,
								" modules · ",
								c.language,
								" · rating ",
								c.rating
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs text-muted-foreground",
							children: ["Skills: ", c.skills.join(", ")]
						}),
						enr && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, { value: enr.progress })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "mt-4 w-fit",
							variant: enr ? "outline" : "accent",
							onClick: () => {
								enrol(c.id);
								toast.success(enr ? "Enrolment updated." : `Enrolled in ${c.title}`);
							},
							children: enr ? t(lang, "continue") : t(lang, "enrol")
						})
					]
				}, c.id);
			})
		})
	] });
}
//#endregion
export { CoursesPage as component };
