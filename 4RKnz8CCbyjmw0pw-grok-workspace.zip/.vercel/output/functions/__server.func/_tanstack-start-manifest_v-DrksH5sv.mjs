//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DrksH5sv.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/admin",
			"/assessment",
			"/courses",
			"/dashboard",
			"/login",
			"/security",
			"/quiz/take",
			"/quiz/trainer",
			"/quiz/"
		],
		preloads: ["/assets/index-By735AHN.js", "/assets/store-CtIZ_f0i.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-By735AHN.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-Be1yVz-K.js",
			"/assets/card-CkUfvA59.js",
			"/assets/arrow-right-3vCrz85F.js",
			"/assets/cloud-CoN2Syj0.js",
			"/assets/lock-4sv-ssTS.js"
		]
	},
	"/admin": {
		filePath: "/workspace/src/routes/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-DwHR1qHz.js",
			"/assets/card-CkUfvA59.js",
			"/assets/select-CEw8sGwH.js",
			"/assets/charts-B27i5L5f.js"
		]
	},
	"/assessment": {
		filePath: "/workspace/src/routes/assessment.tsx",
		children: void 0,
		preloads: [
			"/assets/assessment-cpSFEB-C.js",
			"/assets/card-CkUfvA59.js",
			"/assets/select-CEw8sGwH.js",
			"/assets/charts-B27i5L5f.js"
		]
	},
	"/courses": {
		filePath: "/workspace/src/routes/courses.tsx",
		children: void 0,
		preloads: [
			"/assets/courses-CPlLB--L.js",
			"/assets/card-CkUfvA59.js",
			"/assets/select-CEw8sGwH.js"
		]
	},
	"/dashboard": {
		filePath: "/workspace/src/routes/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-BzSkKy5s.js",
			"/assets/card-CkUfvA59.js",
			"/assets/arrow-right-3vCrz85F.js",
			"/assets/charts-B27i5L5f.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-sEOtdhqZ.js",
			"/assets/card-CkUfvA59.js",
			"/assets/lock-4sv-ssTS.js",
			"/assets/shield-check-C7vW1y2W.js"
		]
	},
	"/security": {
		filePath: "/workspace/src/routes/security.tsx",
		children: void 0,
		preloads: [
			"/assets/security-CWa8gy12.js",
			"/assets/card-CkUfvA59.js",
			"/assets/cloud-CoN2Syj0.js",
			"/assets/lock-4sv-ssTS.js",
			"/assets/shield-check-C7vW1y2W.js"
		]
	},
	"/quiz/take": {
		filePath: "/workspace/src/routes/quiz.take.tsx",
		children: void 0,
		preloads: ["/assets/quiz.take-DpBpB18W.js", "/assets/card-CkUfvA59.js"]
	},
	"/quiz/trainer": {
		filePath: "/workspace/src/routes/quiz.trainer.tsx",
		children: void 0,
		preloads: ["/assets/quiz.trainer-CceCnlUl.js", "/assets/card-CkUfvA59.js"]
	},
	"/quiz/": {
		filePath: "/workspace/src/routes/quiz.index.tsx",
		children: void 0,
		preloads: [
			"/assets/quiz.index-Bm3dugQz.js",
			"/assets/card-CkUfvA59.js",
			"/assets/select-CEw8sGwH.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
